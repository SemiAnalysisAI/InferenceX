# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""CLIConfig -> AIPerfConfig converter: endpoint + models sections.

Reads from the flattened endpoint fields on ``CLIConfig`` (with ``headers``
and ``extra_inputs`` living as top-level fields on ``CLIConfig``) to produce
the dict shape consumed by ``AIPerfConfig``.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from aiperf.common.path_safety import safe_read_template_path
from aiperf.config.flags._section_fields import ENDPOINT_FIELDS

if TYPE_CHECKING:
    from aiperf.config.flags.cli_config import CLIConfig


def _url(item: str) -> str:
    return item if "://" in item else f"http://{item}"


def _endpoint_template_from_extra(
    endpoint: dict[str, Any], extra: dict[str, Any]
) -> None:
    payload_template = extra.pop("payload_template", None)
    if payload_template is None:
        return
    body = safe_read_template_path(payload_template)
    if body is None:
        body = payload_template
    endpoint["template"] = {
        "body": body,
        "response_field": extra.pop("response_field", "text"),
    }


def _endpoint_template_fallback(endpoint: dict[str, Any]) -> None:
    from aiperf.plugin.enums import EndpointType

    if endpoint.get("type") != EndpointType.TEMPLATE or "template" in endpoint:
        return
    extra_raw = endpoint.get("extra")
    if not extra_raw:
        return
    ex = dict(extra_raw) if isinstance(extra_raw, list) else extra_raw
    ts = ex.get("payload_template")
    if ts is None:
        return
    body = safe_read_template_path(ts)
    endpoint["template"] = {"body": body if body is not None else ts}


# Map (CLIConfig endpoint field name) -> (AIPerfConfig endpoint key).
_ENDPOINT_FIELD_MAP: dict[str, str] = {
    "url_selection_strategy": "url_strategy",
    "endpoint_type": "type",
    "streaming": "streaming",
    "allow_empty_content": "allow_empty_content",
    "custom_endpoint": "path",
    "api_key": "api_key",
    "timeout_seconds": "timeout",
    "wait_for_model_timeout": "wait_for_model_timeout",
    "wait_for_model_mode": "wait_for_model_mode",
    "wait_for_model_interval": "wait_for_model_interval",
    "transport": "transport",
    "use_legacy_max_tokens": "use_legacy_max_tokens",
    "use_server_token_count": "use_server_token_count",
    "per_chunk_usage": "per_chunk_usage",
    "connection_reuse_strategy": "connection_reuse",
    "download_video_content": "download_video_content",
    "request_content_type": "request_content_type",
    "session_header": "session_header",
    "uuid_and_strip": "uuid_and_strip",
    "aws_region": "aws_region",
    "aws_profile": "aws_profile",
    "auth_type": "auth_type",
    "aws_service": "aws_service",
}


def _maybe_build_reset_kv_cache(cli: CLIConfig) -> dict[str, Any] | None:
    ep_set = cli.model_fields_set & ENDPOINT_FIELDS
    enabled = cli.reset_kv_cache or any(
        name in ep_set
        for name in (
            "reset_kv_cache_timeout_seconds",
            "reset_kv_cache_path",
        )
    )
    if not enabled:
        return None
    out: dict[str, Any] = {}
    if cli.reset_kv_cache_timeout_seconds is not None:
        out["timeout_seconds"] = cli.reset_kv_cache_timeout_seconds
    if cli.reset_kv_cache_path is not None:
        out["path"] = cli.reset_kv_cache_path
    return out


def _maybe_build_server_profiler(cli: CLIConfig) -> dict[str, Any] | None:
    ep_set = cli.model_fields_set & ENDPOINT_FIELDS
    enabled = cli.server_profiler or any(
        name in ep_set
        for name in (
            "server_profiler_timeout_seconds",
            "server_profiler_start_path",
            "server_profiler_stop_path",
        )
    )
    if not enabled:
        return None
    out: dict[str, Any] = {}
    if cli.server_profiler_timeout_seconds is not None:
        out["timeout_seconds"] = cli.server_profiler_timeout_seconds
    if cli.server_profiler_start_path is not None:
        out["start_path"] = cli.server_profiler_start_path
    if cli.server_profiler_stop_path is not None:
        out["stop_path"] = cli.server_profiler_stop_path
    return out


_SAGEMAKER_FIELD_MAP = {
    "sagemaker_endpoint_name": "endpoint_name",
    "sagemaker_target_model": "target_model",
    "sagemaker_inference_component_name": "inference_component_name",
    "sagemaker_target_variant": "target_variant",
}


def _maybe_build_sagemaker(cli: CLIConfig) -> dict[str, Any] | None:
    """Collect the flat ``--sagemaker-*`` flags into the nested config section.

    The flags stay flat on the CLI (``--sagemaker-endpoint-name``) while the
    config model groups them, the same split ``reset_kv_cache`` uses.
    """
    ep_set = cli.model_fields_set & ENDPOINT_FIELDS
    out = {
        key: getattr(cli, field)
        for field, key in _SAGEMAKER_FIELD_MAP.items()
        if field in ep_set
    }
    return out or None


def build_endpoint(cli: CLIConfig) -> dict[str, Any]:
    """Build the AIPerfConfig ``endpoint`` section from a CLIConfig.

    Reads flattened endpoint fields directly off ``cli``. ``urls`` always
    populates; other endpoint fields only flow through when explicitly set
    by the user (per ``cli.model_fields_set & ENDPOINT_FIELDS``).
    ``headers`` / ``extra`` live as top-level fields on CLIConfig and
    flow through to the endpoint dict.
    """
    # --url defaults to http://localhost:8000 (min_length=1, validate_default=True),
    # so passing it through unconditionally means EndpointConfig never sees an
    # empty `urls` and the SageMaker before-validator never derives the runtime
    # host: the documented one-flag quick start would sign for SageMaker and send
    # to localhost. Omitted only when SageMaker is there to supply it, since
    # EndpointConfig.urls is otherwise required.
    derives_own_url = (
        "urls" not in cli.model_fields_set
        and "sagemaker_endpoint_name" in cli.model_fields_set
        and bool(cli.sagemaker_endpoint_name)
    )
    endpoint: dict[str, Any] = (
        {} if derives_own_url else {"urls": [_url(u) for u in cli.urls]}
    )
    ep_set = cli.model_fields_set & ENDPOINT_FIELDS
    for field, key in _ENDPOINT_FIELD_MAP.items():
        if field in ep_set:
            endpoint[key] = getattr(cli, field)

    cli_set = cli.model_fields_set
    if "headers" in cli_set and cli.headers:
        endpoint["headers"] = dict(cli.headers)
    if "extra_inputs" in cli_set and cli.extra_inputs:
        extra = dict(cli.extra_inputs)
        _endpoint_template_from_extra(endpoint, extra)
        endpoint["extra"] = extra
    _endpoint_template_fallback(endpoint)

    reset = _maybe_build_reset_kv_cache(cli)
    if reset is not None:
        endpoint["reset_kv_cache"] = reset
    profiler = _maybe_build_server_profiler(cli)
    if profiler is not None:
        endpoint["server_profiler"] = profiler
    sagemaker = _maybe_build_sagemaker(cli)
    if sagemaker is not None:
        endpoint["sagemaker"] = sagemaker

    return endpoint


def build_models(cli: CLIConfig) -> dict[str, Any]:
    """Build the AIPerfConfig ``models`` section from a CLIConfig.

    ``model_names`` and ``model_selection_strategy`` both live on the
    flattened endpoint section of CLIConfig.
    """
    models: dict[str, Any] = {"items": [{"name": n} for n in cli.model_names]}
    if "model_selection_strategy" in cli.model_fields_set:
        models["strategy"] = cli.model_selection_strategy
    return models
