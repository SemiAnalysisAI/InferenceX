# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

from __future__ import annotations

from typing import Any, ClassVar

from aiperf.common.enums import MediaType
from aiperf.common.models import (
    ExtractedPayload,
    InferenceServerResponse,
    ParsedResponse,
    ReasoningResponseData,
    RequestInfo,
    RequestRecord,
    TextResponseData,
    ToolCallResponseData,
    Turn,
)
from aiperf.common.types import JsonObject
from aiperf.common.utils import is_truthy_flag
from aiperf.endpoints import _openai_responses_replay as _replay
from aiperf.endpoints.base_endpoint import BaseEndpoint


class ResponsesEndpoint(BaseEndpoint):
    """OpenAI Responses API endpoint.

    Message-array construction reuses the generic
    ``BaseEndpoint.build_messages`` flow. Only the content-part type names
    differ from chat (``input_text`` vs ``text``, ``input_image`` vs
    ``image_url``), so we override those hooks and leave the iteration /
    raw-messages pass-through skeleton alone.

    The shared ``system_message`` lives on the top-level ``instructions``
    field rather than inside the ``input`` array (Responses API contract),
    and the per-conversation ``user_context_message`` is prepended as a
    leading user item.
    """

    # Responses API content-part type names. ``BaseEndpoint.extract_payload_inputs``
    # walks the payload once and dispatches every part against this map -
    # text parts contribute to the tokenisable text list, media parts
    # bump their respective counts.
    PART_TYPES: ClassVar[dict[MediaType, set[str]]] = {
        # ``output_text`` appears on replayed assistant history items;
        # omitting it undercounts ISL for multi-turn Responses payloads.
        MediaType.TEXT: {"input_text", "output_text"},
        MediaType.IMAGE: {"input_image"},
        MediaType.AUDIO: {"input_audio"},
        # Responses API does not currently support video input.
        MediaType.VIDEO: set(),
    }

    def extract_payload_inputs(self, payload: dict[str, Any]) -> ExtractedPayload:
        """Responses-API single-pass extraction.

        Inherits the base-class walk (which dispatches content parts via
        ``PART_TYPES``) and additionally prepends ``instructions`` - the
        Responses-API equivalent of a system prompt that lives at the
        top level of the payload rather than inside ``input``.
        Accepts both string and list-of-content-parts shapes for
        ``instructions`` (some Responses-API variants emit either).
        """
        result = super().extract_payload_inputs(payload)
        instructions = payload.get("instructions")
        if isinstance(instructions, str):
            result.texts.insert(0, instructions)
            if result.messages is not None:
                result.messages.insert(0, {"role": "system", "content": instructions})
        elif isinstance(instructions, list):
            collected: list[str] = []
            for part in instructions:
                if isinstance(part, dict):
                    text = part.get("text")
                    if isinstance(text, str) and text:
                        collected.append(text)
                elif isinstance(part, str) and part:
                    collected.append(part)
            for text in reversed(collected):
                result.texts.insert(0, text)
            if result.messages is not None and collected:
                # Chat-template view: collapse the multi-part instructions
                # into a single leading system message (the template wraps it
                # once regardless of how the API split the parts).
                result.messages.insert(
                    0, {"role": "system", "content": "".join(collected)}
                )
        return result

    # --- Content-part hooks (override only the type names) -------------------

    def _render_text_part(self, text: str) -> dict[str, Any]:
        return {"type": "input_text", "text": text}

    def _render_image_part(self, url_or_data_uri: str) -> dict[str, Any]:
        # Responses API takes ``image_url`` as a plain string, not nested.
        return {"type": "input_image", "image_url": url_or_data_uri}

    # _render_audio_part: inherited — Responses API uses the same
    # {"type": "input_audio", "input_audio": {...}} shape as chat.

    def _render_video_part(self, url_or_data_uri: str) -> dict[str, Any]:
        """Reject video parts at format time rather than letting the server 4xx.

        The Responses API does not accept video input as of this writing.
        Inheriting the chat default would emit ``{"type": "video_url", ...}``
        which the server rejects with an opaque schema error - and
        ``PART_TYPES[VIDEO]`` is empty, so ISL accounting silently
        undercounts. Surface the misconfiguration immediately.
        """
        raise NotImplementedError(
            "Responses API does not support video input. "
            "Use endpoint=chat for video turns, or remove the video content."
        )

    # ------------------------------------------------------------------
    # raw_messages filtering on replay
    # ------------------------------------------------------------------
    #
    # ``ResponsesEndpoint.build_assistant_turn`` captures the parent's
    # full ``output[]`` into ``raw_messages``. The Responses API accepts
    # most of those item types in ``input`` on the next request, but a
    # handful are *only* valid as input when paired with the corresponding
    # tool config or with ``previous_response_id`` / ``encrypted_content``:
    #
    # - ``web_search_call`` / ``file_search_call`` need ``tools=[{"type":
    #   "web_search"}]`` / ``file_search`` configured on the next request.
    # - ``image_generation_call`` / ``code_interpreter_call`` /
    #   ``computer_call`` likewise require their tool config.
    # - ``reasoning`` items need ``store=False`` + ``encrypted_content``,
    #   or the conversation continued via ``previous_response_id``.
    #
    # When a FORK-mode DAG child inherits the parent's history without
    # those tools/flags configured (the common case), splicing these
    # items back into ``input`` 400s with an opaque schema error.
    #
    # Skip them. ``message`` items (the actual assistant text) and
    # ``function_call`` items (user-defined tools, valid as input
    # alongside their ``function_call_output``) round-trip cleanly.

    _REPLAY_UNSAFE_OUTPUT_ITEM_TYPES: ClassVar[frozenset[str]] = frozenset(
        {
            "web_search_call",
            "file_search_call",
            "image_generation_call",
            "code_interpreter_call",
            "computer_call",
            "reasoning",
        }
    )

    def build_messages(self, turns: list[Turn]) -> list[dict[str, Any]]:
        """Filter Responses-API replay-unsafe items out of raw_messages.

        Reuses ``BaseEndpoint._flatten_turns`` for the flatten-and-merge and
        ``reset_context`` skeleton (sharing it avoids the drift that once let
        this override silently drop the reset), supplying only the
        Responses-specific per-item behaviour: dropping output-only item types
        (see ``_REPLAY_UNSAFE_OUTPUT_ITEM_TYPES``) and tagging synthetic turns
        with ``type: "message"``.
        """

        def _transform(item: dict[str, Any]) -> dict[str, Any] | None:
            if (
                isinstance(item, dict)
                and item.get("type") in self._REPLAY_UNSAFE_OUTPUT_ITEM_TYPES
            ):
                return None
            return item

        def _render(turn: Turn) -> dict[str, Any]:
            message = self._render_turn_message(turn)
            message["type"] = "message"
            return message

        return self._flatten_turns(
            turns, transform_raw_item=_transform, render_synthetic=_render
        )

    def format_payload(self, request_info: RequestInfo) -> dict[str, Any]:
        """Format OpenAI Responses API request payload from RequestInfo."""
        payload, _ = self._build_payload(request_info)
        self.trace(lambda: f"Formatted payload: {payload}")
        return payload

    def _build_payload(self, request_info: RequestInfo) -> tuple[dict[str, Any], bool]:
        """Build the wire payload and report whether the system prompt was
        merged into an input item that actually ships.

        The flag is read off the final payload, after endpoint ``extra`` and
        per-turn ``extra_body`` are applied, because either may replace
        ``input`` and discard the merged item.
        """
        if not request_info.turns:
            raise ValueError("Responses endpoint requires at least one turn.")

        turns = request_info.turns
        model_endpoint = request_info.model_endpoint

        # Responses API carries the system prompt in top-level ``instructions``
        # rather than in ``input``. The per-conversation ``user_context_message``
        # is a leading user item. Branch on the outgoing id, not the session's:
        # an override to ``None`` breaks the chain, so the server has no history
        # to replay and the full conversation must ship as in a stateless run.
        if self._outgoing_previous_response_id(request_info):
            # Stateful chaining: previous_response_id points to server-side history.
            self._warn_chaining_isl_once()
            rendered = self.build_messages([turns[-1]])
            context_items: list[dict[str, Any]] = []
        else:
            rendered = self.build_messages(turns)
            context_items = (
                [
                    {
                        "type": "message",
                        "role": self.DEFAULT_TURN_ROLE,
                        "content": request_info.user_context_message,
                    }
                ]
                if request_info.user_context_message
                else []
            )
        instructions, merge_prefix = self._system_prompt_carrier(request_info, rendered)

        # A dataset that authored its own leading ``role: system`` input item
        # collides with ``instructions``: both ship, and the server sees two
        # system prompts. Merge into the authored item and drop
        # ``instructions``, matching ``ChatEndpoint._format_messages`` -- the
        # de-dup invariant is endpoint-wide, and repeated system roles are
        # mishandled by many OpenAI-compatible servers.
        #
        # The merged item is placed AHEAD of ``user_context_message`` so the
        # system prompt stays the leading wire bytes, as it does for chat and
        # as ``SYSTEM_PREFIX`` cache-bust assumes. The alternative -- folding
        # the authored item's text into ``instructions`` and dropping it from
        # ``input`` -- would keep the "system lives in instructions" contract
        # unconditional, but flattens list-part content to text and discards
        # any extra fields on the authored item; the dataset's explicit wire
        # shape wins here.
        leading_system: list[dict[str, Any]] = []
        if merge_prefix is not None:
            # Copy rather than mutate: ``rendered`` aliases the turn's
            # raw_messages, reused across credits in a session.
            merged = dict(rendered[0])
            merged["content"] = self._prepend_system_text(
                merge_prefix, merged.get("content")
            )
            leading_system = [merged]
            rendered = rendered[1:]

        input_items: list[dict[str, Any]] = [
            *leading_system,
            *context_items,
            *rendered,
        ]

        # Conversation-level fields walk turns from the end so FORK-mode
        # children whose final turn lacks model/tools still inherit the parent's
        # intent. Per-request overrides stay scoped to the dispatching turn.
        model_name = turns[-1].model
        max_tokens = turns[-1].max_tokens
        extra_body = turns[-1].extra_body

        payload: dict[str, Any] = {
            "input": input_items,
            "model": model_name or model_endpoint.primary_model_name,
            "stream": model_endpoint.endpoint.streaming,
        }
        if request_info.previous_response_id:
            payload["previous_response_id"] = request_info.previous_response_id

        for key, value in (
            ("instructions", instructions),
            ("max_output_tokens", max_tokens),
            ("tools", self._latest_turn_attr(turns, "raw_tools")),
        ):
            if value is not None:
                payload[key] = value

        if model_endpoint.endpoint.extra:
            payload.update(model_endpoint.endpoint.extra)
        if extra_body:
            payload.update(extra_body)

        self._maybe_enable_usage_stream_options(payload, model_endpoint)

        merged_shipped = merge_prefix is not None and payload["input"] is input_items
        return payload, merged_shipped

    @staticmethod
    def _outgoing_previous_response_id(request_info: RequestInfo) -> str | None:
        """The ``previous_response_id`` the payload will actually carry.

        Endpoint ``extra`` and the dispatching turn's ``extra_body`` are applied
        after the payload is built and win over the session's value, including
        an explicit ``None`` that breaks the chain.
        """
        outgoing = request_info.previous_response_id
        for overrides in (
            dict(request_info.model_endpoint.endpoint.extra or {}),
            request_info.turns[-1].extra_body or {},
        ):
            if "previous_response_id" in overrides:
                outgoing = overrides["previous_response_id"]
        return outgoing

    def _system_prompt_already_stored(self, request_info: RequestInfo) -> bool:
        """Whether the chain this request continues already holds the prompt.

        The session flag describes the session's last stored response, so it
        only applies when the outgoing ``previous_response_id`` is still that
        response; an override to another response or to ``None`` does not
        inherit it.
        """
        return bool(
            request_info.previous_response_id
            and request_info.system_prompt_in_stored_history
            and self._outgoing_previous_response_id(request_info)
            == request_info.previous_response_id
        )

    def _system_prompt_carrier(
        self, request_info: RequestInfo, rendered: list[dict[str, Any]]
    ) -> tuple[str | None, str | None]:
        """Decide how this request carries ``system_message``.

        Returns ``(instructions, merge_prefix)``: at most one is set, and
        ``merge_prefix`` means "prepend to the authored leading system item".
        When the chained response's stored history already holds the prompt
        as an input item, neither is set: top-level ``instructions`` is not
        carried across ``previous_response_id``, but stored input items are,
        so sending it again would double the prompt.
        """
        system_message = request_info.system_message or None
        if system_message is None or self._system_prompt_already_stored(request_info):
            return None, None
        if (
            rendered
            and isinstance(rendered[0], dict)
            and rendered[0].get("role") == "system"
        ):
            return None, system_message
        return system_message, None

    def stored_history_has_system_prompt(self, request_info: RequestInfo) -> bool:
        """Whether the stored history of the response to ``request_info``
        contains the system prompt.

        The worker records this next to the response ID on success only, so
        the flag always describes the response being chained onto. It holds
        when the request still chains onto a history that carried the prompt,
        or when the merged input item survived onto the wire; prompts sent as
        ``instructions`` are not stored. Both are read from the built payload
        so explicit overrides of ``input`` or ``previous_response_id`` are
        reflected rather than inferred from the turns.
        """
        if not request_info.system_message:
            return False
        _, merged_shipped = self._build_payload(request_info)
        return self._system_prompt_already_stored(request_info) or merged_shipped

    _warned_chaining_isl: bool = False

    def _warn_chaining_isl_once(self) -> None:
        """Warn once that chained turns only send the newest turn on the wire.

        With ``previous_response_id`` the prior history lives server-side, so
        client-side Input Sequence Length (the default) reflects only the newest
        turn and undercounts the prompt the server actually prefills. Server-side
        token counts (``use_server_token_count``) report the true prompt size.
        """
        if (
            self._warned_chaining_isl
            or self.model_endpoint.endpoint.use_server_token_count
        ):
            return
        self._warned_chaining_isl = True
        self.warning(
            "Stateful Responses chaining is active (previous_response_id): only "
            "the newest turn is sent on the wire, so client-side Input Sequence "
            "Length undercounts the server-side prompt for chained turns. Enable "
            "--use-server-token-count for accurate multi-turn ISL."
        )

    def extract_response_id(self, record: RequestRecord) -> str | None:
        """Extract the server-generated response ID (``resp_<hash>``) for stateful
        chaining, but only when storage was requested for this run.

        ``store`` is a *request* parameter, not a standard field of the Responses
        object: the OpenAI spec does not list it on the response, and real
        servers (e.g. vLLM's agentic-api) accept it on the request but never
        serialize it back onto ``response.created`` / ``response.completed``.
        Gating on the echoed response ``store`` therefore never fires against
        those servers and silently disables chaining. We instead chain when
        storage was requested via ``--extra-inputs store:true`` (endpoint
        ``extra``); a server that *does* echo ``store: true`` is honored too.
        When neither is set we return ``None`` so the caller falls back to
        sending the full history.

        The response object lives under ``response`` for streaming lifecycle
        events (``response.created`` / ``response.completed`` / ...) and at the
        top level for a non-streaming response body.

        A request that returns HTTP 200 but fails does not set
        ``RequestRecord.error``. Streaming signals this via a
        ``response.failed`` / ``response.incomplete`` event; a non-streaming
        body signals it via top-level ``status``. In either case the advertised
        id belongs to an aborted response, so chaining onto it would corrupt the
        next turn and we return ``None`` regardless of the advertised id.
        """
        store_requested = self._store_requested()
        resp_id: str | None = None
        for response in record.responses:
            json_obj = response.get_json()
            if not isinstance(json_obj, dict):
                continue
            if _replay.is_failure_event(json_obj):
                return None
            nested = json_obj.get("response")
            source = nested if isinstance(nested, dict) else json_obj
            if _replay.is_failure_status(source):
                return None
            candidate = source.get("id")
            if not (isinstance(candidate, str) and candidate):
                continue
            if store_requested or source.get("store"):
                resp_id = candidate
        return resp_id

    def _store_requested(self) -> bool:
        """Whether the run requested server-side storage via endpoint ``extra``.

        ``EndpointInfo.extra`` is a list of ``(key, value)`` pairs; ``store`` may
        arrive as a bool or a string depending on how ``--extra-inputs`` was
        supplied.
        """
        store = dict(self.model_endpoint.endpoint.extra or []).get("store")
        return is_truthy_flag(store)

    @staticmethod
    def _maybe_enable_usage_stream_options(
        payload: dict[str, Any], model_endpoint: Any
    ) -> None:
        """Set ``stream_options.include_usage=True`` for streaming runs with
        server-side token counts, preserving any caller-supplied mapping."""
        ep = model_endpoint.endpoint
        if not (ep.streaming and ep.use_server_token_count):
            return
        so = payload.get("stream_options")
        if not isinstance(so, dict):
            payload["stream_options"] = {"include_usage": True}
        elif "include_usage" not in so:
            so["include_usage"] = True

    def parse_response(
        self, response: InferenceServerResponse
    ) -> ParsedResponse | None:
        """Parse OpenAI Responses API response.

        Handles both streaming SSE events (with ``"type"`` field) and
        non-streaming responses (with ``"object": "response"``).

        Args:
            response: Raw response from inference server

        Returns:
            Parsed response with extracted text/reasoning content and usage data
        """
        json_obj = response.get_json()
        if not json_obj:
            return None
        return self._route_parsed_json(json_obj, response.perf_ns)

    def _route_parsed_json(
        self, json_obj: JsonObject, perf_ns: int
    ) -> ParsedResponse | None:
        """Dispatch an already-deserialized response body to the streaming or
        full-response parser.

        Shared by ``parse_response`` (per-event) and ``extract_response_data``
        (record-level) so the latter can inspect each body once for the
        ``response.output_text.done`` de-duplication without re-parsing the
        JSON a second time.
        """
        # Streaming: events have a "type" field
        if "type" in json_obj:
            return self._parse_streaming_event(json_obj, perf_ns)

        # Non-streaming: full response object
        if json_obj.get("object") == "response":
            return self._parse_full_response(json_obj, perf_ns)

        return None

    def extract_response_data(self, record: RequestRecord) -> list[ParsedResponse]:
        """Extract parsed data, de-duplicating the streamed output text.

        A streaming Responses turn carries the assistant text twice: once as
        the chain of ``response.output_text.delta`` events and again, in full,
        as the terminal ``response.output_text.done`` event. Tokenising both
        doubles client-side output tokens (OSL / output-token-throughput ~2x).

        Once a delta has carried text for an output/content part we treat that
        part's terminal ``done`` as a structural envelope - mirroring the
        ``response.function_call_arguments.done`` exclusion in
        ``_streaming_event_data``. Tracking is keyed per
        ``(output_index, content_index)`` so a done-only part (a server that
        emits only the ``done`` event for that item, or deltas dropped under
        load) is NOT suppressed by a sibling part that did stream - it stays the
        sole text carrier and is still counted exactly once. The same holds for
        the non-streaming convenience field, which emits no deltas at all.

        The single forward pass is correct because a part's ``done`` event
        always trails its deltas in SSE arrival order, which ``record.responses``
        preserves.

        ``parse_response`` itself is intentionally left emitting the ``done``
        text: the worker's per-event callers (first-token detection, request
        latency) treat it as a plain data-bearing event and neither sums
        tokens, so they see no behavioral change.
        """
        parsed: list[ParsedResponse] = []
        streamed_parts: set[tuple[Any, Any]] = set()
        for response in record.responses:
            json_obj = response.get_json()
            if not json_obj:
                continue
            if isinstance(json_obj, dict):
                event_type = json_obj.get("type")
                part = (json_obj.get("output_index"), json_obj.get("content_index"))
                if event_type == "response.output_text.delta" and json_obj.get("delta"):
                    streamed_parts.add(part)
                elif (
                    event_type == "response.output_text.done" and part in streamed_parts
                ):
                    # This part's deltas already carried the text: drop the
                    # duplicate TEXT but keep an empty-text response at the done
                    # timestamp so content-timing metrics (request_latency uses
                    # content_responses[-1].perf_ns; inter_chunk_latency walks
                    # the gaps) are byte-for-byte unchanged from the pre-dedup
                    # behavior. Empty text contributes zero output tokens.
                    parsed.append(
                        ParsedResponse(
                            perf_ns=response.perf_ns, data=TextResponseData(text="")
                        )
                    )
                    continue
            if result := self._route_parsed_json(json_obj, response.perf_ns):
                parsed.append(result)
        return parsed

    def _parse_streaming_event(
        self, json_obj: JsonObject, perf_ns: int
    ) -> ParsedResponse | None:
        """Parse a streaming SSE event from the Responses API.

        Surfaces ``response.function_call_arguments.delta`` as a
        ``ToolCallResponseData`` - without this, ~64% of streaming turns
        in real agentic traffic have NO data-bearing event, so the
        worker's first-token callback never fires and client-side OSL is
        undercounted by every tool-using turn. The arguments JSON is what
        the model generated on the wire, so the existing tokeniser treats
        it like any other generated text.

        ``response.function_call_arguments.done`` carries no replayable
        delta content (the assembled arguments are already captured by
        the chained deltas plus the final ``response.completed`` /
        ``response.output_item.done`` events that ``build_assistant_turn``
        consumes), so we let it fall through to the structural-envelope
        branch below.

        Args:
            json_obj: Deserialized event JSON
            perf_ns: Performance timestamp

        Returns:
            Parsed response or None if the event carries no content
        """
        event_type = json_obj.get("type")

        data = self._streaming_event_data(event_type, json_obj)
        if data is not None:
            return ParsedResponse(perf_ns=perf_ns, data=data)

        if event_type == "response.completed":
            resp = json_obj.get("response") or {}
            usage = resp.get("usage") or None
            if usage:
                return ParsedResponse(perf_ns=perf_ns, data=None, usage=usage)
            return None

        # All other events (response.created, response.in_progress,
        # response.output_item.added/done, content_part.added/done,
        # response.function_call_arguments.done, etc.) carry no replayable
        # token content - they're structural envelopes.
        return None

    @staticmethod
    def _streaming_event_data(
        event_type: Any, json_obj: JsonObject
    ) -> TextResponseData | ReasoningResponseData | ToolCallResponseData | None:
        """Map a content-bearing SSE event to its response-data shape.

        Returns ``None`` for events that carry no payload-relevant content
        (including the missing-delta variants of the data events) so the
        caller can fall through to non-data branches like
        ``response.completed``.
        """
        if event_type == "response.output_text.delta":
            delta = json_obj.get("delta")
            return TextResponseData(text=delta) if delta else None

        if event_type == "response.reasoning_text.delta":
            delta = json_obj.get("delta")
            return ReasoningResponseData(reasoning=delta) if delta else None

        if event_type == "response.output_text.done":
            # Sole-carrier fallback for the no-delta case (non-streaming
            # convenience path, or a server that emits only the terminal
            # event). When deltas already carried this text,
            # ``extract_response_data`` drops this event before it reaches here
            # so the output is tokenised exactly once, not doubled.
            text = json_obj.get("text")
            return TextResponseData(text=text) if text else None

        if event_type == "response.function_call_arguments.delta":
            delta = json_obj.get("delta")
            return ToolCallResponseData(tool_call_text=delta) if delta else None

        return None

    def _parse_full_response(
        self, json_obj: JsonObject, perf_ns: int
    ) -> ParsedResponse | None:
        """Parse a non-streaming full response object.

        Args:
            json_obj: Deserialized response JSON with "object": "response"
            perf_ns: Performance timestamp

        Returns:
            Parsed response with extracted content and usage
        """
        data = self._extract_response_content(json_obj)
        usage = json_obj.get("usage") or None

        if data is None and not usage:
            return None

        return ParsedResponse(perf_ns=perf_ns, data=data, usage=usage)

    def _extract_response_content(
        self, json_obj: JsonObject
    ) -> TextResponseData | ReasoningResponseData | ToolCallResponseData | None:
        """Extract content from a non-streaming Responses API response.

        Walks ``output[]`` for every item type that carries model-generated
        tokens:

        - ``message`` items contribute their ``output_text`` parts.
        - ``reasoning`` items contribute their ``reasoning_text`` parts, or
          their ``summary_text`` parts when there are none.
        - ``function_call`` items contribute ``name`` + ``arguments`` -
          the model generated those tokens, and the server's
          ``usage.completion_tokens`` already counts them, so client-side
          OSL must too.

        Precedence mirrors ``ChatEndpoint.extract_chat_response_data``
        (PR #804): ``reasoning > message > function_call``. The first
        non-empty source wins; the others are dropped from this single
        ``ParsedResponse``. The full structured ``output[]`` is still
        captured by ``build_assistant_turn`` for fork-mode replay.

        Falls back to the top-level ``output_text`` convenience field when
        ``output[]`` is absent.

        Args:
            json_obj: Deserialized response JSON

        Returns:
            Extracted response data or None if no content found
        """
        output = json_obj.get("output")
        if isinstance(output, list):
            text_parts: list[str] = []
            reasoning_parts: list[str] = []
            tool_call_parts: list[str] = []
            for item in output:
                if isinstance(item, dict):
                    self._collect_output_item(
                        item, text_parts, reasoning_parts, tool_call_parts
                    )

            if reasoning_parts:
                return ReasoningResponseData(
                    content="".join(text_parts) or None,
                    reasoning="".join(reasoning_parts),
                )
            if text_parts:
                return TextResponseData(text="".join(text_parts))
            if tool_call_parts:
                return ToolCallResponseData(
                    tool_call_text="".join(tool_call_parts),
                    content=None,
                )

        # Fallback: top-level output_text convenience field
        output_text = json_obj.get("output_text")
        if isinstance(output_text, str) and output_text:
            return TextResponseData(text=output_text)

        return None

    @staticmethod
    def _collect_output_item(
        item: dict[str, Any],
        text_parts: list[str],
        reasoning_parts: list[str],
        tool_call_parts: list[str],
    ) -> None:
        """Append model-generated tokens from one ``output[]`` item to the
        appropriate accumulator. Unknown item types are silently ignored.
        """
        item_type = item.get("type")
        if item_type == "reasoning":
            ResponsesEndpoint._collect_reasoning(item, reasoning_parts)
        elif item_type == "message":
            ResponsesEndpoint._collect_message_content(item, text_parts)
        elif item_type == "function_call":
            ResponsesEndpoint._collect_function_call(item, tool_call_parts)

    @staticmethod
    def _collect_reasoning(item: dict[str, Any], reasoning_parts: list[str]) -> None:
        """Append a reasoning item's text: its ``reasoning_text`` content parts,
        else its ``summary_text`` parts.

        ``reasoning_text`` is the full reasoning, matching the streaming
        ``response.reasoning_text.delta`` events; servers such as vLLM serving
        gpt-oss return it with an empty ``summary``. A summary condenses the
        same reasoning, so taking both would count it twice.
        """
        reasoning_parts.extend(
            ResponsesEndpoint._part_texts(item.get("content"), "reasoning_text")
            or ResponsesEndpoint._part_texts(item.get("summary"), "summary_text")
        )

    @staticmethod
    def _part_texts(parts: Any, part_type: str) -> list[str]:
        if not isinstance(parts, list):
            return []
        return [
            part["text"]
            for part in parts
            if isinstance(part, dict)
            and part.get("type") == part_type
            and isinstance(part.get("text"), str)
            and part["text"]
        ]

    @staticmethod
    def _collect_message_content(item: dict[str, Any], text_parts: list[str]) -> None:
        """Append non-empty ``output_text`` strings from a message item."""
        content = item.get("content")
        if not isinstance(content, list):
            return
        for part in content:
            if isinstance(part, dict) and part.get("type") == "output_text":
                text = part.get("text")
                if text:
                    text_parts.append(text)

    @staticmethod
    def _collect_function_call(
        item: dict[str, Any], tool_call_parts: list[str]
    ) -> None:
        """Append ``name`` and ``arguments`` strings from a function_call item."""
        name = item.get("name")
        if isinstance(name, str) and name:
            tool_call_parts.append(name)
        arguments = item.get("arguments")
        if isinstance(arguments, str) and arguments:
            tool_call_parts.append(arguments)

    def build_assistant_turn(self, record: RequestRecord) -> Turn | None:
        """Capture every output item — message, function_call,
        web_search_call, image_generation_call, reasoning, etc. — for
        FORK-replay. See ``_openai_responses_replay`` for the assembly
        logic and the rationale for the dedup-by-id union of
        ``response.completed.response.output[]`` and
        ``response.output_item.done`` events.

        Falls back to the base text-only behaviour when no items are
        recoverable, so callers without tool-using workloads see no change.
        """
        items_by_key: dict[str, dict[str, Any]] = {}
        done_items: list[dict[str, Any]] = []

        for response in record.responses:
            json_obj = response.get_json()
            if not json_obj:
                continue
            if _replay.is_failure_event(json_obj):
                return super().build_assistant_turn(record)
            _replay.collect_response_items(json_obj, items_by_key, done_items)

        for item in done_items:
            _replay.merge_item(items_by_key, item)

        if not items_by_key:
            return super().build_assistant_turn(record)

        return Turn(role="assistant", raw_messages=list(items_by_key.values()))
