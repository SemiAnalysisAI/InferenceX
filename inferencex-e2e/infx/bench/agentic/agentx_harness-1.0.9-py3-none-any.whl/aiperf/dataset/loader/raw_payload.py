# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
"""Raw payload JSONL loader for verbatim API replay.

Each JSONL line is a complete API request body sent directly to the transport
with zero formatting. Produces raw_payload on every turn for payload mmap bypass.

Supports two input modes:
- **Single file**: each line = one single-turn conversation.
- **Directory**: each ``.jsonl`` file = one multi-turn conversation, lines = turns.
"""

from __future__ import annotations

from collections import defaultdict
from pathlib import Path

import orjson

from aiperf.common.enums import ConversationContextMode
from aiperf.common.models import Conversation, Turn
from aiperf.dataset.loader.base_loader import BaseRawPayloadLoader, LoaderProbeData
from aiperf.dataset.loader.models import RawPayload
from aiperf.dataset.loader.speed_bench import is_speed_bench_row


class RawPayloadDatasetLoader(BaseRawPayloadLoader):
    """Dataset loader for raw payload JSONL files or directories.

    **Single file mode**: each line in the JSONL file is a complete API request
    payload (a JSON object containing at minimum a ``messages`` key). Each line
    becomes a single-turn conversation.

    **Directory mode**: each ``.jsonl`` file in the directory is one multi-turn
    conversation. Lines within a file are ordered turns. The filename (stem) is
    used as the session ID.

    Every Turn carries ``raw_payload`` -- the transport sends it verbatim
    without any endpoint formatting.
    """

    @classmethod
    def can_load(
        cls, data: LoaderProbeData | None = None, filename: str | Path | None = None
    ) -> bool:
        """Return True when data is a chat API payload or filename is a directory of JSONL files.

        Rejects agentic trajectory records (``conversation_id`` present),
        declared Mooncake response modes, and InputsFile structures (``data``
        key holding a list).
        """
        if data is not None:
            # Type-dispatch plugins feed arbitrary first-record shapes here;
            # guard against non-dict inputs (list, string, scalar) so
            # auto-detection falls through cleanly instead of AttributeError.
            if not isinstance(data, dict):
                return False
            if is_speed_bench_row(data):
                return False
            # Mooncake must report invalid modes instead of replaying trace
            # metadata as an API payload and discarding session semantics.
            if "assistant_responses" in data or "message_mode" in data:
                return False
            if not isinstance(data.get("messages"), list):
                return False
            if "conversation_id" in data:
                return False
            return not isinstance(data.get("data"), list)

        if filename is not None:
            path = Path(filename)
            if path.is_dir():
                return _dir_has_raw_payload_jsonl(path)

        return False

    def load_dataset(self) -> dict[str, list[RawPayload]]:
        """Load from a single JSONL file or a directory of JSONL files.

        - Single file: each line -> one session (single-turn).
        - Directory: each .jsonl file -> one session (multi-turn, lines = turns).

        Returns:
            Dictionary of session_id -> list[RawPayload].
        """
        path = Path(self.filename)
        if path.is_dir():
            return self._load_directory(path)
        return self._load_single_file(path)

    def _load_single_file(self, path: Path) -> dict[str, list[RawPayload]]:
        data: dict[str, list[RawPayload]] = defaultdict(list)
        with open(path, "rb") as f:
            for lineno, raw_line in enumerate(f, start=1):
                line = raw_line.strip()
                if not line:
                    continue
                payload = orjson.loads(line)
                _validate_payload_shape(path, lineno, payload)
                session_id = self.session_id_generator.next()
                data[session_id].append(RawPayload(payload=payload))

        self.info(f"Loaded {len(data)} raw payload conversations from file")
        return dict(data)

    def _load_directory(self, directory: Path) -> dict[str, list[RawPayload]]:
        data: dict[str, list[RawPayload]] = {}
        total_turns = 0

        for jsonl_file in sorted(directory.glob("*.jsonl")):
            session_id = self.session_id_generator.next()
            payloads: list[RawPayload] = []
            with open(jsonl_file, "rb") as f:
                for lineno, raw_line in enumerate(f, start=1):
                    line = raw_line.strip()
                    if not line:
                        continue
                    payload = orjson.loads(line)
                    _validate_payload_shape(jsonl_file, lineno, payload)
                    payloads.append(RawPayload(payload=payload))

            if payloads:
                data[session_id] = payloads
                total_turns += len(payloads)

        self.info(
            f"Loaded {len(data)} conversations ({total_turns} total turns) "
            f"from directory"
        )
        return data

    def convert_to_conversations(
        self, data: dict[str, list[RawPayload]]
    ) -> list[Conversation]:
        """Convert RawPayload entries to Conversations with raw_payload turns.

        Args:
            data: Dictionary of session_id -> [RawPayload].

        Returns:
            List of Conversations.
        """
        conversations: list[Conversation] = []
        for session_id, payloads in data.items():
            turns = [Turn(role="user", raw_payload=rp.payload) for rp in payloads]
            conversations.append(
                Conversation(
                    session_id=session_id,
                    turns=turns,
                    context_mode=ConversationContextMode.MESSAGE_ARRAY_WITH_RESPONSES,
                )
            )
        return conversations


def _dir_has_raw_payload_jsonl(directory: Path) -> bool:
    """Check if a directory contains at least one JSONL file with a raw payload line."""
    for jsonl_file in directory.glob("*.jsonl"):
        try:
            with open(jsonl_file, "rb") as f:
                for raw_line in f:
                    line = raw_line.strip()
                    if not line:
                        continue
                    record = orjson.loads(line)
                    return isinstance(record, dict) and isinstance(
                        record.get("messages"), list
                    )
        except ValueError:
            # Narrow: only malformed JSON is skipped (orjson.JSONDecodeError is a
            # ValueError subclass). OSError/PermissionError
            # from an unreadable file must propagate so can_load fails loud
            # instead of silently misclassifying the directory.
            continue
    return False


def _validate_payload_shape(path: Path, lineno: int, payload: object) -> None:
    """Reject raw_payload lines that don't carry a ``messages`` array.

    Without this, a stray JSON line like ``{"model": "x"}`` loads silently
    and the failure only surfaces as an opaque server-side 4xx mid-run.
    Fail at load time with the offending file + line so authoring
    mistakes are caught before any wire request is issued.
    """
    if not isinstance(payload, dict):
        raise ValueError(
            f"{path}:{lineno}: raw_payload line must be a JSON object, "
            f"got {type(payload).__name__}"
        )
    messages = payload.get("messages")
    if not isinstance(messages, list):
        raise ValueError(
            f"{path}:{lineno}: raw_payload line missing required 'messages' "
            f"array (got {type(messages).__name__})"
        )
