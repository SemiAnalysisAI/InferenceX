# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

import os
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from aiperf.common import random_generator as rng
from aiperf.common.enums import PromptCorpus, RandomCorpusStyle
from aiperf.common.exceptions import (
    ConfigurationError,
    InvalidStateError,
    NotInitializedError,
)
from aiperf.common.hash_id_random_generator import HashIdRandomGenerator
from aiperf.common.tokenizer import Tokenizer
from aiperf.config.dataset.content import PrefixPromptConfig, PromptConfig
from aiperf.config.dataset.defaults import InputTokensDefaults
from aiperf.dataset.generator.base import BaseGenerator

DEFAULT_CORPUS_FILE = "assets/shakespeare.txt"


def sample_tokens_from_corpus(
    corpus,
    num_tokens: int,
    rng_to_use,
    sep_token: int | None = None,
) -> list[int]:
    """Sample ``num_tokens`` tokens from ``corpus`` using ``rng_to_use``.

    Mirrors :meth:`PromptGenerator._sample_tokens` but takes the RNG explicitly,
    so callers (worker processes, the hash-id reseed path) can drive sampling
    without sharing PromptGenerator state. Wraps the slice if it overflows the
    corpus end so the result is always exactly ``num_tokens`` long.

    Args:
        corpus: Token corpus as a sequence of token IDs.
        num_tokens: Number of tokens to sample.
        rng_to_use: Random generator with a ``randrange(n)`` method.
        sep_token: Optional block-separation token prepended at index 0
            (consumes one slot of ``num_tokens``).

    Returns:
        List of sampled token IDs of length ``num_tokens``.
    """
    corpus_len = len(corpus)
    tokens: list[int] = []

    if sep_token is not None:
        tokens.append(sep_token)
        num_tokens -= 1

    start = rng_to_use.randrange(corpus_len)
    end = start + num_tokens

    if end <= corpus_len:
        tokens.extend(corpus[start:end])
    else:
        tokens.extend(corpus[start:])
        tokens.extend(corpus[: end - corpus_len])

    return tokens


class PromptGenerator(BaseGenerator):
    """A class for generating synthetic prompts from a text corpus.

    This class loads a text corpus (e.g., Shakespearean text), tokenizes it,
    and uses the tokenized corpus to generate synthetic prompts of specified
    lengths. It supports generating prompts with a target number of tokens
    (with optional randomization around a mean and standard deviation) and
    can reuse previously generated token blocks to optimize generation for
    certain use cases. It also allows for the creation of a pool of prefix
    prompts that can be randomly selected.
    """

    def __init__(
        self,
        *,
        prompts: PromptConfig | None,
        prefix_prompts: PrefixPromptConfig | None,
        tokenizer: Tokenizer,
        corpus: PromptCorpus = PromptCorpus.SONNET,
        corpus_style: RandomCorpusStyle = RandomCorpusStyle.VLLM,
        **kwargs,
    ):
        self.prompts = prompts
        self.prefix_prompts = prefix_prompts
        self.tokenizer = tokenizer
        self._corpus = corpus
        self._corpus_style = corpus_style
        self._tokenized_corpus = None
        self._corpus_size = 0
        self._allowed_tokens: list[int] = []
        self._random_request_index: int = 0
        self._prefix_prompts: list[str] = []
        self._topup_tokens: list[int] = []
        self._warned_offsets_exhausted = False
        self._prefix_prompt_tokens: list[list[int]] = []

        # Conversation context prompts
        self._shared_system_prompt: str | None = None
        self._user_context_prompts: list[str] = []

        # Separate RNGs for independent concerns
        self._length_rng = rng.derive("dataset.prompt.length")
        self._corpus_rng = rng.derive("dataset.prompt.corpus")
        self._prefix_rng = rng.derive("dataset.prompt.prefix")

        # Hash-ID-based RNG for deterministic per-(trace_id, hash_id) sampling.
        # Used by the WekaTraceLoader so cross-process replay scopes block
        # content to a single trace_id, eliminating cross-trace cache collisions.
        self._hash_id_corpus_rng = HashIdRandomGenerator.from_base_rng(self._corpus_rng)

        super().__init__(tokenizer=tokenizer, **kwargs)

        # Cached prompts: block ID -> list of tokens
        self._cache: dict[int, list[int]] = {}

        # Decoded string cache: (hash_ids tuple, num_tokens, block_size) -> decoded string
        # This avoids redundant tokenizer.decode() calls for repeated hash_id combinations
        self._decoded_cache: dict[tuple[tuple[int, ...], int, int], str] = {}

        # TODO: move this under initialize() method
        # Initialize corpus if not already done
        if self._tokenized_corpus is None:
            self._initialize_corpus()

        if self._corpus == PromptCorpus.RANDOM:
            self._build_allowed_tokens()

        # Probe the tokenizer for a BPE-stable terminator we can append to
        # every reconstructed segment so aiperf's join-with-" " ISL formula
        # equals the sum of per-segment token counts (eliminates segment-join
        # BPE re-merge drift). See spec §6.2.
        self._bpe_stable_terminator_tokens: list[int] = (
            self._determine_bpe_stable_terminator()
        )

        # The prefix prompt pool is NOT built here. vLLM's RandomDataset draws its
        # prefix from the shared generator immediately after get_sampling_params has
        # drawn ISLs, OSLs and offsets, so the pool has to observe that same stream
        # position — which only exists after preseed(). Callers invoke
        # initialize_prefix_pool() once the generator is seeded.

        # Initialize shared context prompts if configured
        shared_system_length = (
            self.prefix_prompts.shared_system_length
            if self.prefix_prompts is not None
            else None
        )
        if shared_system_length is not None:
            self._generate_shared_system_prompt()
        # Note: User context prompts are generated on-demand in generate_user_context_prompt()

    def _build_allowed_tokens(self) -> None:
        """Build the list of token IDs for random vocab sampling.

        Token pool composition is controlled by corpus_style:
        - VLLM: exclude special tokens via valid_token_ids, matching vLLM's
          ``all_special_ids`` exclusion in RandomDataset.
        - SGLANG: use all_token_ids (full vocab range without special-token
          filtering), matching SGLang's ``% vocab_size`` arithmetic which uses
          the raw vocab_size as modulus and does not exclude special tokens.
        """
        if self._corpus_style == RandomCorpusStyle.VLLM:
            self._allowed_tokens = self.tokenizer.valid_token_ids
        else:
            self._allowed_tokens = self.tokenizer.all_token_ids

        # Separate, wider pool for BPE top-up draws. vLLM's
        # gen_prompt_decode_to_target_len tops up from the full
        # [0, vocab_size) range without excluding special tokens, so the
        # narrower VLLM-style _allowed_tokens would be the wrong pool here.
        #
        # Byte parity: for HF tokenizers all_token_ids IS list(range(vocab_size)),
        # so indexing into it is bit-for-bit identical to drawing raw
        # [0, vocab_size) -- same bound, same value. For tiktoken the two differ
        # (cl100k_base: 100261 decodable vs vocab_size 100277) and the raw draw
        # could return a gap ID that raises KeyError on decode.
        self._topup_tokens = self.tokenizer.all_token_ids
        self.debug(
            lambda: (
                f"Built random vocab corpus with {len(self._allowed_tokens)} allowed tokens "
                f"({len(self._topup_tokens)} in the top-up pool)"
            )
        )

    def _sample_topup_tokens(self, num_tokens: int) -> list[int]:
        """Sample tokens for BPE top-up without consuming the preseed offset cache.

        Top-up draws happen inside the retry loop of generate_prompt when
        re-encoding produces fewer tokens than the target. They must not
        advance _random_request_index (which would shift the arithmetic-sequence
        index for all subsequent requests) and must not consume preseed cache
        entries (one cache entry per request, not per retry).

        When preseed is active, draws from the same generator stream used for
        ISL/OSL/offset draws (matching vLLM's gen_prompt_decode_to_target_len
        which uses its single shared rng for top-up). Falls back to
        _corpus_rng when preseed is not in use.
        """
        if self._corpus == PromptCorpus.RANDOM:
            # vLLM bench passes rng=self._rng (the shared seeded generator) to
            # gen_prompt_decode_to_target_len, drawing top-up tokens from the
            # same stream as ISL/OSL/offsets over the full vocab.
            #
            # Indexed into _topup_tokens rather than emitted as raw draws so
            # sparse-vocabulary tokenizers cannot yield an undecodable ID. This
            # is a no-op for HF tokenizers, where the pool is exactly
            # range(vocab_size) -- same bound, same values, byte-identical
            # prompts. See _build_allowed_tokens.
            pool = self._topup_tokens or self._allowed_tokens
            generator = getattr(self, "_preseed_rng", None) or self._corpus_rng
            return [
                pool[int(i)]
                for i in generator.integers(0, len(pool), size=num_tokens)  # type: ignore[union-attr]
            ]
        return self._sample_tokens(num_tokens)

    def preseed(self, n: int, generator: object) -> None:
        """Pre-generate all offsets for the RANDOM corpus using vLLM's draw order.

        Must be called after :meth:`_build_allowed_tokens`. ``generator`` should
        be the same numpy Generator passed to
        :meth:`RangeRatioDistribution.preseed`, advanced past its ISL/OSL draws,
        so that offsets are drawn from the correct position in the shared stream.

        The generator is retained as ``_preseed_rng`` so that BPE top-up draws
        in :meth:`_sample_topup_tokens` continue from the same stream, matching
        vLLM's ``gen_prompt_decode_to_target_len`` which uses its single shared
        rng for both the initial sequence and any top-up tokens.

        """
        # vLLM bench draws offsets from [0, tokenizer.vocab_size), not from
        # [0, len(allowed_tokens)). Using vocab_size as the draw bound matches
        # vLLM bench's get_sampling_params and produces the same offset values
        # for the same seed, giving identical prompts.
        vocab_size = (
            self.tokenizer.vocab_size
            if self.tokenizer is not None
            else len(self._allowed_tokens)
        )
        self._offset_cache: list[int] = generator.integers(
            0, vocab_size, size=n
        ).tolist()  # type: ignore[union-attr]
        self._offset_idx: int = 0
        self._preseed_rng = generator

    def _initialize_corpus(self) -> None:
        """Load and tokenize the corpus once, storing it for reuse.

        No-op when corpus is RANDOM — token IDs are drawn directly from the
        vocabulary without loading a text file.

        Uses character-based chunking for reproducibility across different machines.
        The chunk size is fixed (not CPU-dependent) to ensure the same tokenization
        boundaries regardless of hardware, which guarantees identical prompts with
        the same random seed across all environments.

        Thread Safety Note:
            This method uses parallel tokenization for performance. Most tokenizers
            (including Hugging Face transformers) are thread-safe and deterministic.
            Thread count doesn't affect reproducibility since chunks have deterministic
            boundaries based on character count.
        """
        if self._corpus == PromptCorpus.RANDOM:
            return

        corpus_path = Path(__file__).parent / DEFAULT_CORPUS_FILE

        with open(corpus_path, encoding="utf-8") as f:
            lines = f.readlines()

        # Pre-filter empty lines for efficiency
        non_empty_lines = [line.strip() for line in lines if line.strip()]

        def tokenize_chunk(chunk):
            """Tokenize a chunk of pre-cleaned lines."""
            text = " ".join(chunk)
            tokens = self.tokenizer.encode(text)
            return tokens

        # Character-based chunking: Fixed chunk size ensures reproducibility
        # across machines with different CPU counts. Creates ~486 chunks for
        # optimal thread utilization (~294 lines per chunk).
        MAX_CHARS_PER_CHUNK = 10_000

        # Build chunks based on character count (deterministic chunking)
        chunks = []
        buffer = []
        char_count = 0

        for line in non_empty_lines:
            buffer.append(line)
            char_count += len(line)

            if char_count >= MAX_CHARS_PER_CHUNK:
                chunks.append(buffer)
                buffer = []
                char_count = 0

        # Add remaining lines as final chunk
        if buffer:
            chunks.append(buffer)

        # Multi-threaded tokenization: thread count doesn't affect reproducibility
        # since chunks are character-based (deterministic boundaries)
        num_threads = min(os.cpu_count() or 4, 8)
        with ThreadPoolExecutor(max_workers=num_threads) as executor:
            tokenized_chunks = list(executor.map(tokenize_chunk, chunks))

        self._tokenized_corpus = [
            token for chunk in tokenized_chunks for token in chunk
        ]
        self._corpus_size = len(self._tokenized_corpus)
        self.debug(
            lambda: (
                f"Initialized corpus with {self._corpus_size} tokens "
                f"from {len(chunks)} chunks using {num_threads} thread(s)"
            )
        )

    def _determine_bpe_stable_terminator(self) -> list[int]:
        """Probe the tokenizer for a short token sequence that, when appended
        to arbitrary content and followed by ``" " + arbitrary content``, does
        NOT cause BPE re-merging across the seam.

        Tries candidates in order and returns the first that passes the
        join-byte-exact probe:

        1. ``"\\n\\n"`` (typically a singleton in modern tokenizers)
        2. ``"\\n"`` (fallback)
        3. ``" "`` (last resort — degenerate)

        Returns an empty list if no candidate passes; segment synthesis then
        falls back to no terminator and segment-join drift is unfixed.
        """
        if not self._tokenized_corpus:
            return []
        corpus_size = self._corpus_size
        if corpus_size < 264:
            return []

        a = self.tokenizer.decode(self._tokenized_corpus[100:164])
        b = self.tokenizer.decode(self._tokenized_corpus[200:264])

        a_tokens = self.tokenizer.encode(a, add_special_tokens=False)
        b_with_lead_space = self.tokenizer.encode(" " + b, add_special_tokens=False)

        for cand_text in ("\n\n", "\n", " "):
            cand_tokens = self.tokenizer.encode(cand_text, add_special_tokens=False)
            if len(cand_tokens) == 0:
                continue
            joined = a + cand_text + " " + b
            joined_tokens = self.tokenizer.encode(joined, add_special_tokens=False)
            expected_total = len(a_tokens) + len(cand_tokens) + len(b_with_lead_space)
            if len(joined_tokens) == expected_total:
                self.debug(
                    lambda ct=cand_text, t=cand_tokens: (
                        f"BPE-stable terminator chosen: {ct!r} -> tokens={t}"
                    )
                )
                return list(cand_tokens)

        self.debug("No BPE-stable terminator found; segment-join drift will be unfixed")
        return []

    def initialize_prefix_pool(self) -> None:
        """Build the pool of prefix prompts, as token IDs and decoded text.

        Must be called after :meth:`preseed` for the RANDOM corpus so the prefix
        draws land at vLLM's stream position (after ISLs, OSLs and offsets). A
        no-op when no pool is configured, so callers can invoke it unconditionally.
        """
        if self.prefix_prompts is None:
            return

        length = self.prefix_prompts.length or 0
        pool_size = self.prefix_prompts.pool_size or 0
        if pool_size <= 0:
            return

        if self._tokenized_corpus is None and self._corpus != PromptCorpus.RANDOM:
            raise NotInitializedError("Tokenized corpus is not initialized.")

        if length <= 0:
            self._prefix_prompt_tokens = [[] for _ in range(pool_size)]
            self._prefix_prompts = [""] * pool_size
            return

        self._prefix_prompt_tokens = [
            self._create_prefix_tokens(length) for _ in range(pool_size)
        ]
        self._prefix_prompts = [
            self.tokenizer.decode(tokens) for tokens in self._prefix_prompt_tokens
        ]
        self.debug(
            lambda: (
                f"Initialized prefix prompts pool with {len(self._prefix_prompts)} prompts"
            )
        )

    def _create_prefix_tokens(self, length: int) -> list[int]:
        """Draw and length-correct a single prefix, returning its token IDs.

        Mirrors vLLM's ``RandomDataset.get_prefix``: the draw is bounded by
        ``len(allowed_tokens)`` (NOT vocab_size, which bounds the offset draws)
        and comes from the shared preseed stream. Deliberately avoids
        :meth:`_sample_tokens` for the RANDOM corpus — that would advance
        ``_random_request_index`` and shift every subsequent request body away
        from vLLM's ``index=i`` sequence.
        """
        if self._corpus == PromptCorpus.RANDOM:
            generator = getattr(self, "_preseed_rng", None) or self._corpus_rng
            n = len(self._allowed_tokens)
            tokens = [
                self._allowed_tokens[int(i)]
                for i in generator.integers(0, n, size=length)
            ]
        else:
            tokens = self._sample_tokens(length)

        text = self._decode_to_exact_len(tokens, length)
        return self.tokenizer.encode(text, add_special_tokens=False)

    def generate(
        self,
        mean: int | None = None,
        stddev: int | None = None,
        hash_ids: list[int] | None = None,
        *,
        with_prefix: bool = False,
        exact_length: bool = False,
    ) -> str:
        """Generate a synthetic prompt with the configuration parameters.
        Serves as a wrapper around other internal methods to provide a unified interface.

        Args:
            mean: The mean of the normal distribution.
            stddev: The standard deviation of the normal distribution.
            hash_ids: A list of hash indices used for token reuse.
            with_prefix: Prepend a pooled prefix prompt at the token level. Ignored
                when hash_ids is set, since that path composes its own blocks.
            exact_length: Treat ``mean`` as an already-decided length and use it
                verbatim instead of resampling. Set by callers driving a
                sequence distribution, which has already produced an exact
                value; routing that through ``calculate_num_tokens`` would floor
                a legitimately-sampled 0 up to 1 and emit one more token than
                the reference implementation.

        Returns:
            A synthetic prompt as a string.
        """
        if hash_ids:
            if mean is None:
                raise ValueError("mean must be provided when hash_ids is set.")
            block_size = (
                self.prompts.block_size if self.prompts is not None else None
            ) or InputTokensDefaults.BLOCK_SIZE
            return self._generate_cached_prompt(mean, hash_ids, block_size)

        num_tokens = (
            int(mean or 0) if exact_length else self.calculate_num_tokens(mean, stddev)
        )
        prefix_tokens = self.get_random_prefix_prompt_tokens() if with_prefix else None
        return self.generate_prompt(num_tokens, prefix_tokens=prefix_tokens)

    def calculate_num_tokens(
        self,
        mean: int | None = None,
        stddev: int | None = None,
    ) -> int:
        """Calculate the number of tokens for a prompt based on a normal distribution.

        Args:
            mean: The mean of the normal distribution.
            stddev: The standard deviation of the normal distribution.
        """

        return self._length_rng.sample_positive_normal_integer(mean, stddev)

    def _decode_to_exact_len(
        self, tokens: list[int], target: int, *, _max_retries: int = 10
    ) -> str:
        """Decode `tokens` to text whose re-encoded length is exactly `target`.

        Decodes, re-encodes to verify the round-trip token count, and trims or
        tops up until the count matches, up to `_max_retries` times. Matches
        vLLM bench's ``gen_prompt_decode_to_target_len`` contract.

        Args:
            tokens: Initial token sequence to decode.
            target: Required token count of the re-encoded result.
            _max_retries: Maximum adjustment iterations before accepting mismatch.

        Returns:
            The decoded prompt text.
        """
        for _ in range(_max_retries):
            text = self.tokenizer.decode(tokens)
            # Re-assign tokens from the re-encoded result, matching vLLM bench's
            # gen_prompt_decode_to_target_len which reassigns token_sequence after
            # encode before trimming or extending. Trimming the re-encoded sequence
            # (not the original) is what produces identical prompts for the same seed.
            tokens = self.tokenizer.encode(text, add_special_tokens=False)
            if len(tokens) == target:
                return text
            if len(tokens) > target:
                tokens = tokens[:target]
            else:
                tokens = tokens + self._sample_topup_tokens(target - len(tokens))
        return self.tokenizer.decode(tokens)

    def generate_prompt(
        self,
        num_tokens: int,
        *,
        _max_retries: int = 10,
        prefix_tokens: list[int] | None = None,
    ) -> str:
        """Generate a prompt whose re-encoded length matches `num_tokens`.

        When `prefix_tokens` is supplied it is concatenated at the TOKEN-ID level
        and the combined sequence is corrected once to ``len(prefix_tokens) +
        num_tokens``, matching vLLM's ``generate_token_sequence``. Joining the
        decoded segments as strings instead would let BPE charge for the seam,
        which cost ~0.84 extra tokens per request (AIP-1118).

        Args:
            num_tokens: Target number of body tokens in the final prompt.
            _max_retries: Maximum adjustment iterations before accepting mismatch.
            prefix_tokens: Prefix token IDs to prepend, or None for no prefix.

        Returns:
            A synthetic prompt as a string.
        """
        if num_tokens < 0 or (num_tokens == 0 and not prefix_tokens):
            raise ValueError(
                f"num_tokens must be > 0 without a prefix, got {num_tokens}"
            )
        tokens = self._sample_tokens(num_tokens)
        target = num_tokens
        if prefix_tokens:
            tokens = list(prefix_tokens) + tokens
            target += len(prefix_tokens)
        return self._decode_to_exact_len(tokens, target, _max_retries=_max_retries)

    def _generate_cached_prompt(
        self,
        num_tokens: int,
        hash_ids: list[int],
        block_size: int,
    ) -> str:
        """
        Generate a prompt containing exactly `num_tokens` by reusing previously generated prompts
        stored in `_cache`. Each hash index in `hash_ids` corresponds to a block of
        `block_size` tokens. If a hash index is found in `_cache`, its stored prompt is reused.
        Otherwise, a new prompt is generated using `generate_prompt()` and stored in `_cache`.

        Args:
            num_tokens: The number of tokens required in the prompt.
            hash_ids: A list of hash IDs to use for token reuse.
            block_size: The number of tokens allocated per hash block.

        Returns:
            str: A synthetic prompt as a string.

        Raises:
            ConfigurationError: If the input parameters are not compatible.
        """
        final_prompt = self._build_token_sequence(num_tokens, hash_ids, block_size)
        return self.tokenizer.decode(final_prompt)

    def _build_token_sequence(
        self,
        num_tokens: int,
        hash_ids: list[int],
        block_size: int,
    ) -> list[int]:
        """
        Build a token sequence without decoding. Used for batch parallel decode.

        Each hash index in `hash_ids` corresponds to a block of `block_size` tokens.
        If a hash index is found in `_cache`, its stored tokens are reused.
        Otherwise, new tokens are sampled and stored in `_cache`.

        Three layouts are supported, matching how upstream trace formats record
        cache structure:

        - **Exact tile** (``len(hash_ids) * block_size == num_tokens``): every
          hash is a full block.
        - **Last block partial** (``(M-1)*block_size < num_tokens < M*block_size``):
          synthetic prompts authored by AIPerf — the final hash maps to a
          partial block of size ``num_tokens - (M-1)*block_size``.
        - **Prefix only** (``M*block_size < num_tokens``): real
          captured traces (e.g. weka kv-cache-tester) where ``hash_ids`` lists
          only the cached prefix and the un-hashed tail represents fresh
          tokens. The tail is padded with sampled (uncached) tokens.

        Args:
            num_tokens: The number of tokens required in the prompt.
            hash_ids: A list of hash IDs covering the cached prefix.
            block_size: The number of tokens allocated per hash block.

        Returns:
            list[int]: A list of token IDs of length ``num_tokens``.

        Raises:
            ConfigurationError: If ``num_tokens <= 0`` or ``block_size <= 0``,
                or if hash_ids overshoots and the implied partial block size is
                outside ``(0, block_size]``.
        """
        if num_tokens <= 0 or block_size <= 0:
            raise ConfigurationError(
                f"Input length: {num_tokens}, Hash IDs: {hash_ids}, "
                f"Block size: {block_size} are not compatible. num_tokens "
                f"and block_size must both be greater than 0."
            )

        m = len(hash_ids)
        total_hashed = m * block_size
        final_prompt: list[int] = []

        if not hash_ids:
            return self._sample_tokens(num_tokens)

        if total_hashed > num_tokens:
            # Synthetic-prompt path: last hash is a partial block.
            final_block_size = num_tokens - ((m - 1) * block_size)
            if final_block_size <= 0 or final_block_size > block_size:
                raise ConfigurationError(
                    f"Input length: {num_tokens}, Hash IDs: {hash_ids}, "
                    f"Block size: {block_size} are not compatible. The final "
                    f"hash block size: {final_block_size} must be greater than "
                    f"0 and less than or equal to {block_size}."
                )
        else:
            # Exact-tile or prefix-only path: every hash is a full block.
            final_block_size = block_size

        for index, hash_id in enumerate(hash_ids):
            current_block_size = final_block_size if index == m - 1 else block_size
            cached = self._cache.get(hash_id)
            if cached is None:
                # Reseed per-(trace_id, hash_id) so the same hash_id in a
                # different trace file (different trace_id scope) produces
                # different tokens. Trace loaders set the trace_id once per
                # file in BaseTraceDatasetLoader.load_dataset and clear
                # ``self._cache`` between files.
                self._hash_id_corpus_rng.reseed_for_hash_id(hash_id)
                cached = sample_tokens_from_corpus(
                    self._tokenized_corpus,
                    current_block_size,
                    self._hash_id_corpus_rng,
                    self.tokenizer.block_separation_token_id,
                )
                self._cache[hash_id] = cached
            elif len(cached) != current_block_size:
                # A hash_id identifies a fixed block of content, so it can only
                # ever have one size. The same id at two sizes means a corrupt
                # trace or a block_size that disagrees with the recorded blocks.
                raise ConfigurationError(
                    f"hash_id {hash_id} requested at {current_block_size} tokens "
                    f"but was already materialized at {len(cached)} tokens. A "
                    f"hash_id must map to a single fixed block size; inconsistent "
                    f"sizes indicate a corrupt trace or a --isl-block-size that "
                    f"disagrees with the recorded blocks."
                )

            final_prompt.extend(cached)

        # Prefix-only: pad the un-hashed tail with sampled (uncached) tokens.
        tail = num_tokens - len(final_prompt)
        if tail > 0:
            final_prompt.extend(self._sample_tokens(tail))

        return final_prompt

    def _sample_tokens(self, num_tokens: int) -> list[int]:
        """Generate a list of token IDs containing exactly `num_tokens` number of tokens.

        For SONNET corpus: samples a contiguous window from the preloaded Shakespeare
        corpus starting at a random offset (wraps at end).

        For RANDOM corpus: samples a contiguous window from the sorted allowed-token
        list using (offset + request_index + j) % n, matching vLLM bench's
        RandomDataset strategy including the per-request index shift.

        Args:
            num_tokens: Number of tokens required in the prompt.

        Returns:
            A list of token IDs.

        Raises:
            NotInitializedError: If the relevant corpus is not initialized.
        """
        if self._corpus == PromptCorpus.RANDOM:
            if not self._allowed_tokens:
                raise NotInitializedError("Random vocab corpus is not initialized.")
            n = len(self._allowed_tokens)
            offset_cache = getattr(self, "_offset_cache", None)
            if offset_cache is not None and self._offset_idx < len(offset_cache):
                offset = offset_cache[self._offset_idx]
                self._offset_idx += 1
            else:
                # The cache holds one offset per conversation but is read once
                # per generate_prompt call, so multi-turn, --prompt-batch-size
                # > 1, prefix pools and user-context prompts all outrun it.
                # Degrade to a live draw rather than raising IndexError out of
                # the dataset composer; reference alignment is already lost.
                if offset_cache is not None and not self._warned_offsets_exhausted:
                    self._warned_offsets_exhausted = True
                    self.warning(
                        f"Preseeded offset cache exhausted after "
                        f"{len(offset_cache)} draws (sized by conversation "
                        "count, consumed once per prompt). Falling back to "
                        "live sampling; prompts past this point no longer "
                        "match the reference implementation for the same seed."
                    )
                offset = int(self._corpus_rng.integers(0, n))
            idx = self._random_request_index
            self._random_request_index += 1
            return [
                self._allowed_tokens[(offset + idx + j) % n] for j in range(num_tokens)
            ]

        if not self._tokenized_corpus:
            raise NotInitializedError("Tokenized corpus is not initialized.")
        if num_tokens > self._corpus_size:
            self.warning(
                f"Requested prompt length {num_tokens} is longer than the corpus. "
                f"Returning a prompt of length {self._corpus_size}."
            )

        start_idx = self._corpus_rng.randrange(self._corpus_size)

        end_idx = start_idx + num_tokens
        prompt_tokens = self._tokenized_corpus[start_idx:end_idx]
        if end_idx > self._corpus_size:
            prompt_tokens += self._tokenized_corpus[: end_idx - self._corpus_size]

        self.trace(lambda: f"Sampled {len(prompt_tokens)} tokens from corpus")
        return prompt_tokens

    def _random_prefix_index(self) -> int:
        """Pick a pool slot, raising when the pool was never initialized."""
        if not self._prefix_prompt_tokens:
            raise InvalidStateError(
                "Attempted to sample a prefix prompt but the prefix prompts pool is empty. "
                "Please ensure that initialize_prefix_pool() has been called."
            )
        return self._prefix_rng.choice(range(len(self._prefix_prompt_tokens)))

    def get_random_prefix_prompt(self) -> str:
        """
        Fetch a random prefix prompt from the pool.

        Returns:
            A random prefix prompt.

        Raises:
            InvalidStateError: If the prefix prompts pool is empty.
        """
        return self._prefix_prompts[self._random_prefix_index()]

    def get_random_prefix_prompt_tokens(self) -> list[int]:
        """
        Fetch the token IDs of a random prefix prompt from the pool.

        Preferred over :meth:`get_random_prefix_prompt` when the prefix is about
        to be joined to a body: concatenating token IDs avoids the BPE seam cost
        that string concatenation incurs.

        Returns:
            The token IDs of a random prefix prompt.

        Raises:
            InvalidStateError: If the prefix prompts pool is empty.
        """
        return self._prefix_prompt_tokens[self._random_prefix_index()]

    def _generate_shared_system_prompt(self) -> None:
        """Generate the shared system prompt.

        This prompt is generated once and is identical across all sessions.
        It appears as a system message in turn 0 of every conversation.
        """
        if self._tokenized_corpus is None and self._corpus != PromptCorpus.RANDOM:
            raise NotInitializedError("Tokenized corpus is not initialized.")

        length = (
            self.prefix_prompts.shared_system_length
            if self.prefix_prompts is not None
            else None
        )
        if length is None:
            return

        self._shared_system_prompt = self.generate_prompt(length)
        self.debug(lambda: f"Generated shared system prompt with {length} tokens")

    def get_shared_system_prompt(self) -> str:
        """Get the shared system prompt.

        Returns:
            The shared system prompt string.

        Raises:
            InvalidStateError: If shared system prompt is not initialized.
        """
        if self._shared_system_prompt is None:
            raise InvalidStateError(
                "Shared system prompt is not initialized. "
                "Ensure --shared-system-prompt-length is specified."
            )
        return self._shared_system_prompt

    def generate_user_context_prompt(self, session_index: int) -> str:
        """Generate unique user context for given session index.

        Generates prompts on-demand as needed. Each session_index gets a unique prompt.
        This allows benchmarks to run with any number of sessions without pre-allocating.

        Args:
            session_index: Sequential index of the session (0, 1, 2, ...).

        Returns:
            Unique user context prompt for this session.

        Raises:
            NotInitializedError: If tokenized corpus is not initialized.
            InvalidStateError: If user context prompt length is not configured.
        """
        if self._tokenized_corpus is None and self._corpus != PromptCorpus.RANDOM:
            raise NotInitializedError("Tokenized corpus is not initialized.")

        length = (
            self.prefix_prompts.user_context_length
            if self.prefix_prompts is not None
            else None
        )
        if length is None:
            raise InvalidStateError(
                "User context prompt length is not configured. "
                "Ensure --user-context-prompt-length is specified."
            )

        # Generate new prompts on-demand as needed
        while session_index >= len(self._user_context_prompts):
            new_prompt = self.generate_prompt(length)
            self._user_context_prompts.append(new_prompt)
            self.debug(
                lambda: (
                    f"Generated user context prompt #{len(self._user_context_prompts) - 1} "
                    f"for session {len(self._user_context_prompts) - 1}"
                )
            )

        return self._user_context_prompts[session_index]
