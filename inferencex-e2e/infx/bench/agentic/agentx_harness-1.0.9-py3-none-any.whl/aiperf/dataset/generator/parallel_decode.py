# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""Parallel decode utilities for batch tokenizer operations.

This module provides functions to decode multiple token sequences in parallel
using ProcessPoolExecutor, bypassing Python's GIL for CPU-bound tokenizer
operations.

The daemon flag on the current process is temporarily cleared because Python's
multiprocessing refuses to spawn children from daemon processes, and AIPerf
services run as daemons.
"""

import multiprocessing as mp
import os
from concurrent.futures import ProcessPoolExecutor
from typing import TYPE_CHECKING

from aiperf.common.utils import allow_daemon_children

if TYPE_CHECKING:
    from aiperf.common.tokenizer import Tokenizer

# Module-level tokenizer for worker processes (initialized once per worker)
_worker_tokenizer: "Tokenizer | None" = None
_worker_tokenizer_key: tuple[str, bool, str] | None = None


def _init_worker(
    tokenizer_name: str,
    trust_remote_code: bool = False,
    revision: str = "main",
) -> None:
    """Initialize tokenizer in worker process.

    This function is called once per worker process when the ProcessPoolExecutor
    starts. It loads the tokenizer so subsequent decode calls don't need to reload it.

    Args:
        tokenizer_name: Pre-resolved model name or local path. Must not be an
            unresolved alias — callers (e.g. BaseTraceLoader) are expected to
            resolve aliases before passing this value, because
            ``resolve_alias=False`` is used to avoid network calls in workers.
        trust_remote_code: Whether to trust remote code when loading.
        revision: The specific model version to use.
    """
    global _worker_tokenizer, _worker_tokenizer_key
    requested_key = (tokenizer_name, trust_remote_code, revision)
    if _worker_tokenizer is None or _worker_tokenizer_key != requested_key:
        # The main process already downloaded and cached the tokenizer, so force
        # offline mode to skip network requests and alias resolution.
        os.environ["HF_HUB_OFFLINE"] = "1"
        os.environ["TRANSFORMERS_OFFLINE"] = "1"

        from aiperf.common.tokenizer import Tokenizer

        _worker_tokenizer = Tokenizer.from_pretrained(
            tokenizer_name,
            trust_remote_code=trust_remote_code,
            revision=revision,
            resolve_alias=False,
        )
        _worker_tokenizer_key = requested_key


def _decode_tokens(token_ids: list[int]) -> str:
    """Decode tokens using worker's tokenizer.

    Args:
        token_ids: List of token IDs to decode.

    Returns:
        Decoded string.

    Raises:
        RuntimeError: If worker tokenizer is not initialized.
    """
    if _worker_tokenizer is None:
        raise RuntimeError("Worker tokenizer not initialized")
    return _worker_tokenizer.decode(token_ids)


def parallel_decode(
    token_sequences: list[list[int]],
    tokenizer_name: str,
    *,
    max_workers: int | None = None,
    chunksize: int = 50,
    trust_remote_code: bool = False,
    revision: str = "main",
) -> list[str]:
    """Decode multiple token sequences in parallel using ProcessPoolExecutor.

    This function is optimized for batch decoding of many token sequences.
    For small batches (< 10 sequences), it falls back to sequential decoding
    to avoid process spawn overhead.

    Args:
        token_sequences: List of token ID lists to decode.
        tokenizer_name: Pre-resolved model name or local path (alias resolution
            is skipped; callers must resolve aliases beforehand).
        max_workers: Number of worker processes. Defaults to min(cpu_count, 8).
        chunksize: Number of items per worker batch for map().
        trust_remote_code: Whether to trust remote code when loading.
        revision: The specific model version to use.

    Returns:
        List of decoded strings in the same order as input.
    """
    if not token_sequences:
        return []

    # For small batches, sequential is faster (avoid process overhead)
    if len(token_sequences) < 10:
        from aiperf.common.tokenizer import Tokenizer

        tokenizer = Tokenizer.from_pretrained(
            tokenizer_name,
            trust_remote_code=trust_remote_code,
            revision=revision,
            resolve_alias=False,
        )
        return [tokenizer.decode(tokens) for tokens in token_sequences]

    num_workers = max_workers or min(mp.cpu_count() or 4, 8)

    # ``allow_daemon_children`` clears the daemon flag so ProcessPoolExecutor
    # can spawn workers: Python refuses to spawn children from daemon processes,
    # and AIPerf services run as daemons.
    #
    # Alternatives considered:
    # - billiard: bypasses the daemon restriction natively, but crashes with
    #   BrokenProcessPool on macOS due to terminal FD inheritance issues.
    # - loky: robust reusable executor, but still requires the same daemon flag
    #   hack, so no advantage over stdlib.
    with (
        allow_daemon_children(),
        ProcessPoolExecutor(
            max_workers=num_workers,
            initializer=_init_worker,
            initargs=(tokenizer_name, trust_remote_code, revision),
        ) as executor,
    ):
        results = list(
            executor.map(_decode_tokens, token_sequences, chunksize=chunksize)
        )

    return results
