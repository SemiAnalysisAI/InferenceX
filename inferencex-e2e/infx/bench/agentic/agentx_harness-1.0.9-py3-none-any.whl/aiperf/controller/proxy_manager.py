# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0


from typing import TYPE_CHECKING

from aiperf.common.hooks import on_init, on_start, on_stop
from aiperf.common.mixins import AIPerfLifecycleMixin
from aiperf.plugin import plugins
from aiperf.plugin.enums import PluginType, ZMQProxyType

if TYPE_CHECKING:
    from aiperf.config.resolution.plan import BenchmarkRun


class ProxyManager(AIPerfLifecycleMixin):
    def __init__(
        self,
        run: "BenchmarkRun",
        **kwargs,
    ) -> None:
        super().__init__(run=run, **kwargs)
        self.run = run

    @on_init
    async def _initialize_proxies(self) -> None:
        comm_config = self.run.cfg.comm_config
        XPubXSubClass = plugins.get_class(PluginType.ZMQ_PROXY, ZMQProxyType.XPUB_XSUB)
        DealerRouterClass = plugins.get_class(
            PluginType.ZMQ_PROXY, ZMQProxyType.DEALER_ROUTER
        )
        PushPullClass = plugins.get_class(PluginType.ZMQ_PROXY, ZMQProxyType.PUSH_PULL)
        self.proxies = [
            XPubXSubClass(zmq_proxy_config=comm_config.event_bus_proxy_config),
            DealerRouterClass(
                zmq_proxy_config=comm_config.dataset_manager_proxy_config
            ),
            PushPullClass(zmq_proxy_config=comm_config.raw_inference_proxy_config),
        ]
        for proxy in self.proxies:
            await proxy.initialize()
        self.debug("All proxies initialized successfully")

    @on_start
    async def _start_proxies(self) -> None:
        self.debug("Starting all proxies")
        for proxy in self.proxies:
            await proxy.start()
        self.debug("All proxies started successfully")

    @on_stop
    async def _stop_proxies(self) -> None:
        self.debug("Stopping all proxies")
        for proxy in self.proxies:
            await proxy.stop()
        self.debug("All proxies stopped successfully")

        # Note: We intentionally do NOT call context.term() here because:
        #
        # 1. The context is a singleton shared by all ZMQ clients in this process
        # 2. zmq_ctx_term() blocks in C code waiting for all sockets to close
        # 3. Even if called in a thread, Python may wait for that thread on shutdown
        # 4. asyncio timeouts CANNOT interrupt blocking C code in threads
        # 5. This causes indefinite hangs
        #
        # Instead, we let the process handle cleanup:
        # - Normal completion: os._exit() forcefully cleans up (no ResourceWarnings)
        # - Exception path: May get ResourceWarning, but better than infinite hang
        # - The OS kernel reliably cleans up all resources on process exit
        #
        # This is the recommended approach per PyZMQ documentation for processes
        # that exit after completing work.
        self.debug("Proxy manager stopped (context cleanup delegated to process exit)")
