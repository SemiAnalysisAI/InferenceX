# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
"""Which CLI flags actually reach ``AIPerfConfig`` when ``--config`` is used.

``resolve_config`` merges a YAML base with explicitly-set CLI flags, but it
only knows how to route a subset of ``CLIConfig`` into the merged dict. Any
flag outside that subset used to be discarded without a word: a user running
``aiperf profile -f base.yaml --random-seed 42`` got a different seed than
they asked for and no diagnostic. For a benchmarking tool that silently
corrupts published numbers.

``CLIConfig`` is the source of truth, and that is structural rather than a
convention: ``resolve_config`` takes a ``CLIConfig`` and a path, and both
``aiperf profile`` and ``aiperf service`` call it with nothing else. A flag
can therefore reach ``AIPerfConfig`` only by being a field on ``CLIConfig``,
which is what lets the classification test enumerate ``model_fields`` and
claim completeness. Give ``resolve_config`` another source of user intent
and that claim quietly stops holding -- extend the classification in the
same change. (``aiperf service``'s own ``--service-id`` / ``--health-*``
parameters live on the command, never reach this path, and are out of scope
by construction.)

This module makes the boundary explicit and enforceable:

``ROUTED_UNDER_CONFIG``
    Fields the resolver genuinely routes. Derived from the same maps the
    resolver and converters use, so it cannot drift from them.

``UNROUTED_UNDER_CONFIG``
    Fields known to be dropped. Written out by hand on purpose -- a computed
    complement would make ``test_every_section_field_is_classified`` vacuous.
    A newly-added CLI flag lands in neither set and fails that test at
    authoring time, which is the whole point.

:func:`reject_unrouted_cli_flags` turns the drop into a ``ConfigurationError``
naming the offending flags. Repairing the routing (so entries move from
``UNROUTED`` to ``ROUTED``) is separate work; until then users get a loud
error instead of a wrong benchmark.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from aiperf.config.flags._section_fields import (
    ACCURACY_FIELDS,
    ENDPOINT_FIELDS,
    INPUT_FIELDS,
    LOADGEN_FIELDS,
    OUTPUT_FIELDS,
    SWEEPING_FIELDS,
    TOKENIZER_FIELDS,
)
from aiperf.config.flags.recipes import _SLA_TARGET_FIELDS, _SWEEP_OVERRIDE_FIELDS

if TYPE_CHECKING:
    from aiperf.config.flags import CLIConfig

ALL_SECTION_FIELDS: frozenset[str] = (
    ACCURACY_FIELDS
    | ENDPOINT_FIELDS
    | INPUT_FIELDS
    | LOADGEN_FIELDS
    | OUTPUT_FIELDS
    | SWEEPING_FIELDS
    | TOKENIZER_FIELDS
)


# Fields that are not benchmark configuration at all, so "routed under
# --config" does not apply to them. Each needs a reason: an unexplained
# exemption is a silent drop with extra steps.
EXEMPT_FROM_CONFIG_ROUTING: frozenset[str] = frozenset(
    {
        # The --config flag itself; it selects the file being merged.
        "config_file",
        # Alias input consumed during CLIConfig validation rather than routed
        # onto AIPerfConfig; it populates its canonical sibling, which is
        # itself classified.
        "stream",
    }
)

# Fields outside every section frozenset that nonetheless reach AIPerfConfig,
# verified by resolving with the flag set and diffing against the no-flag
# baseline. The section sets are opt-in and incomplete; this records what is
# genuinely routed rather than letting absence imply anything.
_ROUTED_OUTSIDE_SECTIONS: frozenset[str] = frozenset(
    {
        # service runtime / logging, via build_logging_runtime
        "api_host",
        "api_port",
        "extra_verbose",
        "log_level",
        "record_processor_service_count",
        "stats_interval",
        "ui_type",
        "verbose",
        "workers_max",
        "zmq_dual_bind",
        "zmq_ipc_path",
        "zmq_tcp_host",
        # telemetry collectors already wired into build_cli_overrides
        "gpu_telemetry",
        "no_gpu_telemetry",
        "server_metrics",
        "no_server_metrics",
        "server_metrics_formats",
        # wandb, via build_wandb (the non-project flags are guarded loudly
        # rather than dropped when --wandb-project is absent)
        "wandb_project",
        "wandb_entity",
        "wandb_run_name",
        "wandb_tags",
        # agentic phase fields, via _apply_agentic_replay_fields
        "agentic_cache_warmup_duration",
        "agentic_warmup_grace_period",
        "warmup_requests_per_lane",
        # publishing targets, via build_mlflow / build_otel /
        # build_network_latency -- the builders the CLI-only converter has
        # always used, now called by build_cli_overrides too
        "mlflow_artifact_globs",
        "mlflow_experiment",
        "mlflow_parent_run_id",
        "mlflow_run_name",
        "mlflow_tags",
        "mlflow_tracking_uri",
        "otel_resource_attributes",
        "otel_url",
        "gen_ai_provider",
        "network_latency_automatic",
        "network_latency_mean",
        "network_latency_ping_interval",
        # scenario lock, via _apply_scenario_overrides
        "scenario",
        "unsafe_override",
        # magic-list sweep topology, read by promote_benchmark_magic_lists
        "sweep_type",
        # inter-turn delay cap, carried onto trace datasets by build_dataset
        "inter_turn_delay_cap_seconds",
        # verbatim system prompt, carried onto the dataset by
        # _VERBATIM_DATASET_FIELDS (added on main by #1268)
        "system_prompt",
        "system_prompt_file",
        # truncation handling, carried onto every dataset variant by
        # _VERBATIM_DATASET_FIELDS
        "end_conversation_on_truncation",
        # baseten_trace dataset knobs carried by _VERBATIM_DATASET_FIELDS;
        # against another format they raise rather than drop
        "force_min_tokens",
        "max_idle_gap_cap_seconds",
        "omit_kv_hints",
        "open_loop_replay",
        "open_loop_strict",
        "replay_speedup",
        "trace_session_sample_ratio",
    }
)


# Inputs to a --search-recipe: SLA targets and sweep-range overrides the
# recipe reads from SearchRecipeContext. Derived from the tuples the recipe
# context is built from, so the two cannot drift. Without a recipe nothing
# reads them.
RECIPE_INPUT_FIELDS: frozenset[str] = frozenset(
    {*_SLA_TARGET_FIELDS, *_SWEEP_OVERRIDE_FIELDS, "isl_osl_pairs"}
)

# Details of trial-level convergence; build_multi_run only emits them once a
# convergence metric turns convergence on.
CONVERGENCE_DETAIL_FIELDS: frozenset[str] = frozenset(
    {"convergence_mode", "convergence_stat", "convergence_threshold"}
)


# Kept (empty) as the invariant suite's hook; companion-required sweep flags are
# covered by reject_missing_sweep_companions here and by SWEEP_FLAG_COMPANIONS
# in tests/unit/config/test_config_override_invariants.py.
COMPANION_ROUTED: dict[str, frozenset[str]] = {}


# Flags that would replace the dataset the config file declared rather than
# shape it: its source file, its public-dataset identity, its format. The YAML
# owns those, and build_dataset drops the corresponding keys in override mode,
# so the flags must keep erroring instead of appearing to work.
DATASET_SOURCE_FIELDS: frozenset[str] = frozenset(
    {
        # Switch the dataset TYPE, not just a value inside it. The variants
        # barely overlap -- FileDataset carries a dozen fields PublicDataset
        # rejects -- so accepting these would silently invalidate whole groups
        # of keys the user wrote in the config file.
        "public_dataset",
        "hf_weka_dataset",
        "hf_mooncake_dataset",
    }
)

# Source flags that change a value WITHIN the declared type: the trace file
# and the loader that reads it. Overriding these is the "same benchmark,
# different trace" loop, and is no more surprising than --model overriding
# models.items. build_dataset applies them only when the config file declares
# type: file; against any other type they raise, because that would be a type
# switch wearing a different hat.
DATASET_SOURCE_IN_TYPE_FIELDS: frozenset[str] = frozenset(
    {"input_file", "custom_dataset_type"}
)

# INPUT_FIELDS members that build_dataset does not carry: they land on the
# slos block or the profiling phase instead. They ARE routed (see
# _apply_phase_loadgen_overrides and the goodput handling in
# build_cli_overrides); this set exists to keep them out of the dataset
# reconciliation, which would otherwise report them as inert because
# build_dataset legitimately emits nothing for them.
_INPUT_NOT_ON_DATASET: frozenset[str] = frozenset(
    {
        # --goodput lands on the benchmark `slos` block.
        "goodput",
        # The fixed-schedule flags select and shape the profiling phase, so
        # they are routed by _apply_phase_loadgen_overrides rather than
        # carried on the dataset -- and must stay out of the dataset
        # reconciliation, which would otherwise report them as inert.
        "fixed_schedule",
        "fixed_schedule_auto_offset",
        "fixed_schedule_end_offset",
        "fixed_schedule_start_offset",
    }
)


# Dataset-carried fields that are not INPUT_FIELDS members. build_dataset
# reads them (via _VERBATIM_DATASET_FIELDS and the trace helpers), so the
# per-flag reconciliation in _apply_dataset_overrides must consider them too;
# keying that check on INPUT_FIELDS alone let them no-op silently.
DATASET_FIELDS_OUTSIDE_INPUT: frozenset[str] = frozenset(
    {
        "end_conversation_on_truncation",
        "force_min_tokens",
        "inter_turn_delay_cap_seconds",
        "max_idle_gap_cap_seconds",
        "omit_kv_hints",
        "open_loop_replay",
        "open_loop_strict",
        "replay_speedup",
        "system_prompt",
        "system_prompt_file",
        "trace_idle_gap_cap_seconds",
        "trace_session_sample_ratio",
    }
)

# INPUT fields that _apply_dataset_overrides carries onto the dataset block.
# Used to decide whether a config file lacking a dataset is an error for this
# invocation or simply nothing to do.
DATASET_OVERRIDE_FIELDS: frozenset[str] = (
    INPUT_FIELDS - DATASET_SOURCE_FIELDS - _INPUT_NOT_ON_DATASET
) - {"headers", "extra_inputs"}


def _build_routed_under_config() -> frozenset[str]:
    """Derive the routed set from the resolver's own routing tables.

    Imports are local: ``resolver`` imports this module's reject helper
    lazily, and reaching back into it at module scope would close the cycle.
    Deriving rather than restating means adding an entry to
    ``_ENDPOINT_FIELD_MAP`` or ``_LOADGEN_PHASE_FIELD_MAP`` automatically
    counts as routed here.
    """
    from aiperf.config.flags._converter_endpoint import _ENDPOINT_FIELD_MAP
    from aiperf.config.flags._converter_profiling import (
        _AGENTIC_REPLAY_ROUTES,
        _GAMMA_ONLY_ROUTES,
        _RAMP_FIELDS,
    )
    from aiperf.config.flags.resolver import _LOADGEN_PHASE_FIELD_MAP

    # _apply_endpoint_overrides: the field map, plus --url and the
    # --model-names/--model-selection-strategy pair that lands on `models`.
    endpoint = (
        set(_ENDPOINT_FIELD_MAP)
        | {
            "urls",
            "model_names",
            "model_selection_strategy",
        }
        | {
            # nested endpoint sub-blocks, via _maybe_build_reset_kv_cache /
            # _maybe_build_server_profiler / _maybe_build_sagemaker
            field
            for field in ENDPOINT_FIELDS
            if field.startswith(("reset_kv_cache", "server_profiler", "sagemaker"))
        }
    )

    # _apply_input_overrides routes headers/extra onto the endpoint block;
    # every other dataset-shaping field goes through _apply_dataset_overrides,
    # which delegates to build_dataset in override mode.
    #
    # The exceptions are the fields that would replace the dataset the config
    # file declared rather than shape it -- source, type, and format. The YAML
    # owns those, so the flags stay rejected (see DATASET_SOURCE_FIELDS).
    inputs = (INPUT_FIELDS - DATASET_SOURCE_FIELDS) - _INPUT_NOT_ON_DATASET
    inputs |= DATASET_SOURCE_IN_TYPE_FIELDS

    # _apply_phase_loadgen_overrides: the phase field map, the rate-series
    # pair, and the AGENTIC_REPLAY fields shared with BasePhaseConfig.
    loadgen = (
        {attr for attr, _ in _LOADGEN_PHASE_FIELD_MAP}
        | {"request_rate_series", "arrival_pattern"}
        | (set(_AGENTIC_REPLAY_ROUTES) & LOADGEN_FIELDS)
        # Phase shaping, applied by _apply_phase_shaping_overrides through the
        # converter's own helpers. Derived from the same tables those helpers
        # read, so a new ramp or gamma-only route counts as routed here too.
        | {attr for attr, _ in _RAMP_FIELDS}
        | {attr for _, attr in _GAMMA_ONLY_ROUTES}
        | {"request_cancellation_rate", "request_cancellation_delay"}
        # Warmup phase shaping, applied by _apply_warmup_overrides.
        | {field for field in LOADGEN_FIELDS if field.startswith("warmup_")}
        # Fixed-schedule phase selection and its offsets, and --goodput, which
        # lands on the benchmark slos block.
        | {field for field in INPUT_FIELDS if field.startswith("fixed_schedule")}
        | {"goodput"}
    )

    # Whole-section builders consumed by build_cli_overrides: build_artifacts
    # + resolve_auto_plot, build_tokenizer, build_accuracy.
    whole_sections = OUTPUT_FIELDS | TOKENIZER_FIELDS | ACCURACY_FIELDS

    # Every SWEEPING member reaches the resolver, but some act only beside a
    # companion. reject_missing_sweep_companions raises for the ones it knows
    # (recipe inputs, convergence details, --sweep-type, --search-sla and
    # --search-sla-tier); routed does not by itself mean a flag acts alone.
    sweeping = set(SWEEPING_FIELDS)

    return frozenset(
        endpoint
        | inputs
        | loadgen
        | whole_sections
        | sweeping
        | _ROUTED_OUTSIDE_SECTIONS
        | DATASET_FIELDS_OUTSIDE_INPUT
    )


ROUTED_UNDER_CONFIG: frozenset[str] = _build_routed_under_config()


def _build_magic_list_only_fields() -> frozenset[str]:
    """Dataset fields whose list form routes as a sweep parameter.

    ``promote_benchmark_magic_lists`` hoists a list-shaped ``--isl 128 256``
    into a ``sweep`` parameter; the scalar form routes onto the dataset block
    through ``_apply_dataset_overrides``. Both forms take effect, so these
    fields are routed either way. The set records which fields have the two
    distinct destinations, so tests (and ``MAGIC_LIST_ONLY_UNDER_CONFIG``
    consumers generally) can assert against the right one.
    """
    from aiperf.config.flags.converter import _CLI_DATASET_MAGIC_LIST_PATHS

    return frozenset(attr for attr, _ in _CLI_DATASET_MAGIC_LIST_PATHS)


MAGIC_LIST_ONLY_UNDER_CONFIG: frozenset[str] = _build_magic_list_only_fields()

# Fields silently discarded when --config is supplied. Listed explicitly so
# that a new CLI flag belongs to neither set and trips the classification
# test. Entries move to ROUTED_UNDER_CONFIG as routing is repaired.
UNROUTED_UNDER_CONFIG: frozenset[str] = frozenset(
    {
        # ----- endpoint -----
        # ----- input: dataset identity, owned by the config file -----
        # Every other INPUT field now routes through _apply_dataset_overrides;
        # these would swap the dataset the YAML declared rather than shape it.
        *DATASET_SOURCE_FIELDS,
        # ----- outside every section frozenset -----
        # Still dropped: consumed by phase construction, which this path does
        # not rebuild.
        "disable_auto_fixed_schedule",
        # ----- loadgen: ramps, pacing, cancellation -----
    }
)


def flag_names_for(field: str) -> tuple[str, ...]:
    """Return the CLI flag spellings for a ``CLIConfig`` field.

    Reads the ``CLIParameter`` annotation metadata rather than kebab-casing
    the attribute, because several fields do not follow from their name --
    ``conversation_num`` is ``--num-conversations``, ``warmup_request_count``
    is also ``--num-warmup-requests``. Error messages have to name flags the
    user can actually type.

    Returns an empty tuple when the field carries no ``CLIParameter``.
    """
    from aiperf.config.flags import CLIConfig

    info = CLIConfig.model_fields.get(field)
    if info is None:
        return ()
    # Fields declare their flags via CLIParameter or via cyclopts' Parameter
    # (--parameter-sweep-same-seed uses the latter). Match structurally on a
    # `name` tuple of dash-prefixed spellings rather than on either class, so
    # a third declaration style still yields real flag names.
    for meta in info.metadata:
        names = getattr(meta, "name", None)
        if isinstance(names, (tuple, list)) and any(
            isinstance(n, str) and n.startswith("--") for n in names
        ):
            return tuple(n for n in names if isinstance(n, str))
    return ()


def _describe(field: str) -> str:
    """Render a field as every spelling it accepts, falling back to the name.

    Naming only the first declared spelling meant a user who typed
    ``--num-warmup-requests`` was told about ``--warmup-request-count``, and
    ``--num-conversations`` was reported as ``--conversation-num`` -- flags
    absent from their shell history. This layer cannot see which spelling was
    typed (the CLIConfig it receives has already been parsed), so it names
    them all rather than guessing.
    """
    names = flag_names_for(field)
    return "/".join(names) if names else field


def reject_unrouted_cli_flags(cli: CLIConfig) -> None:
    """Raise when explicitly-set CLI flags cannot be routed under ``--config``.

    Gating is on ``cli.model_fields_set`` -- a flag the user did not pass can
    never trigger this, and a flag passed with a falsy value (``--concurrency 0``)
    still counts as set.

    Args:
        cli: the parsed ``CLIConfig`` for this invocation.

    Raises:
        ConfigurationError: naming every offending flag at once, so a user
            fixing a long command line learns about all of them in one run.
    """
    from aiperf.config.loader.errors import ConfigurationError

    # Keyed on every CLIConfig field rather than on the section frozensets:
    # those are opt-in, and a field nobody sectioned was invisible here.
    unrouted = cli.model_fields_set - ROUTED_UNDER_CONFIG - EXEMPT_FROM_CONFIG_ROUTING
    if not unrouted:
        return

    flags = ", ".join(sorted(_describe(field) for field in unrouted))
    raise ConfigurationError(
        f"These CLI flags cannot be combined with --config and would "
        f"otherwise be ignored: {flags}. Set the equivalent values in the "
        f"YAML config file, or drop --config and pass the run entirely on "
        f"the command line."
    )


def _cli_magic_list_fields(cli: CLIConfig) -> list[str]:
    from aiperf.config.sweep import MAGIC_LIST_FIELDS

    return sorted(
        field
        for field in cli.model_fields_set
        if field in MAGIC_LIST_FIELDS and isinstance(getattr(cli, field), list)
    )


def _yaml_declares_convergence(yaml_dict: dict[str, Any]) -> bool:
    multi_run = yaml_dict.get("multi_run", yaml_dict.get("multiRun"))
    return isinstance(multi_run, dict) and isinstance(
        multi_run.get("convergence"), dict
    )


def _missing_companion_problems(cli: CLIConfig, yaml_dict: dict[str, Any]) -> list[str]:
    set_fields = cli.model_fields_set
    has_yaml_sweep = isinstance(yaml_dict.get("sweep"), dict)
    has_recipe = "search_recipe" in set_fields and cli.search_recipe is not None
    has_metric = (
        "convergence_metric" in set_fields and cli.convergence_metric is not None
    )
    problems: list[str] = []
    if not has_recipe:
        problems.extend(
            f"{_describe(field)} requires --search-recipe; it is an input to "
            f"a search recipe and nothing else reads it"
            for field in sorted(set_fields & RECIPE_INPUT_FIELDS)
        )
    if not has_metric and not _yaml_declares_convergence(yaml_dict):
        problems.extend(
            f"{_describe(field)} requires --convergence-metric or a "
            f"multi_run.convergence block in the config file"
            for field in sorted(set_fields & CONVERGENCE_DETAIL_FIELDS)
        )
    problems.extend(_search_filter_problems(cli, has_recipe=has_recipe))
    if "sweep_type" in set_fields:
        if has_yaml_sweep:
            problems.append(
                "--sweep-type cannot change the sweep the config file "
                "declares; set sweep.type in the file instead"
            )
        elif not _cli_magic_list_fields(cli):
            problems.append(
                "--sweep-type requires list-valued flags to sweep over "
                "(e.g. --concurrency 1,2,4)"
            )
    if has_recipe and has_yaml_sweep:
        problems.append(
            "--search-recipe defines its own sweep and cannot be combined "
            "with the sweep the config file declares; remove one"
        )
    if "search_space" in set_fields and cli.search_space and has_yaml_sweep:
        problems.append(
            f"{_describe('search_space')} defines its own sweep and cannot be "
            f"combined with the sweep the config file declares; remove one"
        )
    return problems


def _search_filter_problems(cli: CLIConfig, *, has_recipe: bool) -> list[str]:
    """``--search-sla`` / ``--search-sla-tier`` only shape a search's results;
    with neither a recipe nor ``--search-space`` there is no search to shape.

    Whether a recipe expands to the adaptive search tiers need is known only
    after expansion; ``reject_search_filters_for_recipe`` checks that.
    """
    set_fields = cli.model_fields_set
    has_search_space = "search_space" in set_fields and bool(cli.search_space)
    if has_recipe or has_search_space:
        return []
    problems: list[str] = []
    if "search_sla" in set_fields and cli.search_sla:
        problems.append(
            f"{_describe('search_sla')} requires --search-recipe or "
            f"--search-space; it filters a search's results. To filter the "
            f"config file's sweep, set sweep.sla_filters there"
        )
    if "search_sla_tier" in set_fields and cli.search_sla_tier:
        problems.append(
            f"{_describe('search_sla_tier')} requires an adaptive search: "
            f"--search-space, or a --search-recipe that expands to one"
        )
    return problems


def reject_search_filters_for_recipe(
    cli: CLIConfig, recipe_output: dict[str, Any]
) -> None:
    """Raise when ``--search-sla`` / ``--search-sla-tier`` cannot reach the
    sweep a recipe expanded to.

    Tiers rank adaptive-search trials, so a grid or scenarios recipe would drop
    them; scenario sweeps carry only the recipe's own SLA filters.

    Raises:
        ConfigurationError: naming each flag and the recipe's sweep kind.
    """
    from aiperf.config.loader.errors import ConfigurationError

    if recipe_output.get("adaptive_search") is not None:
        return
    kind = "scenario" if recipe_output.get("scenarios") else "grid"
    set_fields = cli.model_fields_set
    problems: list[str] = []
    if "search_sla_tier" in set_fields and cli.search_sla_tier:
        problems.append(
            f"{_describe('search_sla_tier')} requires an adaptive search, but "
            f"--search-recipe {cli.search_recipe} expands to a {kind} sweep"
        )
    if kind == "scenario" and "search_sla" in set_fields and cli.search_sla:
        problems.append(
            f"{_describe('search_sla')} is not applied to a scenario recipe "
            f"such as {cli.search_recipe}"
        )
    if problems:
        details = "\n  - ".join(problems)
        raise ConfigurationError(
            f"Search filters passed with --config cannot take effect:\n  - {details}"
        )


def reject_missing_sweep_companions(cli: CLIConfig, yaml_dict: dict[str, Any]) -> None:
    """Raise when a sweep flag under ``--config`` lacks the flag it needs.

    A recipe input without ``--search-recipe``, a convergence detail without
    a convergence metric, or ``--sweep-type`` with nothing to sweep resolves
    cleanly and changes nothing -- the silent drop this module exists to
    prevent. Only rules answerable before the merge live here; rules about
    the final sweep block are enforced where that block is written.

    Args:
        cli: the parsed ``CLIConfig`` for this invocation.
        yaml_dict: the loaded (rendered) config file.

    Raises:
        ConfigurationError: naming every offending flag at once.
    """
    from aiperf.config.loader.errors import ConfigurationError

    problems = _missing_companion_problems(cli, yaml_dict)
    if problems:
        details = "\n  - ".join(problems)
        raise ConfigurationError(
            f"Sweep flags passed with --config cannot take effect:\n  - {details}"
        )


# Flags that define a sweep. A sweep may be defined in one place only, so
# these cannot be combined with a sweep: block in the config file.
FILE_SWEEP_BLOCK_FLAGS: frozenset[str] = frozenset(
    {"search_recipe", "search_space", "sweep_type", "sweep_variants"}
)


def reject_cli_flags_against_hoisted_blocks(cli: CLIConfig, *, sweep_cfg: Any) -> None:
    """Raise when a sweep-defining flag meets the file's ``sweep:`` block.

    A sweep may be defined only once, so ``aiperf kube sweep`` rejects the
    defining flags against a file that already declares one. Flags that adjust
    the sweep (``--parameter-sweep-*``, ``--convergence-*``) are not rejected:
    kube sweep applies them to the file's blocks after its merge (see
    :func:`hoisted_block_adjusting_fields`).

    Args:
        cli: the parsed ``CLIConfig`` for this invocation.
        sweep_cfg: the file's hoisted ``sweep:`` block, or None.

    Raises:
        ConfigurationError: naming every offending flag at once.
    """
    from aiperf.config.loader.errors import ConfigurationError

    if not isinstance(sweep_cfg, dict):
        return
    problems = [
        f"{_describe(field)} cannot be combined with the sweep: block in "
        f"the file under `aiperf kube sweep`; set it in the file"
        for field in sorted(cli.model_fields_set & FILE_SWEEP_BLOCK_FLAGS)
    ]
    if problems:
        details = "\n  - ".join(problems)
        raise ConfigurationError(
            f"Sweep-defining flags cannot be combined with the file's sweep: "
            f"block under `aiperf kube sweep`:\n  - {details}"
        )


def hoisted_block_adjusting_fields(
    cli: CLIConfig, *, sweep_cfg: Any, multirun_cfg: Any
) -> frozenset[str]:
    """Return the user-set flags that adjust a block ``kube sweep`` hoisted.

    ``aiperf kube sweep`` hoists the file's ``sweep:`` / ``multiRun:`` blocks
    out before the shared resolver runs, so the resolver cannot see them and
    would report these flags as having nothing to apply to. Kube sweep defers
    them past the resolver and applies them once the blocks are merged back.
    Convergence details are deferred only without ``--convergence-metric``;
    with it, the resolver emits the whole convergence block itself.

    Args:
        cli: the parsed ``CLIConfig`` for this invocation.
        sweep_cfg: the file's hoisted ``sweep:`` block, or None.
        multirun_cfg: the file's hoisted ``multiRun:`` block, or None.

    Returns:
        The ``CLIConfig`` field names to defer; empty when none apply.
    """
    from aiperf.config.flags.converter import _PARAMETER_SWEEP_KEYS

    set_fields = cli.model_fields_set
    deferred: set[str] = set()
    if isinstance(sweep_cfg, dict):
        deferred |= set_fields & {cli_field for cli_field, _ in _PARAMETER_SWEEP_KEYS}
    has_metric = (
        "convergence_metric" in set_fields and cli.convergence_metric is not None
    )
    if (
        isinstance(multirun_cfg, dict)
        and isinstance(multirun_cfg.get("convergence"), dict)
        and not has_metric
    ):
        deferred |= set_fields & CONVERGENCE_DETAIL_FIELDS
    return frozenset(deferred)
