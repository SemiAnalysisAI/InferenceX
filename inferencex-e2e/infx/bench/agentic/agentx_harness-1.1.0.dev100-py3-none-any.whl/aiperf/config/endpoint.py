# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""
AIPerf Configuration v2.0 - Pydantic Models

Endpoint - Server connection and API configuration
"""

from __future__ import annotations

import ipaddress
from dataclasses import dataclass
from typing import Annotated, Any, Literal, Self
from urllib.parse import urlparse

from pydantic import (
    AfterValidator,
    ConfigDict,
    Field,
    PrivateAttr,
    field_serializer,
    model_validator,
)

from aiperf.common.aiperf_logger import AIPerfLogger
from aiperf.common.enums import (
    ConnectionReuseStrategy,
    ModelSelectionStrategy,
    RequestContentType,
)
from aiperf.common.utils import is_truthy_flag
from aiperf.config.base import BaseConfig
from aiperf.config.control_hooks import (
    ResetKvCacheConfig,
    ServerProfilerConfig,
    parse_enabled_or_config,
    require_relative_path,
)
from aiperf.config.loader.parsing import normalize_http_urls
from aiperf.config.sagemaker import SageMakerConfig
from aiperf.plugin.enums import (
    EndpointType,
    RequestSignerType,
    TransportType,
    URLSelectionStrategy,
)

__all__ = [
    "EndpointConfig",
    "EndpointDefaults",
    "TemplateConfig",
]

_logger = AIPerfLogger(__name__)


@dataclass(frozen=True)
class EndpointDefaults:
    MODEL_SELECTION_STRATEGY = ModelSelectionStrategy.ROUND_ROBIN
    CUSTOM_ENDPOINT = None
    TYPE = EndpointType.CHAT
    STREAMING = False
    ALLOW_EMPTY_CONTENT = False
    URL = "http://localhost:8000"
    URL_STRATEGY = URLSelectionStrategy.ROUND_ROBIN
    TIMEOUT = 6 * 60 * 60  # 6 hours, match vLLM benchmark default
    API_KEY = None
    USE_LEGACY_MAX_TOKENS = False
    USE_SERVER_TOKEN_COUNT = False
    PER_CHUNK_USAGE = False
    CONNECTION_REUSE_STRATEGY = ConnectionReuseStrategy.POOLED
    DOWNLOAD_VIDEO_CONTENT = False
    REQUEST_CONTENT_TYPE = None
    # Readiness probe defaults. Timeout 0 disables the probe (the default);
    # any positive value enables it. Interval is only consulted when the
    # probe is enabled but is validated positive so mis-configuration
    # (e.g. --wait-for-model-interval 0) is rejected at config-load time.
    WAIT_FOR_MODEL_TIMEOUT = 0.0
    WAIT_FOR_MODEL_INTERVAL = 5.0
    WAIT_FOR_MODEL_MODE = "inference"
    UUID_AND_STRIP = False


class TemplateConfig(BaseConfig):
    """
    Configuration for custom template-based endpoints.

    When endpoint type is "template", this configures how requests
    are formatted and responses are parsed.
    """

    model_config = ConfigDict(extra="forbid")

    body: Annotated[
        str,
        Field(
            description="Jinja2 template string for request body. "
            "Variables: {{prompt}}, {{max_tokens}}, {{model}}, {{messages}}, etc.",
        ),
    ]

    response_field: Annotated[
        str,
        Field(
            default="text",
            description="JSON path to extract response text from API response. "
            "Use dot notation for nested fields: 'choices.0.message.content'.",
        ),
    ]


def _missing_endpoint_name_error() -> ValueError:
    """The SageMaker transport with nothing to put in its request path.

    Raised from both validators so a YAML input without ``urls`` -- where field
    validation would otherwise fail first with "urls: Field required" -- names the
    same missing flag as the CLI path does.
    """
    return ValueError(
        "The SageMaker transport requires --sagemaker-endpoint-name (or an "
        "explicit --endpoint path to use instead); without it the request path "
        "would be /endpoints//invocations."
    )


_SAGEMAKER_ROUTING_FLAGS = {
    "target_model": "--sagemaker-target-model",
    "inference_component_name": "--sagemaker-inference-component-name",
    "target_variant": "--sagemaker-target-variant",
}


def _reject_orphaned_sagemaker_routing(
    sagemaker: SageMakerConfig, transport: TransportType | None
) -> None:
    """Refuse SageMaker routing options that no transport will send.

    Only the SageMaker transport reads them, so under any other transport the
    benchmark would hit the endpoint's default model, component or traffic
    split while the exported config says otherwise.
    """
    flags = [
        flag
        for field, flag in _SAGEMAKER_ROUTING_FLAGS.items()
        if getattr(sagemaker, field)
    ]
    if flags:
        selected = f"--transport {transport}" if transport else "the http transport"
        raise ValueError(
            f"SageMaker routing options require the SageMaker transport, but "
            f"{selected} is selected and would silently ignore "
            f"{', '.join(flags)}. Set --sagemaker-endpoint-name (or --transport "
            f"sagemaker), or drop those flags."
        )


def _missing_region_error() -> ValueError:
    """A SageMaker endpoint with no region to derive its host and scope from.

    Raised by the before-validator when it would derive the URL and by the
    after-validator when an explicit ``--url`` skipped that, so the CLI and YAML
    paths report the same message.
    """
    return ValueError(
        "SageMaker endpoints require --aws-region: it selects both the "
        "runtime hostname and the SigV4 credential scope, and there is "
        "no safe default to guess."
    )


def _canonical_transport(value: Any) -> Any:
    """``value`` as a TransportType when it names one, in any casing.

    The raw mapping is compared here, before field validation, and the field
    itself accepts any casing (YAML `transport: SageMaker`).
    """
    try:
        return TransportType(value)
    except (ValueError, TypeError):
        return value


def _apply_sagemaker_before_validation(data: dict) -> None:
    """Resolve what ``--sagemaker-endpoint-name`` implies about transport and URL.

    Runs as part of the before-validator rather than an after-validator because
    ``urls`` is a required field: an after-validator never runs, so the user
    would get "urls: Field required" instead of anything about SageMaker.

    Separate from ``normalize_before_validation``, which calls it, to keep that
    method under the repo's complexity guardrail; everything here is one concern.
    """
    sagemaker = data.get("sagemaker") or {}
    if isinstance(sagemaker, dict):
        # Both spellings: this runs on the raw mapping, before alias
        # resolution, and the input may use either. BaseConfig accepts both
        # (alias_generator=to_camel, populate_by_name), and the generated CRDs
        # and JSON schema use camelCase.
        endpoint_name = sagemaker.get("endpoint_name") or sagemaker.get("endpointName")
    else:
        endpoint_name = getattr(sagemaker, "endpoint_name", None)
    if not endpoint_name:
        if (
            _canonical_transport(data.get("transport")) == TransportType.SAGEMAKER
            and data.get("path") is None
        ):
            raise _missing_endpoint_name_error()
        return

    # Checked before the URL derivation below, and before any after-validator,
    # so the diagnostic names the real conflict. Otherwise whichever guard
    # happens to fire first blames an unrelated flag: with a region,
    # "--aws-region has no effect unless --auth-type is set to 'sigv4'";
    # without one, "SageMaker endpoints require --aws-region".
    transport = data.get("transport")
    if (
        transport is not None
        and _canonical_transport(transport) != TransportType.SAGEMAKER
    ):
        raise ValueError(
            f"--sagemaker-endpoint-name selects the SageMaker transport, but "
            f"--transport {transport} was set explicitly. Drop --transport to "
            f"benchmark the SageMaker endpoint, or drop "
            f"--sagemaker-endpoint-name to use {transport} against --url."
        )

    if data.get("urls"):
        return

    region = data.get("aws_region") or data.get("awsRegion")
    if not region:
        raise _missing_region_error()
    from aiperf.transports.aws.regions import dns_suffix, is_region_id

    if not isinstance(region, str) or not is_region_id(region):
        raise ValueError(
            f"--aws-region {region!r} is not an AWS region id such as us-west-2. "
            f"It becomes part of the derived SageMaker hostname, so anything else "
            f"could send signed requests to a host outside AWS. To use a custom "
            f"host, pass it with --url."
        )
    data["urls"] = [f"https://runtime.sagemaker.{region}.{dns_suffix(region)}"]


def _transport_signs(transport: TransportType) -> bool:
    """Whether the named transport applies the configured request signer.

    Signing lives on ``AioHttpTransport._sign_if_needed``; anything deriving from
    it inherits the call site. Resolved through the plugin registry rather than an
    enum comparison so that adding a signing transport requires no edit here.
    """
    from aiperf.plugin import plugins
    from aiperf.plugin.enums import PluginType
    from aiperf.transports.aiohttp_transport import AioHttpTransport

    try:
        transport_cls = plugins.get_class(PluginType.TRANSPORT, str(transport))
    except Exception:
        return False
    return isinstance(transport_cls, type) and issubclass(
        transport_cls, AioHttpTransport
    )


def _is_cleartext_remote(url: str) -> bool:
    """Whether ``url`` would send request headers unencrypted off-box.

    Loopback is deliberately exempt: the documented mock-server workflow signs
    against ``http://localhost``, and headers that never leave the machine are not
    disclosed by the absence of TLS.

    The host is parsed as an address rather than matched as text. A prefix test
    such as ``host.startswith("127.")`` also accepts ``127.attacker.example`` --
    a subdomain anyone controlling a domain can create -- and this function is
    what decides whether a signature and session token may travel in cleartext.
    """
    parsed = urlparse(url if "://" in url else f"http://{url}")
    if parsed.scheme != "http":
        return False
    host = (parsed.hostname or "").lower()
    if host == "localhost":
        return False
    try:
        address = ipaddress.ip_address(host)
    except ValueError:
        return True
    # ipv4_mapped is unwrapped explicitly: is_loopback only began covering
    # ::ffff:127.0.0.1 in CPython newer than this project's 3.11 floor.
    return not (getattr(address, "ipv4_mapped", None) or address).is_loopback


class EndpointConfig(BaseConfig):
    """
    Endpoint configuration for connecting to inference servers.

    This section configures how AIPerf connects to and communicates
    with the target inference server(s). It supports multiple URLs
    for load-balanced deployments and various API types.
    """

    model_config = ConfigDict(extra="forbid", validate_default=True)

    urls: Annotated[
        list[str],
        Field(
            min_length=1,
            description="List of server URLs to benchmark. "
            "Requests distributed according to url_strategy. "
            "URLs without a scheme have ``http://`` prepended automatically. "
            "Example: ['http://localhost:8000/v1/chat/completions']",
            json_schema_extra={"x-kubernetes-preserve-unknown-fields": True},
        ),
        AfterValidator(normalize_http_urls),
    ]

    @field_serializer("urls")
    def _redact_urls(self, value: list[str], info: Any) -> list[str]:
        """Redact URL userinfo in serialized config artifacts by default."""
        context = getattr(info, "context", None)
        if isinstance(context, dict) and context.get("include_secrets"):
            return value
        from aiperf.common.redact import redact_url

        return [redact_url(url) for url in value]

    url_strategy: Annotated[
        URLSelectionStrategy,
        Field(
            default=URLSelectionStrategy.ROUND_ROBIN,
            description="Strategy for distributing requests across multiple URLs. "
            "round_robin cycles through URLs in order.",
        ),
    ]

    type: Annotated[
        EndpointType,
        Field(
            default=EndpointType.CHAT,
            description="API endpoint type determining request/response format. "
            "chat: OpenAI chat completions, completions: OpenAI completions, "
            "embeddings: vector embeddings, rankings: reranking, "
            "template: custom format, and others — see `aiperf plugins` "
            "for the full list.",
        ),
    ]

    path: Annotated[
        str | None,
        Field(
            default=None,
            description="Override default endpoint path. "
            "Use for servers with non-standard API paths. "
            "Example: '/custom/v2/generate'",
        ),
    ]

    api_key: Annotated[
        str | None,
        Field(
            default=None,
            description="API authentication key. "
            "Supports environment variable substitution: ${OPENAI_API_KEY}. "
            "Can also use ${VAR:default} syntax for defaults.",
            repr=False,
        ),
    ]

    @field_serializer("api_key", when_used="json")
    def _redact_api_key(self, value: str | None) -> str | None:
        """Never serialize the raw API key into exported JSON artifacts."""
        from aiperf.common.redact import REDACTED_VALUE

        if value is None:
            return None
        return REDACTED_VALUE

    timeout: Annotated[
        float,
        Field(
            ge=0.0,
            default=EndpointDefaults.TIMEOUT,
            description="Request timeout in seconds (0 = no timeout). "
            "Requests exceeding this duration are marked as failed. "
            "Should exceed expected max response time.",
        ),
    ]

    streaming: Annotated[
        bool,
        Field(
            default=False,
            description="Enable streaming (Server-Sent Events) responses. "
            "Required for accurate TTFT (time to first token) measurement. "
            "Server must support streaming for this to work.",
        ),
    ]

    allow_empty_content: Annotated[
        bool,
        Field(
            default=EndpointDefaults.ALLOW_EMPTY_CONTENT,
            description="Retain explicitly empty content or reasoning strings as "
            "timed responses for streaming OpenAI Chat Completions. This changes "
            "the shared response timeline without adding output tokens.",
        ),
    ]

    _streaming_explicitly_set: bool = PrivateAttr(default=False)

    transport: Annotated[
        TransportType | None,
        Field(
            default=None,
            description="Transport plugin name. 'http' (aiohttp-based HTTP/1.1) and "
            "'sagemaker' (AWS SageMaker Runtime, normally derived from "
            "sagemaker.endpoint_name) are shipped. Auto-detected from the URL when "
            "unset, which always selects 'http'; explicit setting overrides "
            "auto-detection.",
        ),
    ]

    aws_region: Annotated[
        str | None,
        Field(
            default=None,
            description="AWS region for the request. Required when auth_type='sigv4'.",
        ),
    ]

    aws_profile: Annotated[
        str | None,
        Field(
            default=None,
            description="Named AWS credentials profile. Unset uses botocore's default "
            "credential chain.",
        ),
    ]

    auth_type: Annotated[
        RequestSignerType | None,
        Field(
            default=None,
            description="Request signing method for authentication. When set, the selected "
            "request_signer plugin signs every HTTP request sent by the HTTP transport. "
            "Replaces Bearer token auth (api_key is ignored when auth_type is set).",
        ),
    ]

    aws_service: Annotated[
        str | None,
        Field(
            default=None,
            description="SigV4 signing name -- the credential scope the signature "
            "is bound to (e.g. 'execute-api', 'sagemaker', 'bedrock'). This is not "
            "always the API id: the 'sagemaker-runtime' API signs as 'sagemaker' and "
            "'bedrock-runtime' as 'bedrock'. Required when auth_type='sigv4', unless "
            "the selected transport declares which AWS API it speaks, in which case "
            "the scope is resolved from botocore's service model.",
        ),
    ]

    sagemaker: Annotated[
        SageMakerConfig,
        Field(
            default_factory=SageMakerConfig,
            description="SageMaker Runtime routing options. Setting "
            "sagemaker.endpoint_name selects the SageMaker transport.",
        ),
    ]

    connection_reuse: Annotated[
        ConnectionReuseStrategy,
        Field(
            default=ConnectionReuseStrategy.POOLED,
            description="HTTP connection management strategy. "
            "pooled: shared connection pool (fastest), "
            "never: new connection per request (includes TCP overhead), "
            "sticky-user-sessions: dedicated connection per user session.",
        ),
    ]

    use_legacy_max_tokens: Annotated[
        bool,
        Field(
            default=False,
            description="Use 'max_tokens' field instead of 'max_completion_tokens'. "
            "Enable for compatibility with older OpenAI API versions.",
        ),
    ]

    use_server_token_count: Annotated[
        bool,
        Field(
            default=False,
            description="Use server-reported token counts from response usage field. "
            "When true, trusts usage.prompt_tokens and usage.completion_tokens. "
            "When false, counts tokens locally using configured tokenizer.",
        ),
    ]

    per_chunk_usage: Annotated[
        bool,
        Field(
            default=False,
            description="Request per-chunk token usage on streaming responses by "
            "setting stream_options.continuous_usage_stats. When true, the server "
            "reports cumulative usage on every chunk (not just the final one), which "
            "lets inter-token latency subtract the first content chunk's real token "
            "count instead of assuming one token. Requires a server that supports "
            "continuous_usage_stats (e.g. vLLM, TRT-LLM); strict OpenAI rejects it. "
            "Requires use_server_token_count so OSL and the first-chunk count share "
            "the server source.",
        ),
    ]

    template: Annotated[
        TemplateConfig | None,
        Field(
            default=None,
            description="Custom template configuration for template endpoint type. "
            "Only used when type='template'. "
            "Defines request body format and response parsing.",
        ),
    ]

    headers: Annotated[
        dict[str, str],
        Field(
            default_factory=dict,
            description="Custom HTTP headers to include in all requests. "
            "Useful for authentication, tracing, or routing. "
            "Values support environment variable substitution.",
        ),
    ]

    @field_serializer("headers", when_used="json")
    def _redact_headers(self, value: dict[str, str]) -> dict[str, str]:
        """Redact credential-bearing header values in exported JSON artifacts.

        Mirrors the api_key serializer above: profile_export_aiperf.json and
        server_metrics_export.json otherwise leak Authorization / X-API-Key /
        api-key etc. verbatim into on-disk artifacts.
        """
        from aiperf.common.redact import redact_headers

        return redact_headers(value) or {}

    extra: Annotated[
        dict[str, Any],
        Field(
            default_factory=dict,
            description="Additional fields to include in request body. "
            "Merged into every request. "
            "Common fields: temperature, top_p, top_k, stop.",
        ),
    ]

    download_video_content: Annotated[
        bool,
        Field(
            default=False,
            description="For video generation endpoints, download the video content "
            "after generation completes. Adds a content download step to the "
            "async polling flow.",
        ),
    ]

    request_content_type: Annotated[
        RequestContentType | None,
        Field(
            default=None,
            description=(
                "Content type for request body serialization. Default is "
                "'application/json'. Set to 'multipart/form-data' for servers that "
                "require form-encoded requests (e.g. vLLM video generation)."
            ),
        ),
    ]

    session_header: Annotated[
        str | None,
        Field(
            default=None,
            description=(
                "HTTP header name used to carry the per-session affinity identifier. "
                "When set, replaces the default `X-Correlation-ID` header. Useful "
                "when the inference server expects a custom session-affinity header "
                "(e.g. `--session-header X-Session-ID`)."
            ),
        ),
    ]

    uuid_and_strip: Annotated[
        bool,
        Field(
            default=EndpointDefaults.UUID_AND_STRIP,
            description=(
                "Enable AIPerf-managed image stripping for vLLM's multimodal processor "
                "cache. Dataset-authored image UUIDs, including UUID-only cache "
                "references, always pass through on the chat endpoint; this flag only "
                "strips repeated content after AIPerf observes it in the same session. "
                "Automatic stripping supports only single_turn datasets with "
                "session_id-grouped rows; multi_turn is rejected. The server cache must "
                "cover the working set, and requests in a session must reach a replica "
                "that retains earlier UUIDs."
            ),
        ),
    ]

    wait_for_model_timeout: Annotated[
        float,
        Field(
            default=0.0,
            description="Enable a pre-flight readiness probe by setting this to a positive value (seconds). "
            "aiperf applies this timeout to each URL/model probe before starting the benchmark, "
            "aborting with a non-zero exit if any probe times out. For multiple URLs or models, "
            "worst-case wall-clock time can be roughly this timeout multiplied by the number of "
            "URL/model probes. The probe strategy is controlled by `--wait-for-model-mode`, which "
            "defaults to sending a 1-token inference request. 0 (default) disables the probe. "
            "Eliminates the need for external shell-based readiness loops in containers and Kubernetes recipes.",
            ge=0.0,
        ),
    ]

    wait_for_model_interval: Annotated[
        float,
        Field(
            default=5.0,
            description="Seconds between readiness probe attempts. "
            "Only consulted when `--wait-for-model-timeout` is positive.",
            gt=0.0,
        ),
    ]

    wait_for_model_mode: Annotated[
        Literal["models", "inference", "both"],
        Field(
            default="inference",
            description="Strategy for the readiness probe. "
            "'inference' (default): POST a 1-token inference request to the configured endpoint; "
            "this is the strongest signal — it proves the full stack (frontend, scheduler, worker, "
            "forward pass) is live. Any HTTP status < 500 counts as ready. "
            "'models': GET `/v1/models` and verify the model id appears in `data[]` "
            "(cheaper, no tokens consumed; falls back to a plain GET on the base URL on 404). "
            "'both': run 'models' first, then 'inference'. "
            "Only consulted when `--wait-for-model-timeout` is positive.",
        ),
    ]

    reset_kv_cache: Annotated[
        ResetKvCacheConfig | None,
        parse_enabled_or_config(ResetKvCacheConfig),
        Field(
            default=None,
            description="When enabled, POST a KV-cache reset once per logical "
            "benchmark cell before warmup/profiling. Accepts false | true | "
            "{timeout_seconds?, path?}.",
        ),
    ] = None

    server_profiler: Annotated[
        ServerProfilerConfig | None,
        parse_enabled_or_config(ServerProfilerConfig),
        Field(
            default=None,
            description="When enabled, start/stop the server profiler around "
            "each profiling phase. Accepts false | true | "
            "{timeout_seconds?, start_path?, stop_path?}.",
        ),
    ] = None

    @model_validator(mode="before")
    @classmethod
    def normalize_before_validation(cls, data: Any) -> Any:
        """Normalize endpoint config before validation.

        Handles:
            - url → urls (singular to plural, wrapped in list)
            - Auto-set type to 'template' when template field is provided
            - Disable streaming when endpoint type does not support it
        """
        if not isinstance(data, dict):
            return data

        # url → urls (singular to plural). Both keys can be present after a
        # YAML+CLI deep-merge (resolve_config) where the YAML used the
        # singular shorthand and a CLI flag overlaid the plural form: in that
        # case the CLI wins and we drop the YAML shorthand. Without this,
        # AIPerfConfig.endpoint.model_validate fails with `url: Extra inputs
        # are not permitted` because both keys reach the validator.
        if "url" in data:
            url = data.pop("url")
            if "urls" not in data:
                data["urls"] = [url] if isinstance(url, str) else url

        _apply_sagemaker_before_validation(data)

        # Auto-detect template type
        if "template" in data and data["template"] is not None and "type" not in data:
            data["type"] = EndpointType.TEMPLATE

        # Disable streaming when the endpoint type does not support it
        if data.get("streaming"):
            try:
                from aiperf.plugin import plugins

                endpoint_type = data.get("type", EndpointType.CHAT)
                metadata = plugins.get_endpoint_metadata(endpoint_type)
                if not metadata.supports_streaming:
                    import warnings

                    warnings.warn(
                        f"Streaming is not supported for endpoint type '{endpoint_type}'. "
                        "Streaming will be disabled.",
                        UserWarning,
                        stacklevel=2,
                    )
                    data["streaming"] = False
            except ImportError:
                pass

        return data

    @model_validator(mode="after")
    def _record_streaming_explicit_set_flag(self) -> Self:
        """Snapshot whether the user explicitly set ``streaming``.

        Scenario validation distinguishes "user explicitly passed
        --streaming/--no-streaming" (raise on conflict) from "streaming is at
        default; auto-fill from the scenario spec" (info log). Surface a stable
        underscore flag for the scenario resolver's defensive ``getattr``.
        """
        self._streaming_explicitly_set = "streaming" in self.model_fields_set
        return self

    @model_validator(mode="after")
    def _derive_sagemaker_settings(self) -> Self:
        """Fill in everything ``--sagemaker-endpoint-name`` implies.

        Defined above ``_validate_endpoint_boundaries`` because that validator
        inspects ``urls``, and the derived URL has to exist by then
        (``mode="after"`` validators run in definition order).

        Only ever fills unset values: anything the user set explicitly wins, so
        an explicit ``--url`` still points at a VPC/PrivateLink endpoint or a
        custom domain.
        """
        if self.sagemaker.endpoint_name and self.transport is None:
            self.transport = TransportType.SAGEMAKER

        if self.transport != TransportType.SAGEMAKER:
            _reject_orphaned_sagemaker_routing(self.sagemaker, self.transport)
            return self

        # An explicit --endpoint path is the exception: get_url() uses it verbatim
        # and never builds the /endpoints/{name}/ route.
        if self.path is None and not self.sagemaker.endpoint_name:
            raise _missing_endpoint_name_error()

        # The readiness probe only knows OpenAI routes (/v1/models, the endpoint
        # type's path), so here it would sign and send a request to a route the
        # endpoint does not serve: a 401/403 aborts pre-flight, any other 4xx is
        # read as "ready".
        if self.wait_for_model_timeout > 0:
            raise ValueError(
                "--wait-for-model-timeout is not supported with the SageMaker "
                "transport: the readiness probe targets OpenAI routes such as "
                "/v1/models, but a SageMaker endpoint serves only "
                "/endpoints/{name}/invocations. Drop --wait-for-model-timeout."
            )

        if self.auth_type is None:
            self.auth_type = RequestSignerType.SIGV4

        if not self.aws_region:
            raise _missing_region_error()

        return self

    @model_validator(mode="after")
    def _validate_endpoint_boundaries(self) -> Self:
        for url in self.urls:
            # Reject leading/trailing whitespace explicitly so that a malformed
            # URL like "  http://h  " or "http://h\n" produces a clear
            # config-time error instead of an InvalidUrlClientError at request
            # time. Internal whitespace (spaces in path, embedded newlines) is
            # also rejected because aiohttp will refuse the request anyway.
            if url != url.strip():
                raise ValueError(
                    f"URL {url!r} has leading or trailing whitespace. "
                    f"Strip whitespace before passing the URL."
                )
            if any(ch.isspace() for ch in url):
                raise ValueError(
                    f"URL {url!r} contains whitespace. URLs must not contain "
                    f"spaces, tabs, or newlines."
                )
            parsed = urlparse(url)
            # Reject anything that lacks a scheme, a netloc, or a hostname.
            # ``http://:18765`` parses as scheme=http, netloc=':18765', hostname=None
            # — looks valid by netloc alone, but aiohttp rejects it with
            # InvalidUrlClientError at request time. Catch it here.
            if not parsed.scheme or not parsed.netloc or not parsed.hostname:
                raise ValueError(
                    f"URL {url!r} is missing scheme or host. "
                    f"Expected 'http://host:port' or 'https://host:port'."
                )
            if parsed.scheme.lower() not in ("http", "https"):
                raise ValueError(
                    f"URL {url!r} has unsupported scheme {parsed.scheme!r}. "
                    f"Expected 'http' or 'https'."
                )
            # Validate the port if one is present. urlparse.port raises
            # ValueError on access for non-numeric or out-of-range ports
            # (``:abc``, ``:99999``, ``:-1``); catch and re-raise with a
            # clear, URL-aware message instead of bubbling the obscure
            # "Port out of range 0-65535".
            try:
                port = parsed.port
            except ValueError as exc:
                raise ValueError(
                    f"URL {url!r} has an invalid port. "
                    f"Ports must be integers in the range 1..65535."
                ) from exc
            if port is not None and not (1 <= port <= 65535):
                raise ValueError(
                    f"URL {url!r} has port {port} outside the valid range 1..65535."
                )
        if self.path is not None and not self.path.startswith("/"):
            raise ValueError("endpoint.path must start with a leading slash")
        return self

    @model_validator(mode="after")
    def _validate_template_required(self) -> Self:
        if self.type == EndpointType.TEMPLATE and self.template is None:
            raise ValueError("template is required when endpoint type is 'template'")
        return self

    @model_validator(mode="after")
    def _validate_uuid_and_strip(self) -> Self:
        """Require image UUID reuse to use the Chat Completions endpoint."""
        if self.uuid_and_strip and self.type != EndpointType.CHAT:
            raise ValueError("--uuid-and-strip requires endpoint type 'chat'")
        return self

    @model_validator(mode="after")
    def _validate_per_chunk_usage(self) -> Self:
        """Require server token counts when per-chunk usage is requested.

        The first content chunk's token count is read only from server-reported
        per-chunk usage (in the server-token-count path). Without
        ``--use-server-token-count`` the client-tokenization path never populates
        it, so ``--per-chunk-usage`` would silently have no effect on inter-token
        latency."""
        if self.per_chunk_usage and not self.use_server_token_count:
            raise ValueError(
                "--per-chunk-usage requires --use-server-token-count "
                "(the first-chunk token count comes from server-reported per-chunk usage)"
            )
        if self.per_chunk_usage and self.type != EndpointType.CHAT:
            raise ValueError(
                "--per-chunk-usage requires endpoint type 'chat' "
                "(continuous_usage_stats is only injected on the chat endpoint)"
            )
        if self.per_chunk_usage and not self.streaming:
            raise ValueError(
                "--per-chunk-usage requires --streaming "
                "(continuous_usage_stats and inter-token latency apply only to "
                "streaming responses)"
            )
        return self

    @model_validator(mode="after")
    def _warn_inactive_allow_empty_content(self) -> Self:
        """Surface ``--allow-empty-content`` where the chat stream parser never sees it."""
        if self.allow_empty_content and (
            not self.streaming or self.type != EndpointType.CHAT
        ):
            _logger.warning(
                "--allow-empty-content has no effect unless --streaming is set with "
                f"endpoint type 'chat' (got streaming={self.streaming}, type "
                f"'{self.type}'). Drop --allow-empty-content to silence this warning."
            )
        return self

    @model_validator(mode="after")
    def _validate_responses_store_requires_server_token_count(self) -> Self:
        """Require server token counts when Responses stateful storage is requested.

        Passing ``store: true`` via ``--extra-inputs`` opts the Responses API into
        server-side persistence, which enables ``previous_response_id`` chaining:
        prior turns live server-side and only the newest turn is sent on the wire.
        Client-side ISL (the default) then reflects only that newest turn and
        undercounts the combined prompt the model actually prefills. The true count
        is only recoverable from the server's ``usage.prompt_tokens``, so require
        ``--use-server-token-count``.
        """
        if (
            self.type == EndpointType.RESPONSES
            and is_truthy_flag(self.extra.get("store"))
            and not self.use_server_token_count
        ):
            raise ValueError(
                "Responses endpoint with --extra-inputs store:true enables "
                "previous_response_id chaining, which sends only the newest turn "
                "on the wire; client-side Input Sequence Length would undercount "
                "the server-side prompt. Add --use-server-token-count so ISL comes "
                "from the server's usage.prompt_tokens, or remove store:true."
            )
        return self

    @model_validator(mode="after")
    def _validate_wait_for_model_coherent(self) -> Self:
        """Reject configurations where probe sub-options are set to non-default
        values without enabling the probe itself (timeout > 0). Catches typos like
        `--wait-for-model-interval 1` without a timeout value.

        Defaults (`interval=5.0`, `mode="inference"`) are tolerated even when
        they appear in ``model_fields_set`` (e.g. from a round-tripped config),
        so only explicit non-default values trigger the error.
        """
        if self.wait_for_model_timeout > 0:
            return self
        non_default = []
        if (
            "wait_for_model_interval" in self.model_fields_set
            and self.wait_for_model_interval != 5.0
        ):
            non_default.append("--wait-for-model-interval")
        if (
            "wait_for_model_mode" in self.model_fields_set
            and self.wait_for_model_mode != "inference"
        ):
            non_default.append("--wait-for-model-mode")
        if non_default:
            shown = ", ".join(non_default)
            raise ValueError(
                f"{shown} has no effect unless --wait-for-model-timeout is set "
                f"to a positive value. Set --wait-for-model-timeout to enable "
                f"the readiness probe."
            )
        return self

    @model_validator(mode="after")
    def _validate_request_content_type(self) -> Self:
        """Auto-select multipart for endpoints that declare requires_form_data."""
        from aiperf.plugin import plugins

        metadata = plugins.get_endpoint_metadata(self.type)
        requires_form_data = getattr(metadata, "requires_form_data", False)

        if self.request_content_type is None:
            if requires_form_data:
                self.request_content_type = RequestContentType.MULTIPART_FORM_DATA
            return self

        if self.request_content_type == RequestContentType.APPLICATION_JSON:
            if requires_form_data:
                raise ValueError(
                    f"endpoint type {self.type} requires multipart/form-data; "
                    "application/json is not supported."
                )
            return self

        if not requires_form_data:
            raise ValueError(
                f"request_content_type={self.request_content_type} is only supported for "
                f"endpoint types that accept form-data (e.g. image_edit, "
                f"video_generation); endpoint type {self.type} does not."
            )
        return self

    @model_validator(mode="after")
    def _validate_control_hook_paths(self) -> Self:
        if self.reset_kv_cache is not None:
            self.reset_kv_cache.path = require_relative_path(
                self.reset_kv_cache.path, "endpoint.reset_kv_cache.path"
            )
        if self.server_profiler is not None:
            self.server_profiler.start_path = require_relative_path(
                self.server_profiler.start_path, "endpoint.server_profiler.start_path"
            )
            self.server_profiler.stop_path = require_relative_path(
                self.server_profiler.stop_path, "endpoint.server_profiler.stop_path"
            )
        return self

    @model_validator(mode="after")
    def _validate_control_hooks_require_http(self) -> Self:
        if self.reset_kv_cache is None and self.server_profiler is None:
            return self
        # Transport None means auto-detect HTTP from URL — allowed.
        if self.transport is not None and self.transport != TransportType.HTTP:
            raise ValueError(
                "endpoint.reset_kv_cache and endpoint.server_profiler require "
                "HTTP transport; unsupported transport "
                f"{self.transport!r}"
            )
        return self

    @model_validator(mode="after")
    def _validate_sigv4_auth(self) -> Self:
        """Reject SigV4 configurations that would only fail at request time.

        Runs after ``_validate_request_content_type`` so the multipart check
        sees the auto-selected content type for form-data endpoints.
        """
        # Exactly what the user passed: this dict also answers "which flags did
        # they set", so a value derived from the transport must not appear here
        # or an unsigned run is rejected over a flag nobody typed.
        aws_flags = {
            "--aws-region": self.aws_region,
            "--aws-profile": self.aws_profile,
            "--aws-service": self.aws_service,
        }
        if self.auth_type != RequestSignerType.SIGV4:
            set_flags = sorted(
                flag for flag, val in aws_flags.items() if val is not None
            )
            if set_flags:
                raise ValueError(
                    f"{', '.join(set_flags)} has no effect unless --auth-type is set "
                    f"to 'sigv4'. Set --auth-type sigv4 to enable request signing."
                )
            return self

        # Only now that signing is confirmed does the transport get to supply
        # the credential scope; the signer resolves it from botocore's model.
        # Imported here, not at module scope: aiperf/auth/__init__.py reaches
        # back into aiperf.config via base_signer, so a top-level import is a
        # cycle. Deliberately the *same* function the signer uses -- a second
        # copy could drift and let this validator accept a scope the signer
        # then resolves to None, turning a config error into a mid-run 403.
        from aiperf.auth._transport_scope import transport_botocore_service_id

        aws_flags["--aws-service"] = self.aws_service or transport_botocore_service_id(
            self.transport
        )

        missing = [
            flag
            for flag in ("--aws-region", "--aws-service")
            if not (aws_flags[flag] or "").strip()
        ]
        if missing:
            raise ValueError(
                f"--auth-type sigv4 requires {' and '.join(missing)} to be set to a "
                f"non-empty value."
            )

        # Transport None means auto-detect HTTP from URL — allowed. Otherwise the
        # transport must actually sign: one lacking the _sign_if_needed call site
        # would resolve AWS credentials and sign nothing, silently producing
        # unauthenticated requests. Tested by capability rather than identity with
        # TransportType.HTTP, which would exclude every transport deriving from the
        # HTTP one -- they inherit the call site and do sign.
        if self.transport is not None and not _transport_signs(self.transport):
            raise ValueError(
                f"--auth-type {self.auth_type} requires a transport that signs "
                f"requests; {self.transport!r} does not. Signing is implemented by "
                "the HTTP transport and anything deriving from it."
            )

        if self.request_content_type == RequestContentType.MULTIPART_FORM_DATA:
            raise ValueError(
                f"--auth-type sigv4 does not support multipart/form-data requests, "
                f"which endpoint type {self.type} uses. Signing a multipart body is "
                f"not implemented, and sending it unsigned would silently produce "
                f"unauthenticated requests."
            )

        # SigV4 signing adds AWS credentials (Authorization header and optional
        # X-Amz-Security-Token) to outbound requests. Sending those over plain
        # HTTP would expose them to interception, so require https -- except for
        # loopback, where the headers never leave the machine and where the
        # documented mock-server workflow runs.
        insecure = [url for url in self.urls if _is_cleartext_remote(url)]
        if insecure:
            raise ValueError(
                f"--auth-type {self.auth_type} puts the signature and any session "
                "token into the request headers; sending those over plain HTTP "
                f"would disclose them: {', '.join(insecure)}. Use https:// URLs, "
                "or drop --auth-type."
            )

        # A warning, not an error: rejecting this stops anyone who keeps a key in
        # a shared config from enabling signing. The endpoints drop the key
        # whenever auth_type is set (base_endpoint, anthropic_messages). The
        # serialized placeholder is skipped: Kubernetes service containers
        # validate before the real key is injected, and sweep subprocesses
        # revalidate per variation, so it would repeat in every log.
        from aiperf.common.redact import REDACTED_VALUE

        if self.api_key and self.api_key != REDACTED_VALUE:
            _logger.warning(
                f"--api-key is ignored when --auth-type {self.auth_type} is set: "
                "request signing replaces API-key auth, so the key is not sent. "
                "Drop --api-key to silence this warning."
            )
        return self
