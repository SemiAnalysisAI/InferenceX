# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

"""Nested configs for endpoint control hooks (reset_kv_cache, server_profiler)."""

from __future__ import annotations

from typing import Annotated, Any

from pydantic import (
    BeforeValidator,
    ConfigDict,
    Field,
    HttpUrl,
    JsonValue,
    field_serializer,
    field_validator,
)

from aiperf.common.finite import FiniteFloat
from aiperf.config.base import BaseConfig

DEFAULT_RESET_KV_CACHE_PATH = "/reset_prefix_cache"
DEFAULT_SERVER_PROFILER_START_PATH = "/start_profile"
DEFAULT_SERVER_PROFILER_STOP_PATH = "/stop_profile"
DEFAULT_CONTROL_HOOK_TIMEOUT_SECONDS = 30.0
"""Default timeout for reset_kv_cache/server_profiler POSTs.

Deliberately independent of ``endpoint.timeout`` (tuned for inference
requests and defaults to 6 hours) so a stalled control-plane POST fails
fast instead of appearing to hang indefinitely.
"""
DEFAULT_RESET_KV_CACHE_MAX_RETRY_SECONDS = 60.0
"""Default total budget for retrying a retryable reset_kv_cache POST failure.

Covers cases where the server is still finishing unrelated control-plane
work (e.g. a profiler stop) and briefly can't accept a reset_kv_cache call.
"""
DEFAULT_RETRY_BACKOFF_SECONDS = 1.0
"""Initial delay between retryable reset_kv_cache POST attempts."""
DEFAULT_RETRY_BACKOFF_CAP_SECONDS = 8.0
"""Ceiling on the exponential backoff delay between retry attempts."""
DEFAULT_RETRY_BACKOFF_MULTIPLIER = 2.0
"""Growth factor applied to the backoff delay after each retry attempt."""
RESET_KV_CACHE_RETRYABLE_STATUS_CODES = frozenset({409, 423, 429, 503})
"""HTTP statuses treated as transient for reset_kv_cache and retried.

409 Conflict / 423 Locked / 429 Too Many Requests / 503 Service Unavailable
are standard signals for "server busy with transient state, try again" -
e.g. a server reporting a profiler-cleanup race explicitly instead of
holding the socket open. Statuses outside this set (400/401/403/404/...)
are real rejections and fail immediately.
"""


class ResetKvCacheConfig(BaseConfig):
    model_config = ConfigDict(extra="forbid")

    timeout_seconds: Annotated[
        FiniteFloat | None,
        Field(
            default=None,
            gt=0,
            description="Timeout in seconds for the reset_kv_cache POST. "
            f"When unset, uses {DEFAULT_CONTROL_HOOK_TIMEOUT_SECONDS}s.",
        ),
    ] = None
    max_retry_seconds: Annotated[
        FiniteFloat | None,
        Field(
            default=None,
            ge=0,
            description="Total time budget in seconds for retrying a "
            "retryable reset_kv_cache POST failure: a timeout/connection "
            "error, or a response with status in "
            "RESET_KV_CACHE_RETRYABLE_STATUS_CODES (409/423/429/503). "
            "Other non-2xx responses are never retried. "
            f"When unset, uses {DEFAULT_RESET_KV_CACHE_MAX_RETRY_SECONDS}s.",
        ),
    ] = None
    path: Annotated[
        str | None,
        Field(
            default=None,
            description="Relative path for KV-cache reset. "
            f"Default: {DEFAULT_RESET_KV_CACHE_PATH}.",
        ),
    ] = None


class ServerProfilerConfig(BaseConfig):
    model_config = ConfigDict(extra="forbid", allow_inf_nan=False)

    urls: Annotated[
        list[HttpUrl] | None,
        Field(
            default=None,
            min_length=1,
            description="Profiler control server URLs. When unset, uses the "
            "inference endpoint origins. Paths and queries are ignored.",
        ),
    ] = None
    start_body: Annotated[
        dict[str, JsonValue] | None,
        Field(
            default=None,
            description="JSON object sent with profiler start requests. "
            "When unset, sends an empty body.",
            json_schema_extra={"x-kubernetes-preserve-unknown-fields": True},
        ),
    ] = None

    @field_validator("urls")
    @classmethod
    def _reject_url_userinfo(cls, value: list[HttpUrl] | None) -> list[HttpUrl] | None:
        """Profiler credentials use the endpoint's supported header transport."""
        if value is not None and any(
            url.username is not None or url.password is not None for url in value
        ):
            raise ValueError(
                "Profiler URLs must not include userinfo; configure endpoint "
                "authentication headers instead."
            )
        return value

    @field_serializer("urls")
    def _redact_urls(self, value: list[HttpUrl] | None, info: Any) -> list[str] | None:
        """Apply the endpoint URL credential policy to profiler targets."""
        if value is None:
            return None
        from aiperf.common.redact import redact_url

        urls = [str(url) for url in value]
        context = getattr(info, "context", None)
        if isinstance(context, dict) and context.get("include_secrets"):
            return urls
        return [redact_url(url) for url in urls]

    timeout_seconds: Annotated[
        FiniteFloat | None,
        Field(
            default=None,
            gt=0,
            description="Timeout in seconds for profiler start/stop POSTs. "
            f"When unset, uses {DEFAULT_CONTROL_HOOK_TIMEOUT_SECONDS}s.",
        ),
    ] = None
    start_path: Annotated[
        str | None,
        Field(
            default=None,
            description="Relative path for profiler start. "
            f"Default: {DEFAULT_SERVER_PROFILER_START_PATH}.",
        ),
    ] = None
    stop_path: Annotated[
        str | None,
        Field(
            default=None,
            description="Relative path for profiler stop. "
            f"Default: {DEFAULT_SERVER_PROFILER_STOP_PATH}.",
        ),
    ] = None


def require_relative_path(path: str | None, field_name: str) -> str | None:
    """Validate a control-hook path is relative and leading-slash, or None.

    Absolute URLs are rejected so hook paths always resolve against the
    endpoint's own origin rather than redirecting control traffic elsewhere.
    """
    if path is None:
        return None
    if "://" in path or not path.startswith("/"):
        raise ValueError(
            f"{field_name} must be a relative path starting with '/', got {path!r}"
        )
    return path


def parse_enabled_or_config(model_cls: type[BaseConfig]) -> BeforeValidator:
    """Build a BeforeValidator for ``false | true | object`` nested configs."""

    def _parse(value: Any) -> BaseConfig | None:
        if value is None or value is False:
            return None
        if value is True:
            return model_cls()
        if isinstance(value, model_cls):
            return value
        if isinstance(value, dict):
            return model_cls.model_validate(value)
        raise ValueError(
            f"Expected false | true | object for {model_cls.__name__}, got {type(value).__name__}"
        )

    return BeforeValidator(_parse)
