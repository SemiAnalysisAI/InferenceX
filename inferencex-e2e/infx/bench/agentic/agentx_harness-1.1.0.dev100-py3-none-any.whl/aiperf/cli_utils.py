# SPDX-FileCopyrightText: Copyright (c) 2025 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

# NOTE: These should be inline imported in cli commands to avoid
# pulling in heavy dependencies at CLI startup time.

from __future__ import annotations

import sys
from contextlib import AbstractContextManager

from rich.align import AlignMethod
from rich.console import Console, RenderableType
from rich.markup import escape
from rich.panel import Panel
from rich.style import StyleType
from rich.text import Text

from aiperf.common.aiperf_logger import AIPerfLogger

console = Console(stderr=True)

_logger = AIPerfLogger("aiperf")


def raise_startup_error_and_exit(
    message: RenderableType,
    *,
    text_color: StyleType | None = None,
    title: str = "Error",
    exit_code: int = 1,
    border_style: StyleType = "bold red",
    title_align: AlignMethod = "left",
) -> None:
    """Raise a startup error and exit the program.

    Args:
        message: The message to display. Can be a string or a rich renderable.
        text_color: The text color to use.
        title: The title of the error.
        exit_code: The exit code to use.
        border_style: The border style to use.
        title_align: The alignment of the title.
    """
    if isinstance(message, str):
        message = f"[{text_color}]{message}[/{text_color}]" if text_color else message

    console.print(
        Panel(
            renderable=message,
            title=title,
            title_align=title_align,
            border_style=border_style,
        )
    )
    console.file.flush()

    sys.exit(exit_code)


class exit_on_error(AbstractContextManager):
    """Context manager that exits the program if an error occurs.

    Args:
        *exceptions: The exceptions to exit on. If no exceptions are provided, all exceptions will be caught.
        message: The message to display. Can be a string or a rich renderable. Will be formatted with the exception as `{e}`.
        text_color: The text color to use.
        title: The title of the error.
        exit_code: The exit code to use.
        show_traceback: Whether to show the full exception traceback. Defaults to True.
        quiet_for: Exception types whose tracebacks should be suppressed (a clean
            error panel is still rendered). Useful for expected user-facing errors
            like ``ConfigurationError`` where the traceback is noise.
    """

    def __init__(
        self,
        *exceptions: type[BaseException],
        message: RenderableType = "{e}",
        text_color: StyleType | None = None,
        title: str = "Error",
        exit_code: int = 1,
        show_traceback: bool = True,
        quiet_for: tuple[type[BaseException], ...] = (),
    ):
        self.message: RenderableType = message
        self.text_color: StyleType | None = text_color
        self.title: str = title
        self.exit_code: int = exit_code
        self.exceptions: tuple[type[BaseException], ...] = exceptions
        self.show_traceback: bool = show_traceback
        self.quiet_for: tuple[type[BaseException], ...] = quiet_for

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        if exc_type is None:
            return

        if (
            not self.exceptions
            and not isinstance(exc_value, (SystemExit | KeyboardInterrupt))
        ) or issubclass(exc_type, self.exceptions):
            # Only show full traceback if requested AND the exception is not
            # in the quiet_for allowlist (expected errors render a clean panel only).
            # Don't show locals as they are very noisy and not useful for most errors
            if self.show_traceback and not (
                self.quiet_for and issubclass(exc_type, self.quiet_for)
            ):
                console.print_exception(
                    show_locals=False,
                    max_frames=10,
                    word_wrap=True,
                    width=console.width,
                )
                console.file.flush()

            # Escape the exception text before substituting it into the
            # markup template: exception messages routinely contain square
            # brackets (e.g. ``list[str]``, ``uv pip install 'aiperf[accuracy]'``)
            # that Rich would otherwise parse as style tags and silently drop,
            # corrupting the message. Any intentional markup in the template
            # itself is preserved.
            message = (
                self.message.format(e=escape(_describe_error(exc_value)))
                if isinstance(self.message, str)
                else self.message
            )
            raise_startup_error_and_exit(
                message,
                text_color=self.text_color,
                title=self.title,
                exit_code=self.exit_code,
            )


def _describe_error(error: BaseException) -> str:
    """Render an error for the terminal without echoing credentials.

    Config errors routinely quote dataset or endpoint URLs, which may carry a
    presigned signature or userinfo.
    """
    from pydantic import ValidationError

    from aiperf.common.redact import redact_text
    from aiperf.config.loader.errors import describe_validation_error

    if isinstance(error, ValidationError):
        return redact_text(describe_validation_error(error))
    return redact_text(str(error))


def print_developer_mode_warning() -> None:
    """Print a warning message to the console if developer mode is enabled."""

    panel = Panel(
        Text(
            "Developer Mode is active. This is a developer-only feature. Use at your own risk.",
            style="yellow",
        ),
        title="AIPerf Developer Mode",
        border_style="bold yellow",
        title_align="left",
    )
    console.print(panel)
    console.file.flush()


def warn_osl_without_ignore_eos() -> None:
    """Log a warning when --osl is used without ignore_eos or min_tokens in extra inputs."""

    _logger.warning(
        "Using --osl without ignore_eos or min_tokens in --extra-inputs. "
        "Output sequence length cannot be guaranteed unless the server honors these parameters. "
        "Consider: --extra-inputs ignore_eos:true (generate until max_tokens) "
        "or --extra-inputs min_tokens:<value> (set minimum output length)."
    )


def warn_accuracy_temperature() -> None:
    """Log a warning when accuracy mode is used without temperature=0 in extra inputs."""

    _logger.warning(
        "Running accuracy benchmark without temperature=0 in --extra-inputs. "
        "Most LLM servers default to temperature=1.0, introducing random sampling and run-to-run variance. "
        "For reproducible results matching lighteval, add: --extra-inputs '{\"temperature\": 0}'"
    )
