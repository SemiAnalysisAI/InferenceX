# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
import asyncio
import multiprocessing
import os
import uuid
from collections import Counter
from multiprocessing import Process
from multiprocessing.context import SpawnProcess

from pydantic import BaseModel, ConfigDict, Field

from aiperf.common.bootstrap import bootstrap_and_run_service
from aiperf.common.constants import IS_WINDOWS
from aiperf.common.enums import ServiceRegistrationStatus
from aiperf.common.environment import Environment
from aiperf.common.exceptions import AIPerfError
from aiperf.common.types import ServiceTypeT
from aiperf.plugin.enums import ServiceType

if IS_WINDOWS:
    # Windows multiprocessing has no fork context — ``ForkProcess`` is
    # undefined on ``multiprocessing.context`` there. Define a stub so the
    # type union below evaluates at class-definition time without the
    # import raising. The stub is never instantiated on Windows because
    # spawn is the only start method available there; it exists purely
    # so Pydantic's annotation resolution doesn't NameError.
    class ForkProcess:  # type: ignore[no-redef]
        pass
else:
    from multiprocessing.context import ForkProcess
from aiperf.controller.base_service_manager import BaseServiceManager


class MultiProcessRunInfo(BaseModel):
    """Information about a service running as a multiprocessing process."""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    process: Process | SpawnProcess | ForkProcess | None = Field(
        default=None,
        description=(
            "The multiprocessing Process handle for the spawned service. "
            "Subclass varies by start method: ``ForkProcess`` on Linux "
            "fork-context, ``SpawnProcess`` on Windows/macOS spawn-context."
        ),
    )
    service_type: ServiceTypeT = Field(
        ...,
        description="Type of service running in the process",
    )
    service_id: str = Field(
        ...,
        description="ID of the service running in the process",
    )


class MultiProcessServiceManager(BaseServiceManager):
    """
    Service Manager for starting and stopping services as multiprocessing processes.
    """

    def __init__(
        self,
        required_services: dict[ServiceTypeT, int],
        log_queue: "multiprocessing.Queue | None" = None,
        **kwargs,
    ):
        super().__init__(required_services, **kwargs)
        self.multi_process_info: list[MultiProcessRunInfo] = []
        self.log_queue = log_queue
        # Kept past reaping: a worker's SERVICE_ERROR can arrive after the
        # registration-wait reaper has dropped it from multi_process_info.
        self._spawned_worker_ids: set[str] = set()
        # Exit codes of processes the registration wait reaped, which removes
        # their entries: the controller's start-up diagnosis reads them later.
        self._reaped_exit_codes: dict[str, int | None] = {}

    async def run_service(
        self, service_type: ServiceTypeT, num_replicas: int = 1
    ) -> None:
        """Run a service with the given number of replicas."""
        from aiperf.plugin import plugins

        service_metadata = plugins.get_service_metadata(service_type)
        for _ in range(num_replicas):
            service_id = (
                f"{service_type}_{uuid.uuid4().hex[:8]}"
                if service_metadata.replicable
                else str(service_type)
            )
            process = Process(
                target=bootstrap_and_run_service,
                name=f"{service_type}_process",
                kwargs={
                    "service_type": service_type,
                    "service_id": service_id,
                    "run": self.run,
                    "log_queue": self.log_queue,
                    # Controller PID for the child's PR_SET_PDEATHSIG guard, so a
                    # hard-killed controller cannot orphan its service processes.
                    "controller_pid": os.getpid(),
                },
                daemon=True,
            )

            process.start()

            self.debug(
                lambda pid=process.pid,
                type=service_type: f"Service {type} started as process (pid: {pid})"
            )

            self.multi_process_info.append(
                MultiProcessRunInfo(
                    process=process,
                    service_type=service_type,
                    service_id=service_id,
                )
            )
            if service_type == ServiceType.WORKER:
                self._spawned_worker_ids.add(service_id)

    async def stop_service(
        self, service_type: ServiceTypeT, service_id: str | None = None
    ) -> list[BaseException | None]:
        self.debug(lambda: f"Stopping {service_type} process(es) with id: {service_id}")
        tasks = []
        for info in list(self.multi_process_info):
            if info.service_type == service_type and (
                service_id is None or info.service_id == service_id
            ):
                task = asyncio.create_task(self._wait_for_process(info))
                task.add_done_callback(
                    lambda _, info=info: self.multi_process_info.remove(info)
                )
                tasks.append(task)
        return await asyncio.gather(*tasks, return_exceptions=True)

    async def shutdown_all_services(self) -> list[BaseException | None]:
        """Stop all required services as multiprocessing processes."""
        self.debug("Stopping all service processes")

        # Wait for all to finish in parallel
        return await asyncio.gather(
            *[self._wait_for_process(info) for info in self.multi_process_info],
            return_exceptions=True,
        )

    async def kill_all_services(self) -> list[BaseException | None]:
        """Kill all required services as multiprocessing processes."""
        self.debug("Killing all service processes")

        # Kill all processes
        for info in self.multi_process_info:
            if info.process:
                info.process.kill()

        # Wait for all to finish in parallel
        return await asyncio.gather(
            *[self._wait_for_process(info) for info in self.multi_process_info],
            return_exceptions=True,
        )

    async def wait_for_all_services_registration(
        self,
        stop_event: asyncio.Event,
        timeout_seconds: float = Environment.SERVICE.REGISTRATION_TIMEOUT,
    ) -> None:
        """Wait for all required services to be registered.

        Args:
            stop_event: Event to check if operation should be cancelled
            timeout_seconds: Maximum time to wait in seconds

        Raises:
            Exception if any service failed to register, None otherwise
        """
        self.debug("Waiting for all required services to register...")

        # Wait for every service we've actually spawned, not just the ones in
        # required_services. Optional services (GPU telemetry, server metrics,
        # API) are started via run_service() and tracked in multi_process_info
        # but never added to required_services. On slow targets (Windows VDI
        # multiprocessing.spawn) those optional services register hundreds of
        # ms after the core ones — if we only waited on required_services, the
        # PROFILE_CONFIGURE would fan out before the optionals had
        # subscribed, leaving them un-configured and their data missing from
        # the final export.
        #
        # Count replicas per type, not per-type presence: a replicated
        # service (e.g. RECORD_PROCESSOR, scaled with worker count) has
        # multiple multi_process_info entries sharing one service_type. A
        # replica that registers after the first can otherwise miss
        # DatasetManager's one-shot DatasetConfiguredNotification and hang
        # until DATASET.CONFIGURATION_TIMEOUT.
        required_counts: Counter[ServiceTypeT] = Counter(
            info.service_type for info in self.multi_process_info
        ) or Counter(self.required_services)

        # TODO: Can this be done better by using asyncio.Event()?

        async def _wait_for_registration():
            while not stop_event.is_set():
                registered_counts = Counter(
                    service_info.service_type
                    for service_info in self.service_id_map.values()
                    if service_info.registration_status
                    == ServiceRegistrationStatus.REGISTERED
                )

                if all(
                    registered_counts[service_type] >= count
                    for service_type, count in required_counts.items()
                ):
                    return

                self._reap_dead_processes_during_registration(required_counts)

                # Wait a bit before checking again
                await asyncio.sleep(0.5)

        try:
            await asyncio.wait_for(_wait_for_registration(), timeout=timeout_seconds)
        except TimeoutError as e:
            registered_counts = Counter(
                service_info.service_type
                for service_info in self.service_id_map.values()
                if service_info.registration_status
                == ServiceRegistrationStatus.REGISTERED
            )

            for service_type, count in required_counts.items():
                registered = registered_counts[service_type]
                if registered < count:
                    self.error(
                        f"Service {service_type} failed to fully register within "
                        f"timeout ({registered}/{count} replicas registered)"
                    )

            raise AIPerfError("Some services failed to register within timeout") from e

    def spawned_worker_ids(self) -> frozenset[str]:
        """Every worker spawned here, including those already reaped.

        The SystemController uses this to recognize a start-up failure from one
        of its own unregistered workers. The reaper may drop a dead worker
        before its SERVICE_ERROR arrives, so identity cannot come from
        ``multi_process_info``; whether a worker can still start is
        ``get_service_liveness``'s question.
        """
        return frozenset(self._spawned_worker_ids)

    def live_worker_ids(self) -> frozenset[str]:
        """Workers whose process is alive, in one pass over the process list.

        The controller asks this once per worker start-up report rather than
        calling ``get_service_liveness`` for every worker, which is a linear
        scan each, made staggered failures cubic in the worker count.
        """
        return frozenset(
            info.service_id
            for info in self.multi_process_info
            if info.service_type == ServiceType.WORKER
            and info.process is not None
            and info.process.is_alive()
        )

    def get_service_liveness(self, service_id: str) -> bool | None:
        """Answer liveness from the real ``multiprocessing.Process`` handle.

        Local runs have authoritative ground truth that the heartbeat watchdog
        would otherwise only guess at. ``None`` is returned for services this
        manager did not spawn (nothing to consult), and a missing process
        handle counts as dead -- the spawn call failed before producing one,
        matching ``_reap_dead_processes_during_registration``.
        """
        for info in self.multi_process_info:
            if info.service_id == service_id:
                return info.process is not None and info.process.is_alive()
        # Spawned here but since reaped: known dead, not unknown.
        return False if service_id in self._spawned_worker_ids else None

    def get_service_exit_code(self, service_id: str) -> int | None:
        for info in self.multi_process_info:
            if info.service_id == service_id and info.process is not None:
                return info.process.exitcode
        return self._reaped_exit_codes.get(service_id)

    def _reap_dead_processes_during_registration(
        self, required_counts: "Counter[ServiceTypeT]"
    ) -> None:
        """Reap dead processes mid-registration: required dying is fatal,
        optional dying gets a warning and is dropped from the wait set.

        Without this differentiation, an optional service crashing during
        init (e.g. GPU telemetry missing a DCGM endpoint) would kill the
        entire benchmark. ``process is None`` is treated as dead — a None
        process means the spawn call failed before producing a handle.

        Mutates ``required_counts`` (decrements the expected replica count
        for optional dead types) and ``self.multi_process_info`` (removes
        optional dead entries) so the caller's wait loop can converge.

        Raises:
            AIPerfError: if any required service has died.
        """
        for info in list(self.multi_process_info):
            is_dead = info.process is None or not info.process.is_alive()
            if not is_dead:
                continue
            exit_code = info.process.exitcode if info.process else None
            if info.service_type in self.required_services:
                raise AIPerfError(
                    f"Required service {info.service_id} died before "
                    f"registering (exit code {exit_code})"
                )
            required_counts[info.service_type] -= 1
            self._reaped_exit_codes[info.service_id] = exit_code
            self.multi_process_info.remove(info)
            if info.service_type == ServiceType.WORKER:
                # Not "continuing without it": whether the run can continue is
                # the SystemController's start-up decision, not this wait's.
                self.warning(
                    f"Worker {info.service_id!r} exited before registering "
                    f"(exit code {exit_code})."
                )
            else:
                self.warning(
                    f"Optional service {info.service_id!r} exited before "
                    f"registering (exit code {exit_code}); continuing "
                    f"benchmark without it."
                )

    async def _wait_for_process(self, info: MultiProcessRunInfo) -> None:
        """Force-kill a service process that is still alive after bus shutdown.

        Children install ``signal.SIG_IGN`` for SIGTERM in
        ``bootstrap_and_run_service`` (to avoid C-extension teardown SIGSEGVs).
        Graceful exit is exclusively via the ``SHUTDOWN`` command on the control
        bus; by the time we reach here that path has already been given its
        delivery grace. ``Process.terminate()`` (SIGTERM) is therefore a
        no-op on POSIX, and waiting ``TASK_CANCEL_TIMEOUT_SHORT`` (~2s) on
        ``join()`` *before* ``kill()`` only burns wall-clock per process.
        Go straight to ``kill()`` (SIGKILL on POSIX; ``TerminateProcess``
        on Windows, where ``kill``/``terminate`` are equivalent), then
        ``join()`` to reap so the child does not linger as a zombie.
        """
        if not info.process or not info.process.is_alive():
            return

        self.warning(
            f"Service {info.service_type} process (pid: {info.process.pid}) "
            "still alive after bus shutdown grace; killing (SIGKILL / "
            "TerminateProcess — children ignore SIGTERM)"
        )
        info.process.kill()
        await asyncio.to_thread(
            info.process.join, timeout=Environment.SERVICE.TASK_CANCEL_TIMEOUT_SHORT
        )
        if info.process.is_alive():
            self.warning(
                f"Service {info.service_type} process (pid: {info.process.pid}) "
                "still alive after kill()+join timeout"
            )

    async def wait_for_all_services_start(
        self,
        stop_event: asyncio.Event,
        timeout_seconds: float = Environment.SERVICE.START_TIMEOUT,
    ) -> None:
        """Wait for all required services to be started."""
        raise NotImplementedError(
            "MultiprocessServiceManager.wait_for_all_services_start is not wired up. "
            "Multiprocess services self-report START via heartbeats; if a future caller "
            "needs an explicit barrier here, implement it rather than calling this stub."
        )
