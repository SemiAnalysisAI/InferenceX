# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
"""Centralized redaction utilities for sensitive data (API keys, auth tokens, etc.)."""

import re
import shlex
from collections.abc import Sequence
from copy import deepcopy
from typing import Any
from urllib.parse import unquote_plus

REDACTED_VALUE = "<redacted>"

# Header names (case-insensitive) whose values carry credentials.
# Covers standard HTTP auth plus all major LLM/cloud API providers:
#   - authorization / proxy-authorization: Bearer tokens (OpenAI, Groq, Cohere, Mistral,
#     Together, HuggingFace, Google, NVIDIA NIM, etc.), Basic auth
#   - x-api-key: Anthropic
#   - api-key: Azure OpenAI
#   - ocp-apim-subscription-key: Azure API Management
#   - x-goog-api-key: Google Cloud / Vertex AI
#   - x-functions-key: Azure Functions
#   - aeg-sas-key: Azure Event Grid
#   - x-amz-security-token: AWS STS temporary credentials
#   - cookie / set-cookie: session credentials
#   - x-auth-token / x-access-token / x-session-token: common custom auth headers
_SENSITIVE_HEADER_NAMES = frozenset(
    {
        "authorization",
        "proxy-authorization",
        "x-api-key",
        "api-key",
        "ocp-apim-subscription-key",
        "x-goog-api-key",
        "x-functions-key",
        "aeg-sas-key",
        "x-amz-security-token",
        "cookie",
        "set-cookie",
        "x-auth-token",
        "x-access-token",
        "x-session-token",
        "x-csrf-token",
        "x-xsrf-token",
    }
)

# ``EndpointConfig.headers`` accepts arbitrary user-supplied headers, so an
# exact-name allowlist can never be complete: a deployment may authenticate with
# ``X-Acme-Token`` or ``X-Tenant-Secret``. Any header whose name contains one of
# these fragments is therefore treated as credential-bearing. Deliberately
# fail-safe: over-redacting a benign header only costs readability, while
# under-redacting leaks a credential into artifacts, logs, and (via
# ``validate_kubernetes_credential_transport``) an unencrypted K8s ConfigMap.
_SENSITIVE_HEADER_SUBSTRINGS: tuple[str, ...] = (
    "auth",
    "token",
    "secret",
    "password",
    "passwd",
    "credential",
    "cookie",
    "apikey",
    "api-key",
    "api_key",
    "session",
    "signature",
    "sas-key",
    "access-key",
    "private-key",
)


def is_sensitive_header_name(name: str) -> bool:
    """Return True if a header name is treated as credential-bearing.

    Single source of truth for every header gate: the redactors, the
    out-of-band credential extractor, and the Kubernetes Secret-transport
    validator all route through this so they cannot disagree about which
    headers need protection.

    Args:
        name: Header name, any casing.
    """
    lowered = name.lower()
    if lowered in _SENSITIVE_HEADER_NAMES:
        return True
    return any(fragment in lowered for fragment in _SENSITIVE_HEADER_SUBSTRINGS)


# Pre-compiled regex patterns for redacting credentials in arbitrary strings.
# Patterns must handle plain text ("Authorization: Bearer <key>"),
# JSON-serialized ('"Authorization":"Bearer <key>"'), and Python repr
# ("'Authorization': 'Bearer <key>'") forms.
# Build alternation from non-auth headers for string-level redaction.
# Authorization/proxy-authorization are handled separately (they have Bearer/Basic schemes).
_NON_AUTH_SENSITIVE_HEADERS = _SENSITIVE_HEADER_NAMES - {
    "authorization",
    "proxy-authorization",
}
_NON_AUTH_HEADER_ALT = "|".join(
    re.escape(h) for h in sorted(_NON_AUTH_SENSITIVE_HEADERS)
)

_STRING_REDACTION_PATTERNS = [
    # Authorization / Proxy-Authorization: redact the entire value including multi-token
    # schemes like SigV4 (AWS4-HMAC-SHA256 Credential=..., Signature=...).
    # Uses [^'"\}\n]+ to consume everything up to the enclosing quote/brace/newline,
    # which correctly handles JSON, Python repr, and plain text contexts.
    (
        re.compile(
            r"""(?i)((?:proxy-)?authorization['":\s]*(?:bearer|basic)?\s*)[^'"\}\n]+"""
        ),
        rf"\1{REDACTED_VALUE}",
    ),
    # api_key=<value>, token=<value>, secret=<value> (query string style)
    (
        re.compile(r"(?i)\b(api[-_ ]?key|token|secret)\s*=\s*[^&\s]+"),
        rf"\1={REDACTED_VALUE}",
    ),
    # Other credential-carrying headers (plain text, JSON, Python repr)
    (
        re.compile(rf"""(?i)({_NON_AUTH_HEADER_ALT})['":\s]*[^\s,;'"\}}]+"""),
        rf"\1: {REDACTED_VALUE}",
    ),
]


def redact_headers(headers: dict[str, str] | None) -> dict[str, str] | None:
    """Return a copy of headers with sensitive values replaced by REDACTED_VALUE.

    Matches via :func:`is_sensitive_header_name` (case-insensitive: the exact
    provider header list plus credential-shaped custom names).
    Returns None if input is None.
    """
    if headers is None:
        return None
    return {
        k: (REDACTED_VALUE if is_sensitive_header_name(k) else v)
        for k, v in headers.items()
    }


def extract_sensitive_headers(headers: dict[str, str] | None) -> dict[str, str]:
    """Return only the entries from ``headers`` that ``redact_headers`` would
    redact, keyed by their original (un-lowercased) name.

    Used by orchestrator IPC: ``EndpointConfig.headers`` is redacted on every
    JSON dump, so the subprocess loads a ``run_config.json`` whose
    credential-bearing headers carry the literal string ``<redacted>``. The
    parent forwards the real values out-of-band via ``AIPERF_INJECTED_HEADERS``
    and the child overlays them back onto the loaded config.
    """
    if not headers:
        return {}
    return {k: v for k, v in headers.items() if is_sensitive_header_name(k)}


def redact_header_tuples(
    headers: list[tuple[str, str]],
) -> list[tuple[str, str]]:
    """Return a copy of header tuples with sensitive values replaced by REDACTED_VALUE.

    Same logic as redact_headers but for (name, value) tuple format
    used by InputConfig.headers.
    """
    return [
        (name, REDACTED_VALUE if is_sensitive_header_name(name) else value)
        for name, value in headers
    ]


def redact_string(value: str) -> str:
    """Redact credentials embedded in an arbitrary string (e.g., exception repr)."""
    for pattern, repl in _STRING_REDACTION_PATTERNS:
        value = pattern.sub(repl, value)
    return value


# CLI argument patterns that contain secrets.
# Each pattern captures a prefix group (\1) and replaces the secret with REDACTED_VALUE.
# Build header name alternation from _SENSITIVE_HEADER_NAMES so they stay in sync.
_SENSITIVE_HEADER_ALT = "|".join(re.escape(h) for h in _SENSITIVE_HEADER_NAMES)
_SHELL_WORD_PATTERN = r"""(?:[^\s'"\\]|\\.|'[^']*'|"(?:\\.|[^"\\])*")+"""
_CLI_SECRET_PATTERNS: Sequence[re.Pattern[str]] = (
    # --api-key <value> or --api-key=<value>
    re.compile(r"(--api-key[\s=])'?[^'\s]+'?"),
    # Match a complete shell word, including concatenated quoted/escaped parts.
    re.compile(r"(--server-profiler-start-body(?:\s+|=))" + _SHELL_WORD_PATTERN),
    # Single-quoted: --header 'Authorization:Bearer token' / -H 'X-API-Key:val'
    re.compile(rf"((?:--header|-H)\s+)'(?i:{_SENSITIVE_HEADER_ALT})[:\s][^']+'"),
    # Double-quoted: --header "Authorization:Bearer token"
    re.compile(rf'((?:--header|-H)\s+)"(?i:{_SENSITIVE_HEADER_ALT})[:\s][^"]+"'),
    # Unquoted with space-separated value: --header Authorization:Bearer token
    re.compile(rf"((?:--header|-H)\s+)(?i:{_SENSITIVE_HEADER_ALT})\S*\s+\S+"),
    # Unquoted single-token: --header X-API-Key:value
    re.compile(rf"((?:--header|-H)\s+)(?i:{_SENSITIVE_HEADER_ALT})\S+"),
)

# URL-typed CLI flags whose values may carry `user:password@` userinfo. Redaction
# rewrites the *value only* — preserves the flag, surrounding quotes, and any
# non-credential URL parts. Kept separate from _CLI_SECRET_PATTERNS because the
# replacement is structural (strip userinfo) rather than wholesale (<redacted>).
_URL_FLAG_ALT = "|".join(
    re.escape(f)
    for f in (
        "--url",
        "-u",
        "--server-profiler-url",
        "--otel-url",
        "--mlflow-tracking-uri",
        "--input-file",
    )
)
# Match: (flag)(sep)(open quote?)(value)(close quote?)
# Group 1: flag + separator, group 2: optional open quote, group 3: raw value,
# group 4: optional close quote. The value is captured as non-greedy so the
# close quote and value stay aligned.
_URL_FLAG_PATTERN = re.compile(
    rf"((?:{_URL_FLAG_ALT})[\s=])(['\"])?([^'\"\s]+)(['\"])?"
)

# Safety net for stray scheme-prefixed URLs carrying userinfo — required because
# URL-typed flags like ``--url`` use ``consume_multiple=True`` (see
# ``endpoint_config.py``), so 2nd+ values are not captured by the per-flag
# matcher. The userinfo segment is bounded by /, ?, #, whitespace, quote, @ so
# a path ``@`` like ``http://host/users@example.com`` never matches, and
# non-URL args with ``@`` (e.g. ``--model foo@bar``) are untouched.
_STRAY_URL_USERINFO_PATTERN = re.compile(r"([A-Za-z][A-Za-z0-9+.\-]*://)[^\s'\"@/?#]+@")

# Query parameters that conventionally carry credentials. The pattern matches a
# complete parameter name (it is applied with ``fullmatch``) so ordinary values
# such as ``token_count`` and ``monkey`` are preserved. ``[-_ ]?`` rather than
# ``[-_]?`` because ``+`` in a query string decodes to a space, so ``api+key``
# is the same parameter as ``api_key``.
_SENSITIVE_URL_QUERY_PARAMETER_NAME_PATTERN = re.compile(
    r"(?:"
    r"api[-_ ]?key|apikey|key|token|access[-_ ]?token|auth[-_ ]?token|"
    r"bearer[-_ ]?token|id[-_ ]?token|refresh[-_ ]?token|secret|"
    r"client[-_ ]?secret|password|passwd|credential|access[-_ ]?key[-_ ]?id|"
    r"awsaccesskeyid|sig|signature|x-amz-signature|x-amz-security-token|"
    r"x-amz-credential|x-goog-signature|x-goog-credential"
    r")",
    re.IGNORECASE,
)

# Splits a URL query string into (separator, raw name, raw value) triples. The
# name/value spans stop at ``&`` and ``#`` so a fragment is never swallowed.
_URL_QUERY_PARAMETER_PATTERN = re.compile(r"([?&])([^=&#]*)=([^&#]*)")

# Flag tokens that open a ``consume_multiple=True`` URL-value window. Only
# these flags have the multi-value leak — ``--otel-url`` / ``--mlflow-tracking-uri``
# take a single value and are already covered by ``_URL_FLAG_PATTERN``.
_MULTI_VALUE_URL_FLAGS: frozenset[str] = frozenset(
    {"--url", "-u", "--server-profiler-url"}
)


def _redact_url_flag_match(match: re.Match[str]) -> str:
    prefix = match.group(1)
    open_quote = match.group(2) or ""
    value = match.group(3)
    close_quote = match.group(4) or ""
    return f"{prefix}{open_quote}{redact_url(value)}{close_quote}"


def _redact_cli_url_word(word: str) -> str:
    """Redact a complete URL argument without reformatting unchanged words."""
    try:
        value = shlex.split(word)[0]
    except (ValueError, IndexError):
        return redact_url(word)
    redacted = redact_url(value)
    return word if redacted == value else shlex.quote(redacted)


def _redact_urls_after_multi_value_flags(cmd: str) -> str:
    """Redact every URL in a multi-value flag's window, preserving spacing.

    Other flags end the window so non-URL values such as header emails and
    MLflow tags are preserved.
    """
    tokens = re.findall(rf"{_SHELL_WORD_PATTERN}|\s+|.", cmd)
    out: list[str] = []
    in_url_window = False
    for token in tokens:
        if token.isspace():
            out.append(token)
            continue
        flag, separator, value = token.partition("=")
        if flag in _MULTI_VALUE_URL_FLAGS:
            in_url_window = True
            if separator:
                token = f"{flag}={_redact_cli_url_word(value)}"
            out.append(token)
            continue
        # Any other flag closes the window. Conservative: treat any ``-`` or
        # ``--`` prefix as a new flag.
        if (
            token.startswith("-")
            and len(token) >= 2
            and (token.startswith("--") or token[1].isalpha())
        ):
            in_url_window = False
            out.append(token)
            continue
        if in_url_window:
            token = _redact_cli_url_word(token)
        out.append(token)
    return "".join(out)


def redact_cli_command(cmd: str) -> str:
    """Redact secrets from a CLI command string.

    Redacts:
    - ``--api-key`` values.
    - The opaque JSON value of ``--server-profiler-start-body``.
    - Credentialed header values (``--header Authorization: Bearer …`` etc.).
    - Userinfo embedded in URL-typed flag values (``--url``, ``-u``,
      ``--otel-url``, ``--mlflow-tracking-uri``).
    - Stray scheme-prefixed URLs with userinfo that slipped past the URL-flag
      matcher — e.g. 2nd+ URL under ``--url u1 u2 u3`` (``consume_multiple=True``).
      Restricted to ``scheme://`` URLs, so non-URL args like ``--model foo@bar``
      pass through unchanged.
    - Stray scheme-less bare ``user:pass@host`` tokens inside a ``--url``/``-u``
      consumption window. Scoped to that window so benign ``key:value@...``
      tokens on non-URL flags (``--header X-User-Email:alice@example.com``,
      ``--mlflow-tag owner:alice@acme.com``) pass through untouched.
    """
    for pattern in _CLI_SECRET_PATTERNS:
        cmd = pattern.sub(rf"\1'{REDACTED_VALUE}'", cmd)
    cmd = _redact_urls_after_multi_value_flags(cmd)
    cmd = _URL_FLAG_PATTERN.sub(_redact_url_flag_match, cmd)
    cmd = _STRAY_URL_USERINFO_PATTERN.sub(rf"\1{REDACTED_VALUE}@", cmd)
    return cmd


# Each entry must contain a `-` or `_` so it can't substring-match an innocent
# plural (e.g. bare `"token"` would match `--*-tokens-mean` flags carrying LLM
# token counts). Bare `--token` is intentionally not matched; add a specific
# compound form (e.g. `"my-token"`) if a new auth flag needs to be covered.
_CLI_COMMAND_SENSITIVE_TOKENS = (
    "api-key", "api_key",
    "api-token", "api_token",
    "auth-token", "auth_token",
    "access-token", "access_token",
    "bearer-token", "bearer_token",
    "id-token", "id_token",
    "refresh-token", "refresh_token",
    "authorization",
)  # fmt: skip


def _redact_cli_args(args: list) -> list:
    """Redact secret flags and opaque profiler JSON before command assembly."""
    out: list = []
    redact_next = False
    for arg in args:
        if redact_next:
            out.append(REDACTED_VALUE)
            redact_next = False
            continue
        if isinstance(arg, str) and arg.startswith("-"):
            name = arg.lstrip("-").lower()
            key, _, inline = name.partition("=")
            if key == "server-profiler-start-body" or any(
                tok in key for tok in _CLI_COMMAND_SENSITIVE_TOKENS
            ):
                if inline:
                    out.append(f"{arg.split('=', 1)[0]}={REDACTED_VALUE}")
                else:
                    out.append(arg)
                    redact_next = True
                continue
        out.append(arg)
    return out


def build_cli_command() -> str:
    """Synthesize the redacted CLI command string from `sys.argv`.

    Used as `default_factory` for `BenchmarkRun.cli_command` so that runs auto-
    capture the launching command (for reproducibility in
    `profile_export_aiperf.json`). `_redact_cli_args` handles --api-key-shaped
    flags token-wise; `redact_cli_command` then catches sensitive
    --header/-H values (Authorization, X-API-Key, etc.) at the assembled-string
    level so the canonical cli_command stored in JSON exports is never the
    source of a credential leak.
    """
    import sys

    from aiperf.config.loader.parsing import coerce_value

    args = [coerce_value(x) for x in sys.argv[1:]]
    redacted = _redact_cli_args(args)
    cmd = " ".join(
        ["aiperf"]
        + [
            f"'{x}'"
            if isinstance(x, str) and not x.startswith("-") and x != "profile"
            else str(x)
            for x in redacted
        ]
    )
    return redact_cli_command(cmd)


def is_sensitive_query_parameter_name(name: str) -> bool:
    """Return True when a raw query parameter name denotes a credential.

    A server percent-decodes the parameter name before dispatching, so
    ``api%5Fkey``, ``%61pi_key`` and ``api_key`` all name the same parameter.
    Matching the raw text alone therefore lets any encoded spelling smuggle a
    secret through unredacted, so the name is decoded before matching.
    """
    try:
        decoded_name = unquote_plus(name, errors="strict")
    except UnicodeDecodeError:
        # Undecodable octets cannot name a sensitive parameter on the
        # server either; fall back to the raw text rather than dropping it.
        decoded_name = name
    return (
        _SENSITIVE_URL_QUERY_PARAMETER_NAME_PATTERN.fullmatch(decoded_name) is not None
    )


def has_sensitive_query_parameters(url: str) -> bool:
    """Return True when the URL carries a credential-bearing query parameter.

    Uses the same name matching as :func:`redact_url`, so a URL for which this
    returns True is exactly one whose query ``redact_url`` rewrites.
    """
    return any(
        is_sensitive_query_parameter_name(match.group(2))
        for match in _URL_QUERY_PARAMETER_PATTERN.finditer(url)
    )


def _redact_sensitive_query_parameters(url: str) -> str:
    """Replace the value of every credential-carrying query parameter.

    Only the value span is rewritten; the separator and the parameter name are
    re-emitted byte-for-byte. Rebuilding the URL through ``urlsplit``/
    ``urlencode`` would additionally normalize escaping, parameter ordering and
    path bytes, changing URLs that carry no credentials at all.
    """

    def _redact_parameter(match: re.Match[str]) -> str:
        separator, name, value = match.group(1), match.group(2), match.group(3)
        # An already-redacted value is kept so redaction stays idempotent;
        # in free text the value span also covers trailing punctuation.
        if not is_sensitive_query_parameter_name(name) or value.startswith(
            REDACTED_VALUE
        ):
            return match.group(0)
        return f"{separator}{name}={REDACTED_VALUE}"

    return _URL_QUERY_PARAMETER_PATTERN.sub(_redact_parameter, url)


def redact_url(url: str) -> str:
    """Redact credentials in URL userinfo and sensitive query parameters.

    Handles URIs of any scheme (http, https, postgresql, mysql, sqlite, file,
    etc.) plus bare ``user:pass@host`` URLs. Returns the URL unchanged if no
    credentials are embedded.

    Matters for MLflow: ``--mlflow-tracking-uri`` commonly carries backends
    like ``postgresql://user:secret@db:5432/mlflow`` — limiting redaction to
    ``http(s)://`` would leak those credentials.
    """
    # Any scheme followed by ``://`` then userinfo up to ``@``. The userinfo
    # segment is bounded by /, ?, # so ``@`` inside a path or query string
    # (e.g. ``/users@example.com``, ``?email=a@b.com``) is never matched.
    result = re.sub(
        r"([A-Za-z][A-Za-z0-9+.\-]*://)([^@/?#]+)@",
        r"\1" + REDACTED_VALUE + "@",
        url,
    )
    if result == url and "://" not in url:
        # Bare userinfo: user:pass@host (no scheme prefix, must contain : before @)
        result = re.sub(r"^([^@:/?#]+:[^@/?#]+)@", REDACTED_VALUE + "@", result)
    return _redact_sensitive_query_parameters(result)


_WHITESPACE_RUN = re.compile(r"(\s+)")


def redact_text(text: str) -> str:
    """``redact_url`` for free text that may embed URLs.

    ``redact_url`` treats everything after a sensitive query value as part of that
    value, so applying it to a whole sentence would swallow the words after the
    URL. Redacting each whitespace-delimited token keeps the sentence readable.
    """
    return "".join(
        part if part.isspace() else redact_url(part)
        for part in _WHITESPACE_RUN.split(text)
    )


def _redact_endpoint_fields(endpoint: Any) -> None:
    """Redact endpoint and profiler credentials in both public and Python shapes."""
    if not isinstance(endpoint, dict):
        return
    for key in ("apiKey", "api_key"):
        if endpoint.get(key) is not None:
            endpoint[key] = REDACTED_VALUE

    headers = endpoint.get("headers")
    if isinstance(headers, dict):
        endpoint["headers"] = redact_headers(headers) or {}

    for key in ("urls", "url"):
        urls = endpoint.get(key)
        if isinstance(urls, str):
            endpoint[key] = redact_url(urls)
        elif isinstance(urls, list):
            endpoint[key] = [
                redact_url(url) if isinstance(url, str) else url for url in urls
            ]

    for key in ("serverProfiler", "server_profiler"):
        _redact_profiler_fields(endpoint.get(key))


def _redact_profiler_fields(profiler: Any) -> None:
    """Hide profiler URL credentials and opaque start bodies in public specs."""
    if not isinstance(profiler, dict):
        return
    _redact_endpoint_fields(profiler)
    for body_key in ("startBody", "start_body"):
        if profiler.get(body_key) is not None:
            profiler[body_key] = REDACTED_VALUE


def _redact_dataset_path(dataset: Any) -> None:
    """Redact one dataset's ``path``: a string, or a pinned ``{ref, resolved_version}``."""
    if not isinstance(dataset, dict):
        return
    path = dataset.get("path")
    if isinstance(path, str):
        dataset["path"] = redact_url(path)
    elif isinstance(path, dict) and isinstance(path.get("ref"), str):
        path["ref"] = redact_url(path["ref"])


def _redact_dataset_paths(benchmark: dict[str, Any]) -> None:
    """Redact every dataset path in a benchmark: ``datasets`` (list or map) and ``dataset``."""
    datasets = benchmark.get("datasets")
    if isinstance(datasets, dict):
        datasets = list(datasets.values())
    for dataset in datasets if isinstance(datasets, list) else []:
        _redact_dataset_path(dataset)
    _redact_dataset_path(benchmark.get("dataset"))


def redact_endpoint_spec(spec: dict[str, Any]) -> dict[str, Any]:
    """Return a credential-safe copy of a CR spec or benchmark configuration.

    Kubernetes CRs use the public ``apiKey`` spelling while Python model dumps
    may use ``api_key``. Both shapes cross persistence and API boundaries, so
    the canonical redactor intentionally handles both without normalizing the
    rest of the user-authored document. Dataset paths are redacted as well: a
    presigned dataset URL is a credential.
    """
    redacted = deepcopy(spec)
    benchmark = redacted.get("benchmark", redacted)
    if not isinstance(benchmark, dict):
        return redacted
    _redact_endpoint_fields(benchmark.get("endpoint"))
    _redact_dataset_paths(benchmark)
    return redacted
