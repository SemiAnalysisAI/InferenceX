# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

import asyncio
import contextlib
import os
import uuid
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from aiperf.common.enums import LifecycleState
from aiperf.common.environment import Environment
from aiperf.common.exceptions import (
    InvalidStateError,
    LifecycleOperationError,
)
from aiperf.common.hooks import (
    AIPerfHook,
    BackgroundTaskParams,
    on_init,
    on_start,
    on_stop,
    provides_hooks,
)
from aiperf.common.mixins.hooks_mixin import HooksMixin
from aiperf.common.mixins.task_manager_mixin import TaskManagerMixin
from aiperf.common.models import ErrorDetails, ExitErrorInfo
from aiperf.common.protocols import AIPerfLifecycleProtocol


@provides_hooks(
    AIPerfHook.ON_INIT,
    AIPerfHook.ON_START,
    AIPerfHook.ON_STOP,
    AIPerfHook.ON_STATE_CHANGE,
    AIPerfHook.BACKGROUND_TASK,
)
class AIPerfLifecycleMixin(TaskManagerMixin, HooksMixin):
    """This mixin provides a lifecycle state machine, and is the basis for most components in the AIPerf framework.
    It provides a set of hooks that are run at each state transition, and the ability to define background tasks
    that are automatically ran on @on_start, and canceled via @on_stop.

    It exposes to the outside world `initialize`, `start`, and `stop` methods, as well as getting the
    current state of the lifecycle. These simple methods promote a simple interface for users to interact with.
    """

    def __init__(self, id: str | None = None, **kwargs) -> None:
        """
        Args:
            id: The id of the lifecycle. If not provided, a random uuid will be generated.
        """
        self.id = id or f"{self.__class__.__name__}_{uuid.uuid4().hex[:8]}"
        self._state = LifecycleState.CREATED
        self.initialized_event = asyncio.Event()
        self.started_event = asyncio.Event()
        self._stop_requested_event = asyncio.Event()
        self.stopped_event = asyncio.Event()  # set on stop or failure
        self._children: list[AIPerfLifecycleProtocol] = []
        self._exit_errors: list[ExitErrorInfo] = []
        if "logger_name" not in kwargs:
            kwargs["logger_name"] = self.id
        super().__init__(**kwargs)

    @property
    def state(self) -> LifecycleState:
        return self._state

    # NOTE: This was moved to not be a property setter, as we want it to be async so we can
    # run the hooks and await them. Otherwise there is issues with creating a task when the
    # lifecycle is trying to stop.
    async def _set_state(self, state: LifecycleState) -> None:
        if state == self._state:
            return
        old_state = self._state
        self._state = state
        if self.is_trace_enabled:
            self.trace(f"State changed from {old_state!r} to {state!r} for {self}")
        await self.run_hooks(
            AIPerfHook.ON_STATE_CHANGE, old_state=old_state, new_state=state
        )

    @property
    def was_initialized(self) -> bool:
        return self.initialized_event.is_set()

    @property
    def was_started(self) -> bool:
        return self.started_event.is_set()

    @property
    def was_stopped(self) -> bool:
        return self.stopped_event.is_set()

    @property
    def is_running(self) -> bool:
        """Whether the lifecycle's current state is LifecycleState.RUNNING."""
        return self.state == LifecycleState.RUNNING

    @property
    def failure_shutdown_timeout(self) -> float | None:
        """Wall-clock cap applied to ``self.stop()`` when ``_fail`` tears down
        after a failed on_init/on_start transition. Defaults to
        ``Environment.SERVICE.FAILURE_SHUTDOWN_TIMEOUT``.

        Subclasses whose ``on_stop`` hooks legitimately need longer than the
        global default (e.g. a terminal hook that exports results and calls
        ``os._exit()`` itself, which the bound would otherwise cut off mid-export)
        should override this to return a larger value, or ``None`` to disable
        the bound entirely and rely on the subclass's own exit path.
        """
        return Environment.SERVICE.FAILURE_SHUTDOWN_TIMEOUT

    @property
    def stop_requested(self) -> bool:
        """Whether the lifecycle has been requested to stop."""
        return self._stop_requested_event.is_set()

    @stop_requested.setter
    def stop_requested(self, value: bool) -> None:
        if value:
            self._stop_requested_event.set()
        else:
            self._stop_requested_event.clear()

    async def _execute_state_transition(
        self,
        transient_state: LifecycleState,
        final_state: LifecycleState,
        hook_type: AIPerfHook,
        event: asyncio.Event,
        *,
        reverse: bool = False,
    ) -> None:
        """This method wraps the functionality of changing the state of the lifecycle, and running the hooks.
        It is used to ensure that the state change and hook running are atomic, and that the state change is
        only made after the hooks have completed. It also takes in an event that is set when the state change is complete.
        This is useful for external code waiting for the state change to complete before continuing.

        If reverse is True, the hooks are run in reverse order. This is useful for stopping the lifecycle in the reverse order of starting it.
        """
        await self._set_state(transient_state)
        self.debug(lambda: f"{transient_state.title()} {self}")
        # Startup transitions must fail-fast: continuing to run later hooks
        # after an earlier one aborted produces a half-started service (e.g.
        # background tasks spawned after a PUB/SUB probe already failed) that
        # survives as a silent zombie container. Stop transitions stay
        # best-effort so cleanup errors don't mask each other.
        fail_fast = transient_state in (
            LifecycleState.INITIALIZING,
            LifecycleState.STARTING,
        )
        try:
            await self.run_hooks(hook_type, reverse=reverse, fail_fast=fail_fast)
            await self._set_state(final_state)
            self.debug(lambda: f"{self} is now {final_state.title()}")
            event.set()
        except asyncio.CancelledError as e:
            # A *child* lifecycle reports its own start-up failure by raising
            # CancelledError from _fail() -- a BaseException, so it slips past
            # the `except Exception` below and this parent never reaches
            # _fail(), never becoming FAILED. Nothing upstream can then tell a
            # failed start from a clean stop: bootstrap's
            # _exit_if_service_failed sees a healthy service and the process
            # exits 0, so a worker whose request signer could not resolve
            # credentials surfaces as "No workers registered with the credit
            # router" instead of the real cause.
            #
            # Genuine cancellation must still propagate untouched, or a
            # cooperative shutdown turns into a spurious failure.
            task = asyncio.current_task()
            if task is not None and task.cancelling():
                raise
            # Prefer the child's underlying error: _fail() raises
            # `CancelledError(...) from e`, so __cause__ carries the diagnosis
            # a user can act on.
            cause = e.__cause__
            await self._fail(
                cause
                if isinstance(cause, Exception)
                else RuntimeError(str(e) or repr(e))
            )
        except Exception as e:
            await self._fail(e)

    async def initialize(self) -> None:
        """Initialize the lifecycle and run the @on_init hooks.

        NOTE: It is generally discouraged from overriding this method.
        Instead, use the @on_init hook to handle your own initialization logic.
        """
        if self.state in (
            LifecycleState.INITIALIZING,
            LifecycleState.INITIALIZED,
            LifecycleState.STARTING,
            LifecycleState.RUNNING,
        ):
            self.debug(
                lambda: f"Ignoring initialize request for {self} in state {self.state}"
            )
            return

        if self.state != LifecycleState.CREATED:
            raise InvalidStateError(
                f"Cannot initialize from state {self.state} for {self}"
            )

        await self._execute_state_transition(
            LifecycleState.INITIALIZING,
            LifecycleState.INITIALIZED,
            AIPerfHook.ON_INIT,
            self.initialized_event,
        )

    async def start(self) -> None:
        """Start the lifecycle and run the @on_start hooks.

        NOTE: It is generally discouraged from overriding this method.
        Instead, use the @on_start hook to handle your own starting logic.
        """
        if self.state in (
            LifecycleState.STARTING,
            LifecycleState.RUNNING,
        ):
            self.debug(
                lambda: f"Ignoring start request for {self} in state {self.state}"
            )
            return

        if self.state != LifecycleState.INITIALIZED:
            raise InvalidStateError(f"Cannot start from state {self.state} for {self}")

        await self._execute_state_transition(
            LifecycleState.STARTING,
            LifecycleState.RUNNING,
            AIPerfHook.ON_START,
            self.started_event,
        )

    @asynccontextmanager
    async def try_operation_or_stop(self, operation: str) -> AsyncIterator[None]:
        """Context manager to try an operation or stop the lifecycle on failure.

        This context manager catches any exception, logs it, and raises a LifecycleOperationError
        which will be caught by the lifecycle system and trigger a graceful shutdown via _fail().

        Args:
            operation: Description of the operation being performed

        Raises:
            LifecycleOperationError: When the operation fails, triggering graceful shutdown
        """
        try:
            yield
        except LifecycleOperationError as e:
            # Log error and re-raise without wrapping to avoid duplicate error info
            self.error(f"Failed to {operation.lower()}: {e}")
            self._exit_errors.append(
                ExitErrorInfo(
                    error_details=ErrorDetails.from_exception(e),
                    operation=operation,
                    service_id=self.id,
                )
            )
            raise
        except Exception as e:
            self.error(f"Failed to {operation.lower()}: {e}")
            error = LifecycleOperationError(
                operation=operation,
                original_exception=e,
                lifecycle_id=self.id,
            )
            self._exit_errors.append(
                ExitErrorInfo.from_lifecycle_operation_error(error)
            )
            raise error from e

    async def initialize_and_start(self) -> None:
        """Initialize and start the lifecycle. This is a convenience method that calls `initialize` and `start` in sequence."""
        async with self.try_operation_or_stop("Initialize"):
            await self.initialize()
        async with self.try_operation_or_stop("Start"):
            await self.start()

    async def stop(self) -> None:
        """Stop the lifecycle and run the @on_stop hooks.

        NOTE: It is generally discouraged from overriding this method.
        Instead, use the @on_stop hook to handle your own stopping logic.
        """
        if self.stop_requested:
            self.debug(
                lambda: f"Ignoring stop request for {self} in state {self.state}"
            )
            return

        self.stop_requested = True
        await self._execute_state_transition(
            LifecycleState.STOPPING,
            LifecycleState.STOPPED,
            AIPerfHook.ON_STOP,
            self.stopped_event,
            reverse=True,  # run the stop hooks in reverse order
        )

    @on_start
    async def _start_background_tasks(self) -> None:
        """Start all tasks that are decorated with the @background_task decorator."""
        for hook in self.get_hooks(AIPerfHook.BACKGROUND_TASK):
            if not isinstance(hook.params, BackgroundTaskParams):
                raise AttributeError(
                    f"Invalid hook parameters for {hook}: {hook.params}. Expected BackgroundTaskParams."
                )
            self.start_background_task(
                hook.func,
                interval=hook.params.interval,
                immediate=hook.params.immediate,
                stop_on_error=hook.params.stop_on_error,
                stop_event=self._stop_requested_event,
            )

    @on_stop
    async def _stop_all_tasks(self) -> None:
        """Stop all tasks that are decorated with the @background_task decorator,
        and any custom ones that were ran using `self.execute_async()`.
        """
        await self.cancel_all_tasks()

    @property
    def _hard_exit_on_wedged_shutdown(self) -> bool:
        """Whether a wedged failure-shutdown should force-exit the process.

        Only containerized (operator-managed) services get the hard kill. A
        service whose ``on_stop`` never returns keeps its Pod alive as a silent
        zombie, so losing cleanup state beats never exiting. A local
        ``aiperf profile`` run is the opposite trade: ``_fail`` is reached by
        every ``AIPerfLifecycleMixin`` in the CLI's own process, so
        ``os._exit`` there would discard the traceback, the artifact export,
        and every buffered writer in the process. Locally the failure is left
        to surface through the normal ``CancelledError`` path below.

        ``self.run`` only exists on ``BaseService`` subclasses, so the run-type
        lookup is defensive and falls back to the ``AIPERF_OPERATOR_MANAGED``
        marker the operator sets on every JobSet container.
        """
        runtime = getattr(getattr(self, "run", None), "cfg", None)
        run_type = getattr(getattr(runtime, "runtime", None), "service_run_type", None)
        if run_type is not None:
            # Compared as a string rather than importing ServiceRunType: the
            # plugin enums are generated at registry-load time and importing
            # them from this core mixin would invert the dependency order.
            return str(run_type).lower() == "kubernetes"
        return os.environ.get("AIPERF_OPERATOR_MANAGED") == "1"

    @staticmethod
    def _describe_in_flight_stop(task: asyncio.Task) -> str:
        """Describe where a wedged ``stop()`` task was suspended.

        Walks the task's coroutine await chain (outermost to innermost) so
        the reported description names the actual on_stop hook that was
        still running when the failure_shutdown_timeout bound was hit,
        rather than only the generic ``stop()``/``run_hooks()`` frames that
        wrap it.
        """
        frames: list[str] = []
        coro = task.get_coro()
        while coro is not None:
            frame = getattr(coro, "cr_frame", None)
            if frame is not None:
                code = frame.f_code
                name = getattr(code, "co_qualname", code.co_name)
                frames.append(f"{name}:{frame.f_lineno}")
            coro = getattr(coro, "cr_await", None)
        return " -> ".join(frames) if frames else "an unknown step"

    async def _fail(self, e: Exception) -> None:
        """Set the state to FAILED and raise an asyncio.CancelledError.
        This is used when the transition from one state to another fails.
        """
        self.error(f"Failed for {self}: {e}")
        if not isinstance(e, LifecycleOperationError):
            # Only add to exit errors if the exception has not already been added
            self._exit_errors.append(
                ExitErrorInfo(
                    error_details=ErrorDetails.from_exception(e),
                    operation=self.state.title(),
                    service_id=self.id,
                )
            )
        if self.state != LifecycleState.STOPPING:
            self.debug(f"Stopping {self} due to failure")
            # Bound the shutdown: a blocked on_stop hook (a cancelled ZMQ
            # client stuck in a C-extension recv) otherwise turns a failed
            # service into a silent zombie that keeps its container alive.
            # We are already on the failure path, so losing cleanup state
            # beats never exiting. Subclasses whose teardown legitimately runs
            # long widen this bound via ``failure_shutdown_timeout``; None
            # removes it entirely and is only correct for a lifecycle that
            # cannot wedge. In containers, a wedged teardown hard-exits via
            # ``_hard_exit_on_wedged_shutdown``.
            timeout = self.failure_shutdown_timeout
            if timeout is None:
                await self.stop()
            else:
                stop_task = asyncio.ensure_future(self.stop())
                done, pending = await asyncio.wait({stop_task}, timeout=timeout)
                if stop_task in pending:
                    # Report exactly which stop hook was suspended before
                    # cutting it off: a bare "timed out" message gives an
                    # operator nothing to act on when the truncated step was,
                    # e.g., a buffered writer flush or an in-flight export.
                    in_flight = self._describe_in_flight_stop(stop_task)
                    stop_task.cancel()
                    with contextlib.suppress(asyncio.CancelledError):
                        await stop_task
                    if self._hard_exit_on_wedged_shutdown:
                        self.error(
                            f"Shutdown after failure did not complete in {timeout}s "
                            f"(stuck in: {in_flight}); force-exiting"
                        )
                        os._exit(1)
                    else:
                        self.error(
                            f"Shutdown after failure did not complete in {timeout}s "
                            f"(stuck in: {in_flight}); continuing teardown and "
                            f"reporting the failure"
                        )
                else:
                    # Propagate any exception raised by stop() itself, matching
                    # the exception-propagation behavior of a plain await.
                    stop_task.result()
        await self._set_state(LifecycleState.FAILED)
        raise asyncio.CancelledError(f"Failed for {self}: {e}") from e

    def attach_child_lifecycle(self, child: AIPerfLifecycleProtocol) -> None:
        """Attach a child lifecycle to manage. This child will now have its lifecycle managed and
        controlled by this lifecycle. Common use cases are having a Service be a parent lifecycle,
        and having supporting components such as streaming post processors, progress reporters, etc. be children.

        Children will be called in the order they were attached for initialize and start,
        and in reverse order for stop.
        """
        if self.state != LifecycleState.CREATED:
            raise InvalidStateError(
                f"Cannot attach child {child} to {self} in state {self.state}. "
                "Please attach children before initializing or starting the lifecycle."
            )
        self._children.append(child)

    @on_init
    async def _initialize_children(self) -> None:
        """Initialize all children. This is done via the @on_init hook to ensure that the children
        initialize along with the parent hooks, and not after the parent hooks, which would cause
        a race condition.
        """
        for child in self._children:
            await child.initialize()

    @on_start
    async def _start_children(self) -> None:
        """Start all children. This is done via the @on_start hook to ensure that the children
        start along with the parent hooks, and not after the parent hooks, which would cause
        a race condition.
        """
        for child in self._children:
            await child.start()

    @on_stop
    async def _stop_children(self) -> None:
        """Stop all children. This is done via the @on_stop hook to ensure that the children
        are stopped along with the parent hooks, and not after the parent hooks, which would cause
        a race condition.
        """
        for child in reversed(self._children):
            await child.stop()

    def __str__(self) -> str:
        return f"{self.__class__.__name__} (id={self.id})"

    def __repr__(self) -> str:
        return f"<{self.__class__.__qualname__} {self.id} (state={self.state})>"
