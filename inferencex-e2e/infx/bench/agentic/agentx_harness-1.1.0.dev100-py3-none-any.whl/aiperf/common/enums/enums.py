# SPDX-FileCopyrightText: Copyright (c) 2025-2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0

from typing import Any, Self

from aiperf.common.enums.base_enums import CaseInsensitiveStrEnum


class AIPerfLogLevel(CaseInsensitiveStrEnum):
    """Logging levels for AIPerf output verbosity."""

    TRACE = "TRACE"
    """Most verbose. Logs all operations including ZMQ messages and internal state changes."""

    DEBUG = "DEBUG"
    """Detailed debugging information. Logs function calls and important state transitions."""

    INFO = "INFO"
    """General informational messages. Default level showing benchmark progress and results."""

    NOTICE = "NOTICE"
    """Important informational messages that are more significant than INFO but not warnings."""

    WARNING = "WARNING"
    """Warning messages for potentially problematic situations that don't prevent execution."""

    SUCCESS = "SUCCESS"
    """Success messages for completed operations and milestones."""

    ERROR = "ERROR"
    """Error messages for failures that prevent specific operations but allow continued execution."""

    CRITICAL = "CRITICAL"
    """Critical errors that may cause the benchmark to fail or produce invalid results."""


class AudioFormat(CaseInsensitiveStrEnum):
    """Audio file formats for synthetic audio generation."""

    WAV = "wav"
    """WAV format. Uncompressed audio, larger file sizes, best quality."""

    MP3 = "mp3"
    """MP3 format. Compressed audio, smaller file sizes, good quality."""


class CommAddress(CaseInsensitiveStrEnum):
    """Enum for specifying the address type for communication clients.
    This is used to lookup the address in the communication config."""

    EVENT_BUS_PROXY_FRONTEND = "event_bus_proxy_frontend"
    """Frontend address for services to publish messages to."""

    EVENT_BUS_PROXY_BACKEND = "event_bus_proxy_backend"
    """Backend address for services to subscribe to messages."""

    CREDIT_ROUTER = "credit_router"
    """Address for bidirectional ROUTER-DEALER credit routing (all timing modes)."""

    RECORDS = "records"
    """Address to send parsed records from InferenceParser to RecordManager."""

    DATASET_MANAGER_PROXY_FRONTEND = "dataset_manager_proxy_frontend"
    """Frontend address for sending requests to the DatasetManager."""

    DATASET_MANAGER_PROXY_BACKEND = "dataset_manager_proxy_backend"
    """Backend address for the DatasetManager to receive requests from clients."""

    RAW_INFERENCE_PROXY_FRONTEND = "raw_inference_proxy_frontend"
    """Frontend address for sending raw inference messages to the InferenceParser from Workers."""

    RAW_INFERENCE_PROXY_BACKEND = "raw_inference_proxy_backend"
    """Backend address for the InferenceParser to receive raw inference messages from Workers."""

    # Referenced by aiperf.config.comm.*.
    CREDIT_RETURN_ROUTER = "credit_return_router"
    """Address for credit-return ROUTER-DEALER traffic (separate from CREDIT_ROUTER for high-throughput modes)."""

    CREDIT_RETURN = "credit_return"
    """Address for the credit-return PUSH/PULL fan-in channel (worker PUSH -> timing-manager PULL).
    CreditReturn/FirstToken ride this dedicated channel so the dispatch CREDIT_ROUTER stays
    send-only; returns are unaddressed fan-in (worker_id travels in CreditReturn)."""

    CONTROL = "control"
    """Control-plane address for service-manager commands."""

    GROUP_LIFECYCLE = "group_lifecycle"
    """Address for worker-group lifecycle signaling."""


class CommandType(CaseInsensitiveStrEnum):
    FINALIZE_ARTIFACTS = "finalize_artifacts"
    """Flush and durably publish artifacts before service communication stops."""
    GET_POD_STATES = "get_pod_states"
    """Return the SystemController's authoritative worker-pod state snapshot."""
    REALTIME_METRICS = "realtime_metrics"
    PROFILE_CANCEL = "profile_cancel"
    PROFILE_COMPLETE = "profile_complete"
    PROFILE_CONFIGURE = "profile_configure"
    PROFILE_START = "profile_start"
    SHUTDOWN = "shutdown"
    SPAWN_WORKERS = "spawn_workers"
    START_REALTIME_TELEMETRY = "start_realtime_telemetry"
    ABORT = "abort"
    """Signal sibling pod peers (workers/record-processors) to exit the process
    with a non-zero status so kubelet restarts them. Used by WorkerGroupManager
    when its own lifecycle failed -- a clean SHUTDOWN would let siblings exit 0
    and leave the pod permanently half-dead at 1/13 Ready."""


class ProfileCancelReason(CaseInsensitiveStrEnum):
    """Why a PROFILE_CANCEL command was issued; controls run exit semantics."""

    USER = "user"
    WARMUP_FAILURE = "warmup_failure"
    FAILED_REQUEST_THRESHOLD = "failed_request_threshold"
    PROGRESS_STALL = "progress_stall"

    @property
    def is_abort(self) -> bool:
        """Return whether the cancellation represents a benchmark failure."""
        return self is not ProfileCancelReason.USER


class ConversationBranchMode(CaseInsensitiveStrEnum):
    """Mode discriminator for ``ConversationBranchInfo``.

    Distinguishes two kinds of DAG branches sharing one primitive:

    - ``FORK``: child inherits the parent's accumulated message context and
      sticky-routes to the parent's worker (prefix-cache locality). Used by
      aiperf's native DAG conversation-forking semantics.
    - ``SPAWN``: child starts with a fresh context; its first turn co-locates
      on the parent's worker when that sticky entry is live (least-loaded
      otherwise), then it pins to that worker under its own id (no parent
      refcount bump). Used for sub-agent dispatch and upcoming graph-mode
      fan-out.
    """

    FORK = "fork"
    """Child inherits parent's turn_list (accumulated message history + captured
    live responses); sticky-routes to parent's worker for prefix-cache locality."""

    SPAWN = "spawn"
    """Child gets a fresh context; starts on the parent's worker when that
    sticky entry is live, then pins under its own id (no parent refcount bump).

    Disambiguation note: this SPAWN is the DAG-branch mode (a child
    *conversation* that runs alongside its parent). It is unrelated to
    ``CommandType.SPAWN_WORKERS`` (the controller->worker-manager command
    that spawns *worker processes*). One is dataset/orchestration semantics;
    the other is process lifecycle.
    """


class PrerequisiteKind(CaseInsensitiveStrEnum):
    """Types of conditions that can gate a turn's dispatch.

    Extensible: v1 orchestrator only honors SPAWN_JOIN; the remaining values
    are reserved and rejected at load time by
    ``validate_for_orchestrator_v1``. Each deferred value is pinned to a
    future orchestrator capability in the DAG prereq-gating design doc.
    """

    SPAWN_JOIN = "spawn_join"
    """All blocking children from a named branch have completed."""

    CHILD_SESSION_COMPLETE = "child_session_complete"
    """A specific child runtime session has completed (reserved)."""

    TIMER = "timer"
    """Wall-clock delay has elapsed (reserved)."""

    EXTERNAL_EVENT = "external_event"
    """Named external signal has been received (reserved)."""

    BARRIER = "barrier"
    """Runtime-diamond join on a shared barrier_id (reserved)."""


class ConversationContextMode(CaseInsensitiveStrEnum):
    """Controls how prior turns are accumulated in multi-turn conversations.

    Two dimensions determine behavior:

    - **Turn format**: ``DELTAS`` (incremental per-turn content) vs
      ``MESSAGE_ARRAY`` (each turn carries its complete message list).
    - **Response inclusion**: ``WITH_RESPONSES`` (pre-canned assistant turns
      are present in the dataset) vs ``WITHOUT_RESPONSES`` (only user content;
      live inference responses are captured at runtime).
    """

    DELTAS_WITHOUT_RESPONSES = "deltas_without_responses"
    """Standard multi-turn chat. Each dataset turn is a user-only delta.
    AIPerf accumulates turns and threads live inference responses into the history."""

    DELTAS_WITH_RESPONSES = "deltas_with_responses"
    """Delta-compressed prompts. Each dataset turn is a delta that may include
    pre-canned assistant responses. AIPerf accumulates but discards live responses."""

    MESSAGE_ARRAY_WITH_RESPONSES = "message_array_with_responses"
    """Self-contained prompts. Each turn carries a complete message array (including
    assistant responses) and is sent as-is. Default for Mooncake traces with
    pre-built ``messages`` arrays."""

    MESSAGE_ARRAY_WITHOUT_RESPONSES = "message_array_without_responses"
    """Reserved. Each turn would carry a complete user-only message array, requiring
    live response merging between turns. Not yet implemented."""


class TurnInputKind(CaseInsensitiveStrEnum):
    """What produced a turn's new input content, for trace replays that record it.

    Classified by trace loaders from the recorded per-request content-block
    types (``input_types``) and assistant stop reasons (``stop``). Lets
    downstream consumers distinguish machine-paced agentic-loop continuations
    from human-paced input turns.
    """

    USER_INPUT = "user_input"
    """Genuine user/agent text (or multimodal) input arriving at a yield point
    (the previous assistant turn ended without calling a tool)."""

    TOOL_RESULT = "tool_result"
    """Tool output fed back after the assistant stopped with ``tool_use`` --
    an immediate machine-paced continuation, not human input."""


class SubagentType(CaseInsensitiveStrEnum):
    """Optional sub-agent classification carried on DAG Conversation nodes.

    Used for DAG-benchmark bucket metrics and future routing policies. Unused
    by core aiperf today; present so externally-authored manifests can
    round-trip through aiperf models without validation errors.
    """

    EXPLORE = "explore"
    """Exploratory agent branch (e.g. breadth-first search child)."""

    GENERAL = "general"
    """General-purpose agent branch (default when unspecified)."""

    PLAN = "plan"
    """Planning/decomposition agent branch."""


class CacheBustTarget(CaseInsensitiveStrEnum):
    """Where (and how) to inject a per-conversation cache-bust marker.

    Prefix variants diverge at token 0 of the prompt (most aggressive -- defeats
    KV-cache prefix matching for the entire prompt). Suffix variants append
    after existing content (preserves leading-prefix caching).
    """

    NONE = "none"
    SYSTEM_PREFIX = "system_prefix"
    SYSTEM_SUFFIX = "system_suffix"
    FIRST_TURN_PREFIX = "first_turn_prefix"
    FIRST_TURN_SUFFIX = "first_turn_suffix"
    WARMUP_ISOLATION_SYSTEM = "warmup_isolation_system"
    WARMUP_ISOLATION_FIRST_TURN = "warmup_isolation_first_turn"


class PromptCorpus(CaseInsensitiveStrEnum):
    """Corpus used for synthetic prompt text generation."""

    SONNET = "sonnet"
    """Shakespeare sonnets (default). Classic prose for filler text."""

    CODING = "coding"
    """Realistic coding content: code, bash output, JSON, error tracebacks, git diffs."""

    RANDOM = "random"
    """Random tokens drawn from the full tokenizer vocabulary minus special tokens.
    Matches vLLM bench's RandomDataset token-generation strategy."""


class MemoryMapFormat(CaseInsensitiveStrEnum):
    """Storage format for memory-mapped dataset files."""

    CONVERSATION = "conversation"
    """Each entry is a JSON-serialized Conversation object."""

    PAYLOAD_BYTES = "payload_bytes"
    """Each entry is pre-encoded payload bytes for verbatim API replay."""


class ConnectionReuseStrategy(CaseInsensitiveStrEnum):
    """Transport connection reuse strategy. Controls how and when connections are reused across requests."""

    POOLED = "pooled"
    """Connections are pooled and reused across all requests"""

    NEVER = "never"
    """New connection for each request, closed after response"""

    STICKY_USER_SESSIONS = "sticky-user-sessions"
    """Connection persists across turns of a multi-turn conversation, closed on final turn (enables sticky load balancing)"""


class CreditPhase(CaseInsensitiveStrEnum):
    """The type of credit phase. This is used to identify which phase of the
    benchmark the credit is being used in, for tracking and reporting purposes."""

    WARMUP = "warmup"
    """The credit phase while the warmup is active. This is used to warm up the model and
    ensure that the model is ready to be profiled."""

    PROFILING = "profiling"
    """The credit phase while profiling is active. This is the primary phase of the
    benchmark, and what is used to calculate the final results."""


class ExportLevel(CaseInsensitiveStrEnum):
    """Export level for benchmark data."""

    SUMMARY = "summary"
    """Export only aggregated/summarized metrics (most compact)"""

    RECORDS = "records"
    """Export per-record metrics after aggregation with display unit conversion (CLI default)"""

    RAW = "raw"
    """Export raw parsed records with full request/response data (most detailed)"""


class ConvergenceMode(CaseInsensitiveStrEnum):
    """Statistical method for convergence detection in adaptive multi-run mode."""

    CI_WIDTH = "ci_width"
    """Stop when Student's t confidence interval width relative to mean is below threshold."""

    CV = "cv"
    """Stop when coefficient of variation (std/mean) is below threshold."""

    DISTRIBUTION = "distribution"
    """Stop when KS test p-value indicates latest run matches prior runs."""


class ConvergenceStat(CaseInsensitiveStrEnum):
    """Statistic to evaluate for convergence when using ci_width or cv mode."""

    AVG = "avg"
    P50 = "p50"
    P90 = "p90"
    P95 = "p95"
    P99 = "p99"
    MIN = "min"
    MAX = "max"


class GPUTelemetryMode(CaseInsensitiveStrEnum):
    """GPU telemetry display mode."""

    SUMMARY = "summary"
    REALTIME_DASHBOARD = "realtime_dashboard"


class ImageFormat(CaseInsensitiveStrEnum):
    """Image file formats for synthetic image generation."""

    PNG = "png"
    """PNG format. Lossless compression, larger file sizes, best quality."""

    JPEG = "jpeg"
    """JPEG format. Lossy compression, smaller file sizes, good for photos."""

    RANDOM = "random"
    """Randomly select PNG or JPEG for each image."""


class ImageSource(CaseInsensitiveStrEnum):
    """Source image generation mode for multimodal benchmarking."""

    ASSETS = "assets"
    """Load source images from the bundled assets/source_images directory."""

    NOISE = "noise"
    """Generate random noise images on the fly. Produces diverse, unique images
    without requiring files on disk."""


class ImageSourceSamplingStrategy(CaseInsensitiveStrEnum):
    """How source images are selected from a finite source-image pool."""

    RANDOM_WITH_REPLACEMENT = "random-with-replacement"
    """Draw each source image independently; repeats may occur immediately."""

    SHUFFLE_CYCLE = "shuffle-cycle"
    """Draw every source image once per shuffled cycle; reshuffle after exhaustion."""

    SEQUENTIAL_CYCLE = "sequential-cycle"
    """Walk source images in sorted load order; wrap after exhaustion."""


class IPVersion(CaseInsensitiveStrEnum):
    """IP version for HTTP socket connections."""

    V4 = "4"
    """Use IPv4 only (AF_INET). Default for most environments."""

    V6 = "6"
    """Use IPv6 only (AF_INET6). Use when connecting to IPv6-only servers."""

    AUTO = "auto"
    """Let the system choose (AF_UNSPEC). Supports both IPv4 and IPv6."""


class LifecycleState(CaseInsensitiveStrEnum):
    """This is the various states a service can be in during its lifecycle."""

    CREATED = "created"
    INITIALIZING = "initializing"
    INITIALIZED = "initialized"
    STARTING = "starting"
    RUNNING = "running"
    STOPPING = "stopping"
    STOPPED = "stopped"
    FAILED = "failed"


class MediaType(CaseInsensitiveStrEnum):
    """The various types of media (e.g. text, image, audio, video)."""

    TEXT = "text"
    IMAGE = "image"
    AUDIO = "audio"
    VIDEO = "video"


class MessageType(CaseInsensitiveStrEnum):
    """The various types of messages that can be sent between services.

    The message type is used to determine what Pydantic model the message maps to,
    based on the message_type field in the message model. For detailed explanations
    of each message type, go to its definition in :mod:`aiperf.common.messages`.
    """

    ALL_RECORDS_RECEIVED = "all_records_received"
    CONNECTION_PROBE = "connection_probe"
    CONVERSATION_REQUEST = "conversation_request"
    CONVERSATION_RESPONSE = "conversation_response"
    BENCHMARK_COMPLETE = "benchmark_complete"
    CONVERSATION_TURN_REQUEST = "conversation_turn_request"
    CONVERSATION_TURN_RESPONSE = "conversation_turn_response"
    CREDIT_PHASE_COMPLETE = "credit_phase_complete"
    CREDIT_PHASE_PROGRESS = "credit_phase_progress"
    CREDIT_PHASE_SENDING_COMPLETE = "credit_phase_sending_complete"
    CREDIT_PHASE_START = "credit_phase_start"
    CREDIT_PHASES_CONFIGURED = "credit_phases_configured"
    CREDITS_COMPLETE = "credits_complete"
    DATASET_CONFIG_STATUS_REQUEST = "dataset_config_status_request"
    DATASET_CONFIG_STATUS_RESPONSE = "dataset_config_status_response"
    DATASET_CONFIGURED_NOTIFICATION = "dataset_configured_notification"
    DATASET_DOWNLOADED_NOTIFICATION = "dataset_downloaded_notification"
    DATASET_CONFIGURATION_FAILED = "dataset_configuration_failed"
    ERROR = "error"
    HEARTBEAT = "heartbeat"
    INFERENCE_RESULTS = "inference_results"
    RECORDS = "records"
    PHASE_BASELINE_REQUEST = "phase_baseline_request"
    PROCESSING_STATS = "processing_stats"
    PROCESS_RECORDS_RESULT = "process_records_result"
    PROCESS_TELEMETRY_RESULT = "process_telemetry_result"
    PROCESS_SERVER_METRICS_RESULT = "process_server_metrics_result"
    PROCESS_ACCURACY_RESULT = "process_accuracy_result"
    PROCESS_ALL_RESULTS = "process_all_results"
    PROFILE_RESULTS = "profile_results"
    REALTIME_METRICS = "realtime_metrics"
    REALTIME_SERVER_METRICS = "realtime_server_metrics"
    REALTIME_TELEMETRY_METRICS = "realtime_telemetry_metrics"
    RESULTS_EXPORTED = "results_exported"
    SERVICE_ERROR = "service_error"
    SYSTEM_STATE_CHANGED = "system_state_changed"
    TELEMETRY_RECORDS = "telemetry_records"
    TELEMETRY_STATUS = "telemetry_status"
    SERVER_METRICS_STATUS = "server_metrics_status"
    SERVER_METRICS_WARMUP_BOUNDARY_READY = "server_metrics_warmup_boundary_ready"
    NETWORK_LATENCY_RECORD = "network_latency_record"
    WORKER_GROUP_STATS = "worker_group_stats"
    WORKER_HEALTH = "worker_health"
    WORKER_POD_STATE = "worker_pod_state"
    WORKER_STARTUP_STATE = "worker_startup_state"
    WORKER_STATUS_SUMMARY = "worker_status_summary"


class ModelSelectionStrategy(CaseInsensitiveStrEnum):
    """Strategy for selecting the model to use for the request."""

    ROUND_ROBIN = "round_robin"
    """Cycle through models in order. The nth prompt is assigned to model at index (n mod number_of_models)."""

    RANDOM = "random"
    """Randomly select a model for each prompt using uniform distribution."""

    WEIGHTED = "weighted"
    """Select a model with probability proportional to a per-model weight."""


class PrometheusMetricType(CaseInsensitiveStrEnum):
    """Prometheus metric types as defined in the Prometheus exposition format.

    See: https://prometheus.io/docs/concepts/metric_types/
    """

    COUNTER = "counter"
    """Counter: A cumulative metric that represents a single monotonically increasing counter."""

    GAUGE = "gauge"
    """Gauge: A metric that represents a single numerical value that can arbitrarily go up and down."""

    HISTOGRAM = "histogram"
    """Histogram: Samples observations and counts them in configurable buckets."""

    SUMMARY = "summary"
    """Summary: Not supported for collection (quantiles are cumulative over server lifetime).

    Note: Summary metrics are intentionally skipped during collection because their
    quantiles are computed cumulatively over the entire server lifetime, making them
    unsuitable for benchmark-specific analysis. No major LLM inference servers use
    Summary metrics - they all use Histograms instead.
    """

    UNKNOWN = "unknown"
    """Unknown: Untyped metric (prometheus_client uses 'unknown' instead of 'untyped')."""

    @classmethod
    def _missing_(cls, value: Any) -> Self:
        """Handle unrecognized metric type values by returning UNKNOWN.

        Called automatically when constructing a PrometheusMetricType with a value
        that doesn't match any defined member. Attempts case-insensitive matching
        via parent class, then falls back to UNKNOWN for unrecognized types.

        This ensures robust parsing of Prometheus metrics where servers may expose
        non-standard or future metric types.

        Args:
            value: The value to match against enum members

        Returns:
            Matching enum member (case-insensitive) or PrometheusMetricType.UNKNOWN
        """
        try:
            return super()._missing_(value)
        except ValueError:
            return cls.UNKNOWN


class PromptSource(CaseInsensitiveStrEnum):
    SYNTHETIC = "synthetic"
    FILE = "file"
    PAYLOAD = "payload"


class ServerMetricsFormat(CaseInsensitiveStrEnum):
    """Format options for server metrics export.

    Controls which output files are generated for server metrics data.
    Default selection is JSON + CSV (JSONL excluded to avoid large files).
    """

    JSON = "json"
    """Export aggregated statistics in JSON hybrid format with metrics keyed by name.
    Best for: Programmatic access, CI/CD pipelines, automated analysis."""

    CSV = "csv"
    """Export aggregated statistics in CSV tabular format organized by metric type.
    Best for: Spreadsheet analysis, Excel/Google Sheets, pandas DataFrames."""

    JSONL = "jsonl"
    """Export raw time-series records in line-delimited JSON format.
    Best for: Time-series analysis, debugging, visualizing metric evolution.
    Warning: Can generate very large files for long-running benchmarks."""

    PARQUET = "parquet"
    """Export raw time-series data with delta calculations in Parquet columnar format.
    Best for: Analytics with DuckDB/pandas/Polars, efficient storage, SQL queries.
    Includes cumulative deltas from reference point for counters and histograms."""


class ServiceRegistrationStatus(CaseInsensitiveStrEnum):
    """Defines the various states a service can be in during registration with
    the SystemController."""

    UNREGISTERED = "unregistered"
    """The service is not registered with the SystemController. This is the
    initial state."""

    WAITING = "waiting"
    """The service is waiting for the SystemController to register it.
    This is a temporary state that should be followed by REGISTERED, TIMEOUT, or ERROR."""

    REGISTERED = "registered"
    """The service is registered with the SystemController."""

    TIMEOUT = "timeout"
    """The service registration timed out."""

    ERROR = "error"
    """The service registration failed."""


class SSEEventType(CaseInsensitiveStrEnum):
    """Event types in an SSE message."""

    ERROR = "error"


class SSEFieldType(CaseInsensitiveStrEnum):
    """Field types in an SSE message."""

    DATA = "data"
    EVENT = "event"
    ID = "id"
    RETRY = "retry"
    COMMENT = "comment"


class SystemState(CaseInsensitiveStrEnum):
    """State of the system as a whole.

    This is used to track the state of the system as a whole, and is used to
    determine what actions to take when a signal is received.
    """

    INITIALIZING = "initializing"
    """The system is initializing. This is the initial state."""

    CONFIGURING = "configuring"
    """The system is configuring services."""

    READY = "ready"
    """The system is ready to start profiling. This is a temporary state that should be
    followed by PROFILING."""

    PROFILING = "profiling"
    """The system is running a profiling run."""

    PROCESSING = "processing"
    """The system is processing results."""

    STOPPING = "stopping"
    """The system is stopping."""

    SHUTDOWN = "shutdown"
    """The system is shutting down. This is the final state."""

    @property
    def rank(self) -> int:
        """Position in the forward-only lifecycle, for monotonicity checks.

        Consumers (``AIPerfJob.status.subPhase``, dashboards) treat this as a
        forward-only sequence, so a late message from a cancelled component
        must not walk it backwards.
        """
        return _SYSTEM_STATE_ORDER[self]


_SYSTEM_STATE_ORDER: dict[SystemState, int] = {
    state: index
    for index, state in enumerate(
        (
            SystemState.INITIALIZING,
            SystemState.CONFIGURING,
            SystemState.READY,
            SystemState.PROFILING,
            SystemState.PROCESSING,
            SystemState.STOPPING,
            SystemState.SHUTDOWN,
        )
    )
}


class RequestContentType(CaseInsensitiveStrEnum):
    """Content type for HTTP request body serialization."""

    APPLICATION_JSON = "application/json"
    """Standard JSON encoding. Default for all endpoints."""

    MULTIPART_FORM_DATA = "multipart/form-data"
    """Multipart form encoding. Required by some video generation servers (e.g., vLLM)."""


class VideoFormat(CaseInsensitiveStrEnum):
    """Video container formats for synthetic video generation."""

    MP4 = "mp4"
    """MP4 container. Widely compatible, good for H.264/H.265 codecs."""

    WEBM = "webm"
    """WebM container. Open format, optimized for web, good for VP9 codec."""


class VideoJobStatus(CaseInsensitiveStrEnum):
    """Status values for async video generation jobs."""

    QUEUED = "queued"
    """Job is queued and waiting to start."""

    IN_PROGRESS = "in_progress"
    """Job is currently being processed."""

    COMPLETED = "completed"
    """Job completed successfully."""

    FAILED = "failed"
    """Job failed with an error."""


class VideoAudioCodec(CaseInsensitiveStrEnum):
    """Audio codecs for embedding audio in synthetic video files."""

    AAC = "aac"
    """AAC codec. Not built into the AIPerf container's FFmpeg; selecting it
    requires an FFmpeg build that includes an AAC encoder."""

    LIBVORBIS = "libvorbis"
    """Vorbis codec. Default for WebM containers."""

    LIBOPUS = "libopus"
    """Opus codec. Default for MP4 containers. Always encodes at 48 kHz
    regardless of the requested sample rate."""


class VideoSynthType(CaseInsensitiveStrEnum):
    MOVING_SHAPES = "moving_shapes"
    """Generate videos with animated geometric shapes moving across the frame"""

    GRID_CLOCK = "grid_clock"
    """Generate videos with a grid pattern and frame number overlay for frame-accurate verification"""

    NOISE = "noise"
    """Generate videos with random noise frames"""


class WorkerStatus(CaseInsensitiveStrEnum):
    """The current status of a worker service.

    NOTE: The order of the statuses is important for the UI.
    """

    HEALTHY = "healthy"
    HIGH_LOAD = "high_load"
    ERROR = "error"
    IDLE = "idle"
    STALE = "stale"


# =============================================================================
# Surface consumed by `aiperf.config` (BenchmarkPlan, SweepConfig,
# ArtifactsConfig, etc.).
# =============================================================================


class CommunicationType(CaseInsensitiveStrEnum):
    """Type of inter-process communication transport."""

    IPC = "ipc"
    """Unix domain sockets (single machine)."""

    TCP = "tcp"
    """TCP sockets (multi-machine)."""

    DUAL = "dual"
    """Dual-bind: IPC for co-located services, TCP for remote workers (Kubernetes)."""


class DatasetType(CaseInsensitiveStrEnum):
    """Defines the source type for benchmark datasets."""

    SYNTHETIC = "synthetic"
    """Generate synthetic prompts programmatically."""

    FILE = "file"
    """Load prompts from a local file."""

    PUBLIC = "public"
    """Use a well-known public dataset."""


class OptimizationDirection(CaseInsensitiveStrEnum):
    """Direction of optimization for a metric.

    MAXIMIZE: Higher values are preferred (e.g. throughput, goodput).
    MINIMIZE: Lower values are preferred (e.g. latency, TTFT, p99).
    """

    MAXIMIZE = "maximize"
    MINIMIZE = "minimize"


class ServerMetricsDiscoveryMode(CaseInsensitiveStrEnum):
    """Mode for discovering server metrics endpoints in distributed environments."""

    AUTO = "auto"
    """Automatically detect environment and use appropriate discovery method."""

    KUBERNETES = "kubernetes"
    """Use Kubernetes API to discover inference-server pods."""

    DISABLED = "disabled"
    """Disable automatic discovery. Only use explicitly provided URLs."""


class SweepMode(CaseInsensitiveStrEnum):
    """Execution order for sweep + confidence composition.

    REPEATED: for trial in trials: for value in values
        All values tested per trial before moving to next trial.

    INDEPENDENT: for value in values: for trial in trials
        All trials completed per value before moving to next value.
    """

    INDEPENDENT = "independent"
    REPEATED = "repeated"


class ExportFormat(CaseInsensitiveStrEnum):
    """Defines the file format for record-level exports."""

    JSON = "json"
    JSONL = "jsonl"
    CSV = "csv"


class RandomCorpusStyle(CaseInsensitiveStrEnum):
    """Benchmark style for RANDOM corpus generation.

    Controls the full set of behaviors that vary between tools. Each style
    is a bundle of decisions that together reproduce the statistical
    distribution of a specific benchmarking tool:

    .. list-table::
       :header-rows: 1
       :widths: 30 35 35

       * - Concern
         - VLLM
         - SGLANG
       * - Token pool
         - ``valid_token_ids`` (special tokens excluded via ``all_special_ids``)
         - ``all_token_ids`` (full ``range(vocab_size)``, no exclusion)
       * - BOS / special-token adjustment
         - ``max(0, mean - num_special_tokens)``, applied to the mean before
           the window bounds are computed
         - ``max(1, drawn - num_special_tokens)``, applied per-request after
           sampling so the window keeps its raw-mean shape
       * - ISL/OSL range formula
         - Symmetric: ``[floor(mean*(1-r)), ceil(mean*(1+r))]``
         - Lower-bounded: ``[max(1, int(mean*r)), mean]``
       * - RNG algorithm (preseed)
         - PCG64 via ``numpy.random.default_rng(seed)``
         - MT19937 via a private ``numpy.random.RandomState(seed)``
       * - RNG draw order (with preseed)
         - All ISLs → all OSLs → all offsets
         - All ISLs → all OSLs → all offsets (same order, different algorithm)
       * - Top-up RNG
         - Continues from the same ``default_rng`` stream (``_preseed_rng``)
         - Continues from the same ``RandomState`` stream (``_preseed_rng``)

    Both styles are preseeded whenever the corpus is
    :attr:`PromptCorpus.RANDOM` — the composer gates on
    ``isinstance(dist, RangeRatioDistribution)``, which the SGLANG subclass
    satisfies. ``_corpus_rng`` is the fallback for the non-preseeded paths
    (non-RANDOM corpora, and draws past cache exhaustion), not a per-style
    difference.

    .. note::
       The two styles subtract special tokens at different points on purpose,
       each following its own upstream. VLLM folds the count into the bounds;
       SGLANG shifts each drawn length, mirroring ``sample_random_requests``
       under ``return_text`` (the default, and what aiperf sends)::

           input_lens[i] = max(1, input_lens[i] - num_special_tokens)

       Both land the same wire ISL on the configured value; only the resulting
       window shape differs.
    """

    VLLM = "vllm"
    """vllm bench serve semantics: symmetric window ``[floor(mean*(1-r)), ceil(mean*(1+r))]``.
    r=0 is fixed at mean; larger r widens the window on both sides. r must be in [0, 1).
    Special tokens excluded from the sampling pool. BOS subtracted from ISL mean."""

    SGLANG = "sglang"
    """sglang ``benchmark.serving`` semantics under ``--dataset-name random-ids``:
    lower-bounded window ``[max(1, int(mean*r)), mean]``.
    r=0 allows full variability [1, mean]; r=1 fixes length at mean. Full vocab_size range
    used for token sampling (no special-token exclusion). No BOS adjustment.

    The default ``--dataset-name random`` is a different algorithm upstream
    (repeat/truncate ShareGPT token ids) and is not what this style mirrors."""
